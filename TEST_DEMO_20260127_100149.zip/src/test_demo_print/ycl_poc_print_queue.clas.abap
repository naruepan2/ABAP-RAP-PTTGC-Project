CLASS ycl_poc_print_queue DEFINITION
  PUBLIC
  INHERITING FROM cl_xco_cp_adt_simple_classrun
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.

    CLASS-METHODS print_po
      EXPORTING
        ev_xdp TYPE xstring
        ev_xml TYPE xstring
        ev_pdf TYPE xstring
        ev_pages type int4
        ev_trace TYPE string
      RAISING
        cx_fp_ads_util.

  PROTECTED SECTION.
    METHODS: main REDEFINITION.

  PRIVATE SECTION.

    METHODS get_xdp
      RETURNING
        VALUE(r_result) TYPE xstring.
    METHODS get_xml
      RETURNING
        VALUE(r_result) TYPE xstring.

ENDCLASS.



CLASS ycl_poc_print_queue IMPLEMENTATION.

  METHOD main.

    FINAL(lv_xdp) = get_xdp( ).
    out->write( |XDP { lv_xdp }| ).

    FINAL(lv_xml) = get_xml( ).
    out->write( |XDP { lv_xdp }| ).

    TRY.
*        cl_fp_ads_util=>render_pdf(
*          EXPORTING
*            iv_xml_data     = lv_xml
*            iv_xdp_layout   = lv_xdp
*            iv_locale       = 'en_US'
*          IMPORTING
*            ev_pdf          = FINAL(lv_pdf)
*            ev_pages        = FINAL(lv_pages)
*            ev_trace_string = FINAL(lv_trace)
*        ).
        cl_fp_ads_util=>render_4_pq(
          EXPORTING
            iv_xml_data     = lv_xml
            iv_xdp_layout   = lv_xdp
            iv_locale       = 'en_US'
            iv_pq_name      = 'YQ_PDF_TEST'
          IMPORTING
            ev_pdl          = FINAL(lv_pdf)
            ev_pages        = FINAL(lv_pages)
            ev_trace_string = FINAL(lv_trace)
        ).
        out->write( |PDF { lv_pdf }| ).
        out->write( |Pages { lv_pages }| ).
        out->write( |Trace { lv_trace }| ).

        FINAL(lv_itemid) = cl_print_queue_utils=>create_queue_item_by_data(
          EXPORTING
            iv_qname            = 'YQ_PDF_TEST'
            iv_print_data       = lv_pdf
            iv_name_of_main_doc = 'Test 1050000014'
*            iv_itemid           =
*            iv_pages            =
*            iv_number_of_copies =
*            it_attachment_data  =
*          IMPORTING
*            ev_err_msg          =
*          RECEIVING
*            rv_itemid           =
        ).
        out->write( |Item ID { lv_itemid }| ).

      CATCH cx_fp_ads_util INTO FINAL(lx_err1).
        out->write( lx_err1->get_text( ) ).
    ENDTRY.

  ENDMETHOD.


  METHOD get_xdp.
    TRY.
        r_result = zcl_t2_somu_form_services=>get_xdp( 'MM_PUR_PURCHASE_ORDER' ).
      CATCH zcx_ext_general_error INTO FINAL(lx_error).
        out->write( lx_error->previous->get_text( ) ).
    ENDTRY.
  ENDMETHOD.


  METHOD get_xml.
    TRY.
        zcl_t2_somu_form_services=>get_data(
          EXPORTING
            iv_service_name = 'FDP_EF_PURCHASE_ORDER_SRV'
            it_key          = VALUE #(
                              ( name  = 'PurchaseOrder'           value = '1050000014' )
                              ( name  = 'SenderCountry'           value = 'TH' )
                              ( name  = 'Language'                value = 'E' )
                              ( name  = 'PurchaseOrderChangeFlag' value = space )
                              ( name  = 'ReceiverPartnerNumber'   value = '0010000012' )

            )
          IMPORTING
            ev_xml          = r_result
            et_message      = FINAL(lt_msg)
        ).
        out->write( |XML { r_result }| ).
        out->write( lt_msg ).
      CATCH zcx_ext_general_error INTO FINAL(lx_err2).
        out->write( lx_err2->previous->get_text( ) ).
    ENDTRY.
  ENDMETHOD.

  METHOD print_po.

    FINAL(lo_obj) = NEW ycl_poc_print_queue( ).
    ev_xdp = lo_obj->get_xdp( ).
    ev_xml = lo_obj->get_xml( ).

    cl_fp_ads_util=>render_4_pq(
      EXPORTING
        iv_xml_data     = ev_xml
        iv_xdp_layout   = ev_xdp
        iv_locale       = 'en_US'
        iv_pq_name      = 'YQ_PDF_TEST'
      IMPORTING
        ev_pdl          = ev_pdf
        ev_pages        = ev_pages
        ev_trace_string = ev_trace
    ).

    FINAL(lv_itemid) = cl_print_queue_utils=>create_queue_item_by_data(
      EXPORTING
        iv_qname            = 'YQ_PDF_TEST'
        iv_print_data       = ev_pdf
        iv_name_of_main_doc = 'Test 1050000014'
*            iv_itemid           =
*            iv_pages            =
*            iv_number_of_copies =
*            it_attachment_data  =
*          IMPORTING
*            ev_err_msg          =
*          RECEIVING
*            rv_itemid           =
    ).
  ENDMETHOD.

ENDCLASS.
