CLASS ycl_demo_call_http_json DEFINITION
  PUBLIC
  INHERITING FROM cl_xco_cp_adt_simple_classrun
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
  PROTECTED SECTION.
    METHODS: main REDEFINITION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_demo_call_http_json IMPLEMENTATION.

  METHOD main.
    TYPES:
      BEGIN OF lty_value,
        quotyp   TYPE string,
        quotdate TYPE d,
      END OF lty_value.

    DATA:
      BEGIN OF ls_payload,
        value TYPE STANDARD TABLE OF lty_value WITH EMPTY KEY,
      END OF ls_payload.

    TRY.
        DATA(lo_dest) = zcl_t2_outbound_provider_http=>create_by_destination( 'S4_TO_DSP' ).
        DATA(lo_client) = cl_web_http_client_manager=>create_by_http_destination( lo_dest ).

        DATA(lo_request) = lo_client->get_http_request( ).

        lo_request->set_uri_path( 'HRL_OTC_ISOIL/DSP_OTC_RL_GV_FC_PRICEQUATATIONS/DSP_OTC_RL_GV_FC_PRICEQUATATIONS' ).

        lo_request->set_header_field(
          i_name  = '$top'
          i_value = '5'
        ).

        DATA(lo_response) = lo_client->execute( if_web_http_client=>get ).

        DATA(lv_string) = lo_response->get_text( ).

        out->write( lv_string ).
        xco_cp_json=>data->from_string( lv_string
*          )->apply( VALUE #(
**                      ( xco_cp_json=>transformation->pascal_case_to_underscore )
*                      ( xco_cp_json=>transformation->boolean_to_abap_bool ) )
          )->write_to( REF #( ls_payload ) ).

        out->write( ls_payload ).

      CATCH cx_root INTO DATA(lx_error).
        out->write( lx_error->get_text( ) ).
        "handle exception
    ENDTRY.
  ENDMETHOD.

ENDCLASS.
