@AbapCatalog.sqlViewName: 'YIMAINTBOMHDR'
@ClientHandling.type : #INHERITED
@ClientHandling.algorithm : #SESSION_VARIABLE
@VDM.viewType: #COMPOSITE
@ObjectModel.usageType: {serviceQuality: #D, sizeCategory: #XL, dataClass: #TRANSACTIONAL}
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@AccessControl.personalData.blocking: #NOT_REQUIRED
@AbapCatalog.preserveKey:true
@EndUserText.label: 'Maintenance Bill of Material Header'

define view YI_MaintenanceBillOfMaterial
  as select from I_BillOfMaterial as bom_header
  association [0..1] to I_User                        as _CreatedByUser               on  $projection.CreatedByUser = _CreatedByUser.UserID

  association [0..1] to I_User                        as _ChangedByUser               on  $projection.LastChangedByUser = _ChangedByUser.UserID

  association [0..1] to I_MaintTechObjBOMChgNumberVH  as _MaintTechObjBOMChgNumber    on  $projection.EngineeringChangeDocument = _MaintTechObjBOMChgNumber.ChangeNumber
                                                                                      and $projection.ChangeNumberObjectType    = _MaintTechObjBOMChgNumber.ChangeNumberObjectType
  association [0..1] to I_Plant                       as _Plant                       on  _Plant.Plant = $projection.Plant


  association [0..1] to I_BillOfMaterialUsage         as _MaintBillOfMaterialUsage    on  $projection.BillOfMaterialVariantUsage = _MaintBillOfMaterialUsage.BillOfMaterialVariantUsage
                                                                                      and _MaintBillOfMaterialUsage.Language     = $session.system_language

  association [0..1] to I_MaintBillOfMaterialCategory as _MaintBillOfMaterialCategory on  $projection.BillOfMaterialCategory    = _MaintBillOfMaterialCategory.BillOfMaterialCategory
                                                                                      and _MaintBillOfMaterialCategory.Language = $session.system_language

  association [0..1] to I_FunctionalLocation          as _FunctionalLocation          on  _FunctionalLocation.FunctionalLocation = $projection.FunctionalLocation

  association [0..1] to I_Equipment                   as _Equipment                   on  _Equipment.Equipment = $projection.equipment

  association [0..1] to I_TechObjIsEquipOrFuncnlLoc   as _TechObjIsEquipOrFuncnlLoc   on  _TechObjIsEquipOrFuncnlLoc.TechObjIsEquipOrFuncnlLoc = $projection.TechObjIsEquipOrFuncnlLoc
{

  key                   cast( bom_header.BillOfMaterial  as abap.char( 8 ) )                                         as BillOfMaterial,
                        //
  key                   case BillOfMaterialCategory
                             when 'E' then bom_header._Eqst.Plant
                             when 'T' then  bom_header._Tpst.Plant
                             when 'M' then  bom_header._Mast.Plant
                             else ''
                     end                                                                                             as Plant,
  key                   bom_header.BillOfMaterialCategory                                                            as BillOfMaterialCategory,
  key                   cast(
                       case BillOfMaterialCategory
                          when 'E' then bom_header._Eqst.Equipment
                          when 'T' then bom_header._Tpst.FunctionalLocation
                          when 'M' then bom_header._Mast.Material
                          else ''
                        end as eams_tec_obj )                                                                        as TechnicalObject,
  key                   bom_header.BillOfMaterialVariant                                                             as BillOfMaterialVariant,
  key                   bom_header.BillOfMaterialVersion                                                             as BillOfMaterialVersion,
                        @Consumption.valueHelp: '_MaintTechObjBOMChgNumber'
  key                   bom_header.BillOfMaterialVariantUsage                                                        as BillOfMaterialVariantUsage,
  key                   bom_header.EngineeringChangeDocument                                                         as EngineeringChangeDocument,
                        bom_header.BillOfMaterialHeaderUUID                                                          as BillOfMaterialHeaderUUID,
                        bom_header.IsMultipleBOMAlt                                                                  as IsMultipleBOMAlt,
                        bom_header.BOMHeaderInternalChangeCount                                                      as BOMHeaderInternalChangeCount,
                        bom_header.BOMUsagePriority                                                                  as BOMUsagePriority,
                        bom_header.BillOfMaterialAuthsnGrp                                                           as BillOfMaterialAuthsnGrp,
                        bom_header.BOMVersionStatus                                                                  as BOMVersionStatus,
                        bom_header.IsVersionBillOfMaterial                                                           as IsVersionBillOfMaterial,
                        bom_header.IsLatestBOMVersion                                                                as IsLatestBOMVersion,
                        bom_header.IsConfiguredMaterial                                                              as IsConfiguredMaterial,
                        cast ( bom_header.BOMTechnicalType as tetyp_d preserving type)                               as BOMTechnicalType,
                        bom_header.BOMGroup                                                                          as BOMGroup,
                        bom_header.BOMHeaderText                                                                     as BOMHeaderText,
                        bom_header.BOMAlternativeText                                                                as BOMAlternativeText,
                        bom_header.BillOfMaterialStatus                                                              as BillOfMaterialStatus,
                        bom_header.HeaderValidityStartDate                                                           as HeaderValidityStartDate,
                        bom_header.HeaderValidityEndDate                                                             as HeaderValidityEndDate,
                        bom_header.ChgToEngineeringChgDocument                                                       as ChgToEngineeringChgDocument,
                        bom_header.IsMarkedForDeletion                                                               as IsMarkedForDeletion,
                        bom_header.IsALE                                                                             as IsALE,
                        @Semantics.unitOfMeasure: true
                        bom_header.BOMHeaderBaseUnit                                                                 as BOMHeaderBaseUnit,
                        @Semantics.quantity.unitOfMeasure: 'BOMHeaderBaseUnit'
                        bom_header.BOMHeaderQuantityInBaseUnit                                                       as BOMHeaderQuantityInBaseUnit,
                        bom_header.RecordCreationDate                                                                as RecordCreationDate,
                        bom_header.LastChangeDate                                                                    as LastChangeDate,
                        bom_header.CreatedByUser                                                                     as CreatedByUser,
                        bom_header.LastChangedByUser                                                                 as LastChangedByUser,
                        @Semantics.booleanIndicator: true
                        bom_header.BOMIsToBeDeleted                                                                  as BOMIsToBeDeleted,
                        bom_header.DocumentIsCreatedByCAD                                                            as DocumentIsCreatedByCAD,
                        bom_header.LaboratoryOrDesignOffice,
                        bom_header.LastChangeDateTime,
                        cast(' ' as abap.char( 4 ) )                                                                 as SelectedBillOfMaterialVersion,

                        concat( concat( concat(_CreatedByUser.UserDescription,' (' ) , _CreatedByUser.UserID ), ')') as CreatedByUserName,
                        concat( concat( concat(_ChangedByUser.UserDescription,' (' ) , _ChangedByUser.UserID ), ')') as ChangedByUserName,
                        case when BillOfMaterialCategory = 'T' then '05'
                        else '03'
                        end                                                                                          as ChangeNumberObjectType,

                        bom_header._Eqst.Equipment,
                        cast( bom_header._Tpst.FunctionalLocation as vdm_eam_tplnr )                                 as FunctionalLocation,

                        @ObjectModel.foreignKey.association: '_TechObjIsEquipOrFuncnlLoc'
                        cast( case when _Eqst.Equipment = '' and _Tpst.FunctionalLocation = '' then ''
                              else case when BillOfMaterialCategory = 'T' then 'EAMS_FL'
                                        when BillOfMaterialCategory = 'E' then 'EAMS_EQUI'
                                        else '' end end as eams_tec_obj_type_value )                                 as TechObjIsEquipOrFuncnlLoc,

                        _FunctionalLocation,
                        _Equipment,
                        _MaintBillOfMaterialCategory,
                        _MaintBillOfMaterialUsage,
                        _Plant,
                        _MaintTechObjBOMChgNumber,
                        _TechObjIsEquipOrFuncnlLoc,
                        _CreatedByUser,
                        _ChangedByUser

}
