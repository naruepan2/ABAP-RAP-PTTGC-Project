@AccessControl.authorizationCheck: #CHECK
@AccessControl.personalData.blocking: #NOT_REQUIRED
@EndUserText.label: 'Maintenance Bill Of Material Item'
@VDM.viewType: #COMPOSITE
@ObjectModel.usageType: { serviceQuality: #D , sizeCategory: #XL, dataClass: #TRANSACTIONAL}
@VDM.lifecycle.contract.type:#PUBLIC_REMOTE_API
@Metadata.ignorePropagatedAnnotations: true

define view entity YA_MaintBillOfMaterialItem
  //as select from R_MaintBillOfMaterialItemTP as items
  as projection on R_MaintBillOfMaterialItemTP as items
  //  association        to parent A_MaintenanceBillOfMaterial as _BillOfMaterial  on  $projection.BillOfMaterial             = _BillOfMaterial.BillOfMaterial
  //                                                                               and $projection.BillOfMaterialCategory     = _BillOfMaterial.BillOfMaterialCategory
  //                                                                               and $projection.BillOfMaterialVariant      = _BillOfMaterial.BillOfMaterialVariant
  //                                                                               and $projection.BillOfMaterialVersion      = _BillOfMaterial.BillOfMaterialVersion
  //                                                                               and $projection.TechnicalObject            = _BillOfMaterial.TechnicalObject
  //                                                                               and $projection.Plant                      = _BillOfMaterial.Plant
  //                                                                               and $projection.EngineeringChangeDocument  = _BillOfMaterial.EngineeringChangeDocument
  //                                                                               and $projection.BillOfMaterialVariantUsage = _BillOfMaterial.BillOfMaterialVariantUsage

  association [0..1] to A_BOMItemCategory as _BOMItemCategory on $projection.BillOfMaterialItemCategory = _BOMItemCategory.BillOfMaterialItemCategory
{
  key            items.BillOfMaterial,
  key            items.BillOfMaterialCategory,
  key            items.BillOfMaterialVariant,
  key            items.BillOfMaterialVersion,
  key            items.TechnicalObject,
  key            items.Plant,
  key            items.EngineeringChangeDocument,
  key            items.BillOfMaterialVariantUsage,
  key            items.BillOfMaterialItemNodeNumber,
                 //  key            items.EngineeringChangeDocument,
                 items.BillOfMaterialItemUUID,
                 items.BOMItemInternalChangeCount,
                 items.ValidityStartDate,
                 items.ValidityEndDate,
                 //items.EngineeringChangeDocForEdit,
                 items.ChgToEngineeringChgDocument,
                 items.InheritedNodeNumberForBOMItem,
                 items.BOMItemRecordCreationDate,
                 items.BOMItemCreatedByUser,
                 items.BOMItemLastChangeDate,
                 items.BOMItemLastChangedByUser,
                 items.BillOfMaterialComponent,
                 items.BillOfMaterialItemCategory,
                 items.BillOfMaterialItemNumber,
                 //                 @Semantics.unitOfMeasure: true
                 items.BillOfMaterialItemUnit,
                 @Semantics.quantity.unitOfMeasure: 'BillOfMaterialItemUnit'
                 items.BillOfMaterialItemQuantity,
                 items.IsAssembly,
                 items.IsSubItem,
                 items.BOMItemSorter,
                 // items.FixedQuantity,
                 items.PurchasingGroup,
                 //                 @Semantics.currencyCode: true
                 items.Currency,
                 @Semantics.amount.currencyCode : 'Currency'
                 items.MaterialComponentPrice,
                 items.IdentifierBOMItem,
                 @Semantics.quantity.unitOfMeasure: 'BillOfMaterialItemUnit'
                 items.MaterialPriceUnitQty,
                 items.ComponentScrapInPercent,
                 items.OperationScrapInPercent,
                 items.IsNetScrap,

                 //items.NumberOfVariableSizeItem,
                 @Semantics.quantity.unitOfMeasure: 'BillOfMaterialItemUnit'
                 items.QuantityVariableSizeItem,
                 items.FormulaKey,
                 items.ComponentDescription,
                 items.BOMItemDescription,
                 items.BOMItemText2,
                 items.MaterialGroup,
                 items.DocumentType,
                 items.DocNumber,
                 items.DocumentVersion,
                 items.DocumentPart,
                 items.ClassNumber,
                 items.ClassType,
                 items.ResultingItemCategory,
                 items.DependencyObjectNumber,
                 items.ObjectType,
                 items.IsClassificationRelevant,
                 items.IsBulkMaterial,
                 items.BOMItemIsSparePart,
                 items.BOMItemIsSalesRelevant,
                 items.IsProductionRelevant,
                 items.BOMItemIsPlantMaintRelevant,
                 items.BOMItemIsCostingRelevant,
                 items.IsEngineeringRelevant,
                 items.SpecialProcurementType,
                 items.IsBOMRecursiveAllowed,
                 items.OperationLeadTimeOffset,
                 items.OpsLeadTimeOffsetUnit,
                 items.IsMaterialProvision,
                 items.BOMIsRecursive,
                 items.DocumentIsCreatedByCAD,
                 items.DistrKeyCompConsumption,
                 items.DeliveryDurationInDays,
                 items.Creditor,
                 items.CostElement,
                 @Semantics.quantity.unitOfMeasure : 'UnitOfMeasureForSize1To3'
                 items.Size1,
                 @Semantics.quantity.unitOfMeasure : 'UnitOfMeasureForSize1To3'
                 items.Size2,
                 @Semantics.quantity.unitOfMeasure : 'UnitOfMeasureForSize1To3'
                 items.Size3,
                 items.UnitOfMeasureForSize1To3,
                 items.GoodsReceiptDuration,
                 items.PurchasingOrganization,
                 items.RequiredComponent,
                 items.MultipleSelectionAllowed,
                 items.ProdOrderIssueLocation,
                 items.MaterialIsCoProduct,
                 items.ExplosionType,
                 items.AlternativeItemGroup,
                 items.FollowUpGroup,
                 items.DiscontinuationGroup,
                 items.IsConfigurableBOM,
                 items.ReferencePoint,
                 items.LeadTimeOffset,
                 items.ProductionSupplyArea,
                 items.IsDeleted,
                 items.IsALE,
                 items.BillOfMaterialHeaderUUID,
                 //  @ObjectModel.association.type:  [ #TO_COMPOSITION_ROOT, #TO_COMPOSITION_PARENT ]
                 _BillOfMaterial : redirected to parent A_MaintenanceBillOfMaterial,
                 _BOMItemCategory
}
