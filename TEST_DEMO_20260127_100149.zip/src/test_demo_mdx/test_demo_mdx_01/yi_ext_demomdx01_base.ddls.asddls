@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Base'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #XXL,
    dataClass: #TRANSACTIONAL
}
@Analytics.dataCategory: #CUBE
define view entity YI_EXT_DemoMDX01_Base
  as select from I_GoodsMovementCube
{
  key MaterialDocumentYear,
  key MaterialDocument,
  key MaterialDocumentItem,
      Plant,
      Material,
      CompanyCodeCurrency,
      MaterialBaseUnit,
      IsReversalMovementType,
      //      MaterialGroup,
      //      MaterialType,
      IssuingOrReceivingPlant,
      IssgOrRcvgMaterial,
      GoodsMovementIsCancelled,

      // Periods & Times
      @Semantics.businessDate.at: true
      PostingDate,
      @Semantics.fiscal.yearVariant: true
      FiscalYearVariant,
      FiscalYear,
      @Semantics.fiscal.yearPeriod: true
      FiscalYearPeriod,
      YearDay,
      @Semantics.calendar.yearWeek: true
      YearWeek,
      @Semantics.calendar.yearMonth: true
      YearMonth,
      @Semantics.calendar.yearQuarter: true
      YearQuarter,
      @Semantics.calendar.quarter: true
      CalendarQuarter,
      @Semantics.calendar.month: true
      CalendarMonth,
      @Semantics.calendar.week: true
      CalendarWeek,
      @Semantics.calendar.dayOfYear: true
      CalendarDay,
      WeekDay,

      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      @DefaultAggregation: #SUM
      GoodsMovementStkAmtInCCCrcy,
      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      @DefaultAggregation: #SUM
      GoodsMvtCnsmpnAmtInCCCrcy,
      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      @DefaultAggregation: #SUM
      GoodsIssueAmountInCoCodeCrcy,
      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      @DefaultAggregation: #SUM
      GoodsReceiptAmountInCoCodeCrcy,

      @Semantics.quantity.unitOfMeasure: 'MaterialBaseUnit'
      @DefaultAggregation: #SUM
      MatlStkChangeQtyInBaseUnit,

      /* Associations */
      _Currency,
      _IssgOrRcvgMaterial,
      _IssuingOrReceivingPlant,
      _Material,
      _MaterialBaseUnit,
      //      _MaterialGroup,
      //      _MaterialType,
      _Plant,
      _Product,
      _ProductPlant
}
where
       MaterialDocumentRecordType = 'MDOC'
  and(
       GoodsMovementType          = '301'
    or GoodsMovementType          = '311'
  )
