@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Cube'
@Analytics.dataCategory: #CUBE
define root view entity YI_EXT_DemoMDX01_Cube
  as select from YI_EXT_DemoMDX01_Agg1
{
  key FiscalYearPeriod,
  key Plant,
  key Material,
  key IssuingOrReceivingPlant,
  key IssgOrRcvgMaterial,
      
      FiscalYearVariant,
      CompanyCodeCurrency,
      MaterialBaseUnit,
      FiscalYear,
      @DefaultAggregation: #SUM
      GoodsMovementStkAmtInCCCrcy,
      MatlStkChangeQtyInBaseUnit,
//      @ObjectModel.virtualElementCalculatedBy: 'ABAP:ZCL_RTR_VE_SUPPLIERINVOICE'
//      cast('' as abap.char(10)) as TestVE,
      /* Associations */
      _Currency,
      _IssgOrRcvgMaterial,
      _IssuingOrReceivingPlant,
      _Material,
      _MaterialBaseUnit,
      _Plant,
      _Product,
      _ProductPlant
}
