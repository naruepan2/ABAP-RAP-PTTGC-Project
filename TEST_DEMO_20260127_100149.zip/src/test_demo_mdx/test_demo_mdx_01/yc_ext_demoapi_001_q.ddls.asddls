@AccessControl.authorizationCheck: #NOT_ALLOWED
@EndUserText.label: 'Query 001'
@ObjectModel.modelingPattern: #ANALYTICAL_QUERY
@ObjectModel.supportedCapabilities: [#ANALYTICAL_QUERY]
@Analytics.query: true
define root view entity YC_EXT_DemoAPI_001_Q
  //  provider contract analytical_query
  as select from YI_EXT_DemoMDX01_Cube
{
  key FiscalYearPeriod,
  key Plant,
  key Material,
  key IssuingOrReceivingPlant,
  key IssgOrRcvgMaterial,
      FiscalYearVariant,
      CompanyCodeCurrency,
      MaterialBaseUnit,
      FiscalYear,
      GoodsMovementStkAmtInCCCrcy,
      MatlStkChangeQtyInBaseUnit,
      /* Associations */
      _Currency,
      _IssgOrRcvgMaterial,
      _IssuingOrReceivingPlant,
      _Material,
      _MaterialBaseUnit,
      _Plant,
      _Product,
      _ProductPlant
}
