@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Aggregate'
@Analytics.dataCategory: #AGGREGATIONLEVEL
define view entity YI_EXT_DemoMDX01_Agg1
  as select from YI_EXT_DemoMDX01_Base

{
  key FiscalYearPeriod,
  key Plant,
  key Material,
  key IssuingOrReceivingPlant,
  key IssgOrRcvgMaterial,

      FiscalYearVariant,
      CompanyCodeCurrency,
      MaterialBaseUnit,
      FiscalYear,

      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      cast(
        sum( GoodsMovementStkAmtInCCCrcy )
        as nsdm_stk_chg_amount preserving type ) as GoodsMovementStkAmtInCCCrcy,
      @Semantics.quantity.unitOfMeasure: 'MaterialBaseUnit'
      cast(
        sum( MatlStkChangeQtyInBaseUnit )
        as nsdm_stk_chg_qty preserving type )    as MatlStkChangeQtyInBaseUnit,

      /* Associations */
      _Currency,
      _IssgOrRcvgMaterial,
      _IssuingOrReceivingPlant,
      _Material,
      _MaterialBaseUnit,
      _Plant,
      _Product,
      _ProductPlant
}
group by
  FiscalYearPeriod,
  Plant,
  Material,
  CompanyCodeCurrency,
  MaterialBaseUnit,
  IssuingOrReceivingPlant,
  IssgOrRcvgMaterial,
  FiscalYear,
  FiscalYearVariant
