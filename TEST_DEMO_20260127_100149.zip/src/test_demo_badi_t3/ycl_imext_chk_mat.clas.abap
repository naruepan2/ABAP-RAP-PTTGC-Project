CLASS ycl_imext_chk_mat DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_ex_badi_material_check .
    INTERFACES if_oo_adt_classrun .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS YCL_IMEXT_CHK_MAT IMPLEMENTATION.


  METHOD if_ex_badi_material_check~check_change_mara_meins.
  ENDMETHOD.


  METHOD if_ex_badi_material_check~check_change_pmata.
  ENDMETHOD.


  METHOD if_ex_badi_material_check~check_data.

*    DATA : lr_allow_user TYPE RANGE OF sy-uname .
*    DATA(lo_abap_config) = NEW zcl_ext_abap_config( iv_program = 'YIMEXT_CHK_MAT' ) .
*    lo_abap_config->get_range_value( EXPORTING
*                                     iv_identifier = 'CheckUser'
*                                     iv_type_value = zcl_ext_abap_config=>c_type_value-char
*                                     IMPORTING
*                                     et_range = lr_allow_user ) .
*
*    IF cl_abap_context_info=>get_user_technical_name(  ) IN lr_allow_user AND lr_allow_user IS NOT INITIAL .
*
*      MESSAGE e001(00) WITH 'Sample Tier 3 Call Tier 1' RAISING application_error.
*
*    ENDIF.

  ENDMETHOD.


  METHOD if_ex_badi_material_check~check_data_retail.
  ENDMETHOD.


  METHOD if_ex_badi_material_check~check_mass_marc_data.
  ENDMETHOD.


  METHOD if_ex_badi_material_check~fre_suppress_marc_check.
  ENDMETHOD.


  METHOD if_oo_adt_classrun~main.


*  READ ENTITIES OF ZI_EXT_AbapConfiguration_S
*  ENTITY AbapConfiguration
*  ALL FIELDS WITH
*  VALUE #( )
*  VALUE #( ( ProgramName = 'YIMEXT_CHK_MAT'
**             %key-Item = '001'
*              )
*
**              ( %key-ProgramName = 'YIMEXT_CHK_MAT'
**             %key-Identifier = 'CheckUser'
***             %key-Item = '001'
**              )
*              )
*    result data(lt_result)
*    failed data(lt_fail)
*    reported data(lt_report).
  ENDMETHOD.
ENDCLASS.
