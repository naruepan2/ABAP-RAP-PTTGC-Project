*&---------------------------------------------------------------------*
*& Report yr_demo_apj_01
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT yext001r MESSAGE-ID zmext_common.

*---------------------------------------------------------------------
* Class Definition for Posting Logic
*---------------------------------------------------------------------
CLASS lcl_dummy DEFINITION CREATE PRIVATE.

**********************************************************************
* Public Section
**********************************************************************
  PUBLIC SECTION.
*---------------------------------------------------------------------
* Public Section - Interfaces
*---------------------------------------------------------------------
    "INTERFACES:

*---------------------------------------------------------------------
* Public Section - Constants
*---------------------------------------------------------------------
    "CONSTANTS:

*---------------------------------------------------------------------
* Public Section - Types
*---------------------------------------------------------------------
    "TYPES:

*---------------------------------------------------------------------
* Public Section - Data
*---------------------------------------------------------------------
    "CLASS-DATA:
    "DATA:

*---------------------------------------------------------------------
* Public Section - Methods
*---------------------------------------------------------------------
    CLASS-METHODS create
      RETURNING
        VALUE(ro_instance) TYPE REF TO lcl_dummy.
    CLASS-METHODS set_toolbar.
    CLASS-METHODS handle_command
      IMPORTING
        iv_command TYPE syucomm.

    CLASS-METHODS browse_file
      RETURNING
        VALUE(rv_upload) TYPE string.
    CLASS-METHODS class_constructor.
    METHODS execute.
    "CLASS-METHODS:
    "METHODS:


**********************************************************************
* Protected Section
**********************************************************************
  PROTECTED SECTION.
*---------------------------------------------------------------------
* Protected Section - Types
*---------------------------------------------------------------------
    "TYPES:

*---------------------------------------------------------------------
* Protected Section - Data
*---------------------------------------------------------------------
    "CLASS-DATA:
    "DATA:

*---------------------------------------------------------------------
* Protected Section - Methods
*---------------------------------------------------------------------
    "CLASS-METHODS:
    "METHODS:


**********************************************************************
* Private Section
**********************************************************************
  PRIVATE SECTION.
    CLASS-DATA go_job_log TYPE REF TO if_bali_log.
    CLASS-METHODS _alv.
*---------------------------------------------------------------------
* Private Section - Types
*---------------------------------------------------------------------
    "TYPES:

*---------------------------------------------------------------------
* Private Section - Data
*---------------------------------------------------------------------
    "CLASS-DATA:
    "DATA:

*---------------------------------------------------------------------
* Private Section - Methods
*---------------------------------------------------------------------
    "CLASS-METHODS:
    METHODS _add_log_item
      IMPORTING
        iv_severity         TYPE if_bali_constants=>ty_severity DEFAULT if_bali_constants=>c_severity_error
        io_exception        TYPE cl_bali_exception_setter=>ty_exception OPTIONAL
        is_bapiret2         TYPE bapiret2 OPTIONAL
        io_bali_item_setter TYPE REF TO if_bali_item_setter OPTIONAL.

    METHODS _save_job_log.
    METHODS _pdf
      RAISING
        zcx_ext_general_error.

ENDCLASS.


* [NEW] Required structure for selection screen fields
TABLES: sscrfields.

DATA: gs_company TYPE i_companycode.

* [NEW] Activate Function Key 1 on the toolbar
SELECTION-SCREEN FUNCTION KEY 1.

SELECT-OPTIONS:
  s_ccode FOR gs_company-companycode.

PARAMETERS:
  p_test AS CHECKBOX,
  p_pdf  AS CHECKBOX.

PARAMETERS:
  p_upload TYPE string.

*&---------------------------------------------------------------------*
*& EVENTS
*&---------------------------------------------------------------------*

* [NEW] Set the button text when the program starts
INITIALIZATION.
  lcl_dummy=>set_toolbar( ).

* [NEW] Handle the button click event
AT SELECTION-SCREEN.
  lcl_dummy=>handle_command( sscrfields-ucomm ).

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_upload.
  p_upload = lcl_dummy=>browse_file( ).

START-OF-SELECTION.

  lcl_dummy=>create( )->execute( ).


CLASS lcl_dummy IMPLEMENTATION.

  METHOD class_constructor.
    TRY.
        go_job_log =
          cl_bali_log=>create_with_header(
            cl_bali_header_setter=>create(
              object    = 'YALO_APJ01'
              subobject = 'CLASSIC01' ) ).
      CATCH cx_bali_runtime.
    ENDTRY.
  ENDMETHOD.

  METHOD create.
    ro_instance = NEW #( ).
  ENDMETHOD.


  METHOD set_toolbar.
    sscrfields-functxt_01 = 'Call YEXT999'.
  ENDMETHOD.


  METHOD handle_command.
    CASE iv_command.
      WHEN 'FC01'. " FC01 corresponds to FUNCTION KEY 1
        CALL TRANSACTION 'YEXT999'.
    ENDCASE.

  ENDMETHOD.


  METHOD browse_file.

    DATA: lt_file  TYPE filetable,
          lv_subrc TYPE i.

    CALL METHOD cl_gui_frontend_services=>file_open_dialog
      EXPORTING
        window_title = 'Select file'
      CHANGING
        file_table   = lt_file
        rc           = lv_subrc.

    IF sy-subrc = 0.
      READ TABLE lt_file INDEX 1 INTO rv_upload.
    ENDIF.

  ENDMETHOD.


  METHOD execute.
    TRY.

        IF p_pdf = abap_true.
          MESSAGE s000 WITH 'Print PDF'.
          _add_log_item( ).
          _pdf( ).
        ENDIF.

        IF p_test = abap_true.
          MESSAGE s000 WITH 'Test ALV'.
          _add_log_item( ).
          _alv( ).
        ENDIF.

      CATCH cx_root INTO DATA(lx_error).
        MESSAGE lx_error TYPE 'S' DISPLAY LIKE 'E'.
        _add_log_item( io_exception  = lx_error ).
    ENDTRY.

    _save_job_log( ).
  ENDMETHOD.


  METHOD _alv.

    SELECT FROM i_companycode
      FIELDS
        *
      WHERE companycode IN @s_ccode[]
      INTO TABLE @DATA(lt_company)
      UP TO 30 ROWS.

    TRY.
        cl_salv_table=>factory(
          IMPORTING
            r_salv_table   = FINAL(go_salv)
          CHANGING
            t_table        = lt_company
        ).

        go_salv->display( ).

*        IF sy-batch = abap_true.
        DO 10 TIMES.
          WAIT UP TO 1 SECONDS.
          WRITE:/ sy-index.
        ENDDO.
*        ENDIF.

      CATCH cx_salv_msg.
    ENDTRY.
  ENDMETHOD.

  METHOD _save_job_log.
    IF go_job_log IS BOUND.
      TRY.
          cl_bali_log_db=>get_instance( )->save_log(
            log                        = go_job_log
            assign_to_current_appl_job = abap_true ).
        CATCH cx_bali_runtime.
      ENDTRY.
    ENDIF.
  ENDMETHOD.

  METHOD _add_log_item.

    IF go_job_log IS BOUND.
      TRY.
          IF io_exception IS SUPPLIED.
            IF io_exception IS BOUND.
              go_job_log->add_item( cl_bali_exception_setter=>create(
                                  severity  = iv_severity
                                  exception = io_exception ) ).
              _add_log_item(
                iv_severity   = iv_severity
                io_exception  = io_exception->previous ).
            ELSE.
              RETURN.
            ENDIF.

          ELSEIF is_bapiret2 IS SUPPLIED.
            go_job_log->add_item( cl_bali_message_setter=>create_from_bapiret2( is_bapiret2 ) ).

          ELSEIF io_bali_item_setter IS SUPPLIED.
            go_job_log->add_item( io_bali_item_setter ).

          ELSE.
            go_job_log->add_item( cl_bali_message_setter=>create_from_sy( ) ).

          ENDIF.

        CATCH cx_bali_runtime.
          RETURN.
      ENDTRY.
    ENDIF.
  ENDMETHOD.


  METHOD _pdf.

    TRY.
        FINAL(lo_fdp_api) = cl_fp_fdp_services=>get_instance(
                             iv_service_definition = 'YUI_DEMO_FORM01_O4'
                             iv_root_node          = 'YC_DEMO_FORM01'
                           ).
        DATA(lt_keys) = lo_fdp_api->get_keys( ).

        SELECT SINGLE FROM yc_demo_form01
          FIELDS
            companycode,
            accountingdocument,
            fiscalyear
          INTO @FINAL(ls_doc).

        lt_keys[ name = 'COMPANYCODE' ]-value = ls_doc-companycode.
        lt_keys[ name = 'ACCOUNTINGDOCUMENT' ]-value = ls_doc-accountingdocument.
        lt_keys[ name = 'FISCALYEAR' ]-value = ls_doc-fiscalyear.

        DATA(lv_xml) = lo_fdp_api->read_to_xml_v2( lt_keys ).

        .

*        ls_outputparams = COND #( WHEN is_outputparams IS SUPPLIED
*                                  THEN is_outputparams
*                                  ELSE VALUE #( nodialog = abap_true
*                                                preview  = abap_true
*                                                getpdf   = abap_true ) ).
        zcl_classic_sfp_form_services=>get_pdf(
          EXPORTING
            iv_name         = 'YY_TEST_PDF_FORM02'
            iv_docxml_data  = lv_xml
            is_outputparams = VALUE #(  preview = abap_true
                                        dest    = 'ZPDF'
                                        reqimm  = abap_true
                                      )
*        IMPORTING
*          es_formout      =
*        RECEIVING
*          rv_pdfdata      =
        ).
      CATCH
        cx_fp_fdp_error
        cx_fp_api INTO DATA(lx_error).

        RAISE EXCEPTION TYPE zcx_ext_general_error
          EXPORTING
            io_previous = lx_error.
        .
    ENDTRY.
  ENDMETHOD.

ENDCLASS.
