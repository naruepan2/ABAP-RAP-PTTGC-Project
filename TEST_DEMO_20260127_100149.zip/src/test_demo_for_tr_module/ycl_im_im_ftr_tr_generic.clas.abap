class YCL_IM_IM_FTR_TR_GENERIC definition
  public
  final
  create public .

public section.

  interfaces IF_EX_FTR_TR_GENERIC .
protected section.
private section.

  methods _CHECK_CONFIRMING_BANK_FIELD
    importing
      !PI_PROXY_TRANSACTION type ref to IF_OPEN_TRTM_PROXY_DEAL_DATA optional
      !PI_PROXY_MESSAGES type ref to IF_OPEN_TRTM_PROXY_MESSAGE optional
      !PI_CUST_TRANSACTION type ref to IF_OPEN_TRTM_CUSTOMER_DATA optional .
ENDCLASS.



CLASS YCL_IM_IM_FTR_TR_GENERIC IMPLEMENTATION.


  method IF_EX_FTR_TR_GENERIC~EVT_APPLICATION_FREE.
    IF cl_abap_context_info=>get_user_technical_name( ) <> 'Z0012353'.
      RETURN.
    ENDIF.

    BREAK Z0012353.
  endmethod.


  METHOD if_ex_ftr_tr_generic~evt_application_start.
    IF cl_abap_context_info=>get_user_technical_name( ) <> 'Z0012353'.
      RETURN.
    ENDIF.

    BREAK Z0012353.

    CHECK pi_proxy_transaction->a_editmode = if_ftr_con=>editmode_create .

*    pi_proxy_transaction->a_tlct_activity-issuing_bank = pi_proxy_transaction->a_transaction-kontrh.

  ENDMETHOD.


  METHOD if_ex_ftr_tr_generic~evt_transaction_check.

    _check_confirming_bank_field( pi_proxy_transaction = pi_proxy_transaction
                                  pi_proxy_messages = pi_proxy_messages
                                  pi_cust_transaction = pi_cust_transaction ).

  ENDMETHOD.


  method IF_EX_FTR_TR_GENERIC~EVT_TRANSACTION_SAVE_CANCEL.
  endmethod.


  METHOD if_ex_ftr_tr_generic~evt_transaction_save_check.

    _check_confirming_bank_field( pi_proxy_transaction = pi_proxy_transaction
                                  pi_proxy_messages = pi_proxy_messages
                                  pi_cust_transaction = pi_cust_transaction ).

  ENDMETHOD.


  METHOD if_ex_ftr_tr_generic~evt_transaction_save_ready.
    IF cl_abap_context_info=>get_user_technical_name( ) <> 'Z0012353'.
      RETURN.
    ENDIF.

    BREAK Z0012353.
  ENDMETHOD.


  METHOD if_ex_ftr_tr_generic~evt_transaction_save_required.
    IF cl_abap_context_info=>get_user_technical_name( ) <> 'Z0012353'.
      RETURN.
    ENDIF.
  ENDMETHOD.


  METHOD _check_confirming_bank_field.
    DATA ls_tlcs_screen_fields TYPE tlcs_screen_fields.

    IF cl_abap_context_info=>get_user_technical_name( ) <> 'Z0012353'.
      RETURN.
    ENDIF.

    BREAK z0012353.

    CHECK pi_proxy_transaction->a_editmode = if_ftr_con=>editmode_change
    OR    pi_proxy_transaction->a_editmode = if_ftr_con=>editmode_create .

    ASSIGN ('(SAPLFTR_TLC)TLCS_SCREEN_FIELDS') TO FIELD-SYMBOL(<ls_tlcs_screen_fields>) ELSE UNASSIGN.
    IF <ls_tlcs_screen_fields> IS NOT ASSIGNED.
      RETURN.
    ENDIF.


*              PI_PROXY_TRANSACTION->A_TLCT_ACTIVITY-issuing_bank
*              PI_PROXY_TRANSACTION->A_TLCT_ACTIVITY-confirming_bank

    ls_tlcs_screen_fields = CORRESPONDING #( <ls_tlcs_screen_fields> ).

    IF ls_tlcs_screen_fields-confirming_bank = 'X'.
      CALL METHOD pi_proxy_messages->set_message
        EXPORTING
          pi_message_id       = 'FTR_LC'
          pi_message_number   = 056
          pi_message_severity = 'E'
          pi_message_var1     = ls_tlcs_screen_fields-confirming_bank.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
