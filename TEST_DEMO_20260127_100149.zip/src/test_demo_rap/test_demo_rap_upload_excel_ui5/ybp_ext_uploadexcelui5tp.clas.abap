class YBP_EXT_UPLOADEXCELUI5TP definition
  public
  abstract
  final
  for behavior of YR_EXT_UPLOADEXCELUI5TP .

public section.
protected section.
private section.
ENDCLASS.



CLASS YBP_EXT_UPLOADEXCELUI5TP IMPLEMENTATION.
ENDCLASS.
