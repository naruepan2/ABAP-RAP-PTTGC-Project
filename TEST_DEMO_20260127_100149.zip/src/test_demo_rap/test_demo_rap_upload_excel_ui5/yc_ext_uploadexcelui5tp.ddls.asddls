@AccessControl.authorizationCheck: #CHECK
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for YR_EXT_UPLOADEXCELUI5TP'
@ObjectModel.semanticKey: [ 'MyKey1', 'MyKey2' ]
define root view entity YC_EXT_UPLOADEXCELUI5TP
  provider contract transactional_query
  as projection on YR_EXT_UPLOADEXCELUI5TP
{
  key MyKey1,
  key MyKey2,
  MyField1,
  MyField2,
  LocalLastChangedAt
  
}
