@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '##GENERATED RAP Upload Excel UI5'
define root view entity YR_EXT_UPLOADEXCELUI5TP
  as select from ytext_0001_a as DataUpload
{
  key my_key1 as MyKey1,
  key my_key2 as MyKey2,
  my_field1 as MyField1,
  my_field2 as MyField2,
  @Semantics.user.createdBy: true
  local_created_by as LocalCreatedBy,
  @Semantics.systemDateTime.createdAt: true
  local_created_at as LocalCreatedAt,
  @Semantics.user.localInstanceLastChangedBy: true
  local_last_changed_by as LocalLastChangedBy,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as LocalLastChangedAt,
  @Semantics.systemDateTime.lastChangedAt: true
  last_changed_at as LastChangedAt
  
}
