CLASS lhc_dataupload DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS:
      get_global_authorizations FOR GLOBAL AUTHORIZATION
        IMPORTING
        REQUEST requested_authorizations FOR dataupload
        RESULT result,
      uploadexternalexcel FOR MODIFY
        IMPORTING keys FOR ACTION dataupload~uploadexternalexcel.
ENDCLASS.

CLASS lhc_dataupload IMPLEMENTATION.
  METHOD get_global_authorizations.
  ENDMETHOD.
  METHOD uploadexternalexcel.


    TYPES: BEGIN OF ty_xlsx,
             c001 TYPE string,
             c002 TYPE string,
             c003 TYPE string,
             c004 TYPE string,
             c005 TYPE string,
             c006 TYPE string,
             c007 TYPE string,
             c008 TYPE string,
             c009 TYPE string,
             c010 TYPE string,
             c011 TYPE string,
             c012 TYPE string,
             c013 TYPE string,
             c014 TYPE string,
             c015 TYPE string,
             c016 TYPE string,
             c017 TYPE string,
             c018 TYPE string,
             c019 TYPE string,
             c020 TYPE string,
             c021 TYPE string,
             c022 TYPE string,
             c023 TYPE string,
             c024 TYPE string,
             c025 TYPE string,
             c026 TYPE string,
             c027 TYPE string,
             c028 TYPE string,
             c029 TYPE string,
             c030 TYPE string,
             c031 TYPE string,
             c032 TYPE string,
             c033 TYPE string,
             c034 TYPE string,
             c035 TYPE string,
             c036 TYPE string,
             c037 TYPE string,
             c038 TYPE string,
             c039 TYPE string,
             c040 TYPE string,
             c041 TYPE string,
             c042 TYPE string,
             c043 TYPE string,
             c044 TYPE string,
             c045 TYPE string,
             c046 TYPE string,
             c047 TYPE string,
             c048 TYPE string,
             c049 TYPE string,
             c050 TYPE string,
             c051 TYPE string,
             c052 TYPE string,
             c053 TYPE string,
             c054 TYPE string,
             c055 TYPE string,
             c056 TYPE string,
             c057 TYPE string,
             c058 TYPE string,
             c059 TYPE string,
             c060 TYPE string,
             c061 TYPE string,
             c062 TYPE string,
             c063 TYPE string,
             c064 TYPE string,
             c065 TYPE string,
             c066 TYPE string,
             c067 TYPE string,
             c068 TYPE string,
             c069 TYPE string,
             c070 TYPE string,
             c071 TYPE string,
             c072 TYPE string,
             c073 TYPE string,
             c074 TYPE string,
             c075 TYPE string,
             c076 TYPE string,
             c077 TYPE string,
             c078 TYPE string,
             c079 TYPE string,
             c080 TYPE string,
             c081 TYPE string,
             c082 TYPE string,
             c083 TYPE string,
             c084 TYPE string,
             c085 TYPE string,
             c086 TYPE string,
             c087 TYPE string,
             c088 TYPE string,
             c089 TYPE string,
             c090 TYPE string,
             c091 TYPE string,
             c092 TYPE string,
             c093 TYPE string,
             c094 TYPE string,
             c095 TYPE string,
             c096 TYPE string,
             c097 TYPE string,
             c098 TYPE string,
             c099 TYPE string,
             c100 TYPE string,
             c101 TYPE string,
             c102 TYPE string,
             c103 TYPE string,
             c104 TYPE string,
             c105 TYPE string,
             c106 TYPE string,
             c107 TYPE string,
             c108 TYPE string,
             c109 TYPE string,
             c110 TYPE string,
             c111 TYPE string,
             c112 TYPE string,
             c113 TYPE string,
             c114 TYPE string,
             c115 TYPE string,
             c116 TYPE string,
             c117 TYPE string,
             c118 TYPE string,
             c119 TYPE string,
             c120 TYPE string,
             c121 TYPE string,
             c122 TYPE string,
             c123 TYPE string,
             c124 TYPE string,
             c125 TYPE string,
             c126 TYPE string,
             c127 TYPE string,
             c128 TYPE string,
             c129 TYPE string,
             c130 TYPE string,
             c131 TYPE string,
             c132 TYPE string,
             c133 TYPE string,
             c134 TYPE string,
             c135 TYPE string,
             c136 TYPE string,
             c137 TYPE string,
             c138 TYPE string,
             c139 TYPE string,
             c140 TYPE string,
             c141 TYPE string,
             c142 TYPE string,
             c143 TYPE string,
             c144 TYPE string,
             c145 TYPE string,
             c146 TYPE string,
             c147 TYPE string,
             c148 TYPE string,
             c149 TYPE string,
             c150 TYPE string,
             c151 TYPE string,
           END OF ty_xlsx,
           tty_xlsx TYPE STANDARD TABLE OF ty_xlsx.

    CONSTANTS :
      lc_encoding  TYPE abap_encoding VALUE '1100',
      lc_algorithm TYPE string VALUE 'SHA-256'.
    CONSTANTS lc_cid_pre TYPE string VALUE 'Zdata'.

    DATA lt_data_crt TYPE TABLE FOR CREATE yr_ext_uploadexcelui5tp .
    DATA lt_data_crt_tmp TYPE TABLE FOR CREATE yr_ext_uploadexcelui5tp .


    CHECK keys IS NOT INITIAL.

    IF keys[ 1 ]-%param-filecontent IS NOT INITIAL.

      DATA(lv_filecontentbinary) = /ui2/cl_json=>string_to_raw( iv_string   = keys[ 1 ]-%param-filecontent
                                                                iv_encoding = lc_encoding
                                                              ).

      DATA(lo_xlsx) = xco_cp_xlsx=>document->for_file_content( iv_file_content = lv_filecontentbinary )->read_access( ) .
      DATA(lo_worksheet) = lo_xlsx->get_workbook( )->worksheet->at_position( 1 ).

      DATA(lo_selection_pattern) = xco_cp_xlsx_selection=>pattern_builder->simple_from_to( )->get_pattern( ).

      DATA lt_data_xlsx TYPE tty_xlsx.

      DATA(lo_execute) = lo_worksheet->select( lo_selection_pattern
            )->row_stream(
            )->operation->write_to( REF #( lt_data_xlsx ) ).

      lo_execute->set_value_transformation( xco_cp_xlsx_read_access=>value_transformation->string_value
                           )->if_xco_xlsx_ra_operation~execute( ).


      lt_data_crt = VALUE #(
                                 FOR ls_data_xlsx IN lt_data_xlsx FROM 2 INDEX INTO indx
                                                              (
                                                                %cid        = |{ lc_cid_pre }0{ indx - 1 }|
                                                                %is_draft   = if_abap_behv=>mk-off
                                                                %key-mykey1 = ls_data_xlsx-c001
                                                                %key-mykey2 = |{ ls_data_xlsx-c002 }|
                                                                mykey1      = ls_data_xlsx-c001
                                                                mykey2      = |{ ls_data_xlsx-c002 }|
                                                                myfield1    = ls_data_xlsx-c003
                                                                myfield2    = |{ ls_data_xlsx-c004 }|
                                                              )
                           ).

      DELETE lt_data_crt WHERE mykey1 IS INITIAL or mykey2 is INITIAL .

      IF lt_data_crt IS INITIAL .

        APPEND VALUE #(
              %msg        = new_message( EXPORTING        "#EC OPTL_EXP
                                id       = 'YMEXT'
                                number   = 001
                                severity = CONV #( 'E' )
                                                ) ) TO reported-dataupload.

      ELSE .

*        SELECT FROM i_companycode AS s
*        INNER JOIN @lt_data_crt AS z
*        ON s~companycode = z~bukrs
*        FIELDS s~*
*        INTO TABLE @DATA(lt_t001) .
*
*        LOOP AT lt_data_crt INTO DATA(ls_data_crt) .
*          DATA(lv_tabix) = sy-tabix .
*          IF NOT ( line_exists( lt_t001[ companycode = ls_data_crt-bukrs ] ) ).
*            APPEND VALUE #(
*                  %msg        = new_message( EXPORTING    "#EC OPTL_EXP
*                                    id       = 'ZM_RAP_UPLOAD_01'
*                                    number   = 002
*                                    severity = CONV #( 'E' )
*                                    v1 = ls_data_crt-bukrs ) ) TO reported-zdata.
*          ENDIF.
*
*        ENDLOOP.

        CHECK reported-dataupload IS INITIAL .

        MODIFY ENTITIES OF yr_ext_uploadexcelui5tp IN LOCAL MODE
        ENTITY DataUpload
        CREATE AUTO FILL CID  FIELDS ( MyKey1 MyKey2 MyField1 MyField2 )
        WITH lt_data_crt
        MAPPED FINAL(ls_mapped)
        FAILED FINAL(ls_failed_modify_mapped_data)
        REPORTED FINAL(ls_reported_modify_mapped_data).

        APPEND LINES OF ls_failed_modify_mapped_data-dataupload TO failed-dataupload.
        APPEND LINES OF ls_reported_modify_mapped_data-dataupload TO reported-dataupload.
        APPEND LINES OF ls_mapped-dataupload TO mapped-dataupload.

        APPEND VALUE #(
                         %msg        = new_message( EXPORTING "#EC OPTL_EXP
                                           id       = 'YMEXT'
                                           number   = 003
                                           severity = CONV #( 'S' ) ) ) TO reported-dataupload.

      ENDIF.

    ENDIF.

  ENDMETHOD.

ENDCLASS.
