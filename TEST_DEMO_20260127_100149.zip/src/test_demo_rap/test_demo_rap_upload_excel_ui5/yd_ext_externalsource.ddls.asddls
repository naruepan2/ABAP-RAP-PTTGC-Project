@EndUserText.label: 'Abstract External Source'
define abstract entity YD_EXT_ExternalSource
{
  @EndUserText.label            : 'LANGUAGE'
  @Semantics.largeObject: { mimeType: 'Mimetype', fileName: 'Filename', contentDispositionPreference: #INLINE }
  Language    : sylangu;
  @Semantics.mimeType: true
  MimeType    : yemimetype;
  FileName    : yefilename;
  FileContent : yefile_content;
}
