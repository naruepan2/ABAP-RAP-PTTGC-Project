CLASS ycl_demo_data_nw001 DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
ENDCLASS.


CLASS ycl_demo_data_nw001 IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.
    SELECT * FROM i_currency INTO TABLE @FINAL(lt_currrency).
    SELECT * FROM i_companycode INTO TABLE @FINAL(lt_companycode).
    SELECT * FROM i_product INTO TABLE @FINAL(lt_product).

    TYPES: BEGIN OF lts_test1,
             currency    TYPE TABLE OF i_currency WITH EMPTY KEY,
             companycode TYPE TABLE OF i_companycode WITH EMPTY KEY,
             product     TYPE TABLE OF i_product WITH EMPTY KEY,
           END OF lts_test1.

    DATA(ls_test) = VALUE lts_test1( currency    = lt_currrency
                                     companycode = lt_companycode
                                     product     = lt_product ).

    zcl_ext_expimp_buffering_utils=>get_instance( )->export_buffer_data( iv_buffer_name = 'TEST1'
                                                                         iv_data        = ls_test
                                                                         iv_compression = abap_true
    ).

    out->write( 'Done' ).

*    DATA lv_buff1 TYPE xstring.

*    EXPORT t_curr = lt_currrency
*           t_comp = lt_companycode
*        TO DATA BUFFER lv_buff1.

*    DELETE FROM ytb_table_temp01 WHERE buffer_name = 'TEST1'.
*
*    INSERT ytb_table_temp01 FROM @( VALUE #( buffer_name = 'TEST1' buffer_data = lv_buff1 ) ).

*    SELECT SINGLE * FROM ytb_table_temp01 INTO @FINAL(lv_table_temp01).
*
**    DATA lv_buff1 TYPE xstring.
*    DATA lt_currency TYPE TABLE OF i_currency.
*
*    IMPORT t_curr = lt_currency FROM DATA BUFFER lv_table_temp01-buffer_data.
*
*    out->write( lt_currency ).

*    TYPES:
*      BEGIN OF bline,
*        id    TYPE i,
*        clstr TYPE x LENGTH 100,
*      END OF bline.
*
*
*
*    DATA buffer TYPE TABLE OF bline WITH EMPTY KEY.
*    EXPORT itab = lt_currrency TO INTERNAL TABLE buffer.
  ENDMETHOD.
ENDCLASS.
