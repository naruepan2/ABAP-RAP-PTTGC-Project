@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YC_DEMO_COMPANYCODE'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YC_DEMO_PLANTCODE
  provider contract transactional_query
  as projection on YI_DEMO_PLANTCODE
{
  key Plant,
      PlantName,
      ValuationArea,
      PlantCustomer,
      PlantSupplier,
      FactoryCalendar,
      DefaultPurchasingOrganization,
      SalesOrganization,
      AddressID,
      PlantCategory,
      DistributionChannel,
      Division,
      Language,
      IsMarkedForArchiving,
      /* Associations */
      _Customer,
      _StorageLocation,
      _Supplier,
      _MRPArea,
      _ValuationArea
}
