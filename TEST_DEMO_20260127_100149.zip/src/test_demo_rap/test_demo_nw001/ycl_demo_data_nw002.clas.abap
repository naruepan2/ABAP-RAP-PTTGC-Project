CLASS ycl_demo_data_nw002 DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
ENDCLASS.


CLASS ycl_demo_data_nw002 IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.
    " TODO: variable is assigned but only used in commented-out code (ABAP cleaner)
    SELECT SINGLE * FROM ytb_table_temp01 INTO @FINAL(lv_table_temp01).

*    DATA lv_buff1 TYPE xstring.
*    DATA lt_currency TYPE TABLE OF i_currency.
*    DATA lt_companycode TYPE TABLE OF i_companycode.

*    IMPORT t_curr = lt_currency
*           t_comp = lt_companycode
*      FROM DATA BUFFER lv_table_temp01-buffer_data.

    TYPES: BEGIN OF lts_test1,
             currency    TYPE TABLE OF i_currency WITH EMPTY KEY,
             companycode TYPE TABLE OF i_companycode WITH EMPTY KEY,
             product     TYPE TABLE OF i_product WITH EMPTY KEY,
           END OF lts_test1.

    DATA(ls_test) = VALUE lts_test1( ).

    zcl_ext_expimp_buffering_utils=>get_instance( )->import_buffer_data( EXPORTING iv_buffer_name = 'TEST1'
                                                                         IMPORTING ev_data        = ls_test ).

    out->write( ls_test-currency ).
    out->write( ls_test-companycode ).
*    out->write( ls_test-product ).
  ENDMETHOD.
ENDCLASS.
