@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YI_DEMO_COMPANYCODE'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YI_DEMO_PLANTCODE
  as select from I_Plant
  association [0..*] to I_StorageLocation as _StorageLocation on $projection.Plant = _StorageLocation.Plant
{
  key Plant,
      PlantName,
      ValuationArea,
      PlantCustomer,
      PlantSupplier,
      FactoryCalendar,
      DefaultPurchasingOrganization,
      SalesOrganization,
      AddressID,
      PlantCategory,
      DistributionChannel,
      Division,
      Language,
      IsMarkedForArchiving,
      /* Associations */
      _Customer,
      _Supplier,
      _ValuationArea,
      _MRPArea,
      _StorageLocation
}
