*---------------------------------------------------------------------*
*    program for:   TABLEPROC_YTEXT_0004_A
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_YTEXT_0004_A        .

  PERFORM TABLEPROC.

ENDFUNCTION.
