FUNCTION-POOL YTEXT_0004_A               MESSAGE-ID SV.

* INCLUDE LYTEXT_0004_AD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LYTEXT_0004_AT00                        . "view rel. data dcl.
