*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LYTEXT_0004_ATOP.                  " Global Declarations
  INCLUDE LYTEXT_0004_AUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LYTEXT_0004_AF...                  " Subroutines
* INCLUDE LYTEXT_0004_AO...                  " PBO-Modules
* INCLUDE LYTEXT_0004_AI...                  " PAI-Modules
* INCLUDE LYTEXT_0004_AE...                  " Events
* INCLUDE LYTEXT_0004_AP...                  " Local class implement.
* INCLUDE LYTEXT_0004_AT99.                  " ABAP Unit tests
  INCLUDE LYTEXT_0004_AF00                        . " subprograms
  INCLUDE LYTEXT_0004_AI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
