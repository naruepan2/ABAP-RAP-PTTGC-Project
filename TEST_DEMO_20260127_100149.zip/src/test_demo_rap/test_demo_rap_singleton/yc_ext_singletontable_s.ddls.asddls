@EndUserText.label: 'Maintain Singleton Table Singleton'
@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: true
@ObjectModel.semanticKey: [ 'SingletonID' ]
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define root view entity YC_EXT_SingletonTable_S
  provider contract transactional_query
  as projection on YI_EXT_SingletonTable_S
{
  key SingletonID,
  LastChangedAtMax,
  TransportRequestID,
  HideTransport,
  _SingletonTable : redirected to composition child YC_EXT_SingletonTableTP
  
}
