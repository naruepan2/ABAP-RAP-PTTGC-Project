CLASS LHC_RAP_TDAT_CTS DEFINITION FINAL.
  PUBLIC SECTION.
    CLASS-METHODS:
      GET
        RETURNING
          VALUE(ro_result) TYPE REF TO IF_MBC_CP_RAP_TDAT_CTS.

ENDCLASS.

CLASS LHC_RAP_TDAT_CTS IMPLEMENTATION.
  METHOD GET.
*    result = mbc_cp_api=>rap_tdat_cts( tdat_name = 'YDEMOSINGLETONTABLE'
*                                       table_entity_relations = VALUE #(
*                                         ( entity = 'SingletonTable' table = 'YTEXT_0004_A' )
*                                       ) ) ##NO_TEXT.
  ENDMETHOD.
ENDCLASS.
CLASS LHC_YI_EXT_SINGLETONTABLE_S DEFINITION FINAL INHERITING FROM CL_ABAP_BEHAVIOR_HANDLER.
  PRIVATE SECTION.
    METHODS:
      GET_INSTANCE_FEATURES FOR INSTANCE FEATURES
        IMPORTING
          KEYS REQUEST requested_features FOR SingletonTabAll
        RESULT result,
*      SELECTCUSTOMIZINGTRANSPTREQ FOR MODIFY
*        IMPORTING
*          KEYS FOR ACTION SingletonTabAll~SelectCustomizingTransptReq
*        RESULT result,
      GET_GLOBAL_AUTHORIZATIONS FOR GLOBAL AUTHORIZATION
        IMPORTING
           REQUEST requested_authorizations FOR SingletonTabAll
        RESULT result.
ENDCLASS.

CLASS LHC_YI_EXT_SINGLETONTABLE_S IMPLEMENTATION.
  METHOD GET_INSTANCE_FEATURES.
    DATA: lv_selecttransport_flag TYPE abp_behv_flag VALUE if_abap_behv=>fc-o-enabled,
          lv_edit_flag            TYPE abp_behv_flag VALUE if_abap_behv=>fc-o-enabled.

*    IF lhc_rap_tdat_cts=>get( )->is_editable( ) = abap_false.
*      edit_flag = if_abap_behv=>fc-o-disabled.
*    ENDIF.
*    IF lhc_rap_tdat_cts=>get( )->is_transport_allowed( ) = abap_false.
*      selecttransport_flag = if_abap_behv=>fc-o-disabled.
*    ENDIF.
    READ ENTITIES OF YI_EXT_SingletonTable_S IN LOCAL MODE
    ENTITY SingletonTabAll
      ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_all).
    IF lt_all[ 1 ]-%IS_DRAFT = if_abap_behv=>mk-off.
      lv_selecttransport_flag = if_abap_behv=>fc-o-disabled.
    ENDIF.
    result = VALUE #( (
               %TKY = lt_all[ 1 ]-%TKY
               %ACTION-edit = lv_edit_flag
               %ASSOC-_SingletonTable = lv_edit_flag
*               %ACTION-SelectCustomizingTransptReq = selecttransport_flag
               ) ).
  ENDMETHOD.
*  METHOD SELECTCUSTOMIZINGTRANSPTREQ.
*    MODIFY ENTITIES OF YI_EXT_SingletonTable_S IN LOCAL MODE
*      ENTITY SingletonTabAll
*        UPDATE FIELDS ( TransportRequestID HideTransport )
*        WITH VALUE #( FOR key IN keys
*                        ( %TKY               = key-%TKY
*                          TransportRequestID = key-%PARAM-transportrequestid
*                          HideTransport      = abap_false ) ).
*
*    READ ENTITIES OF YI_EXT_SingletonTable_S IN LOCAL MODE
*      ENTITY SingletonTabAll
*        ALL FIELDS WITH CORRESPONDING #( keys )
*        RESULT DATA(entities).
*    result = VALUE #( FOR entity IN entities
*                        ( %TKY   = entity-%TKY
*                          %PARAM = entity ) ).
*  ENDMETHOD.
  METHOD GET_GLOBAL_AUTHORIZATIONS.
    AUTHORITY-CHECK OBJECT 'S_TABU_NAM' ID 'TABLE' FIELD 'YR_EXT_SINGLETONTABLETP' ID 'ACTVT' FIELD '02'.
    DATA(lv_authorized) = COND #( WHEN sy-subrc = 0 THEN if_abap_behv=>auth-allowed
                                  ELSE if_abap_behv=>auth-unauthorized ).
    result-%UPDATE      = lv_authorized.
    result-%ACTION-Edit = lv_authorized.
*    result-%ACTION-SelectCustomizingTransptReq = is_authorized.
  ENDMETHOD.
ENDCLASS.
CLASS LSC_YI_EXT_SINGLETONTABLE_S DEFINITION FINAL INHERITING FROM CL_ABAP_BEHAVIOR_SAVER.
  PROTECTED SECTION.
    METHODS:
      SAVE_MODIFIED REDEFINITION,
      CLEANUP_FINALIZE REDEFINITION.
ENDCLASS.

CLASS LSC_YI_EXT_SINGLETONTABLE_S IMPLEMENTATION.
  METHOD SAVE_MODIFIED.
    READ TABLE update-SingletonTabAll INDEX 1 INTO DATA(ls_all).
    IF ls_all-TransportRequestID IS NOT INITIAL.
      lhc_rap_tdat_cts=>get( )->record_changes(
                                  transport_request = ls_all-TransportRequestID
                                  create            = REF #( create )
                                  update            = REF #( update )
                                  delete            = REF #( delete ) ).
    ENDIF.
  ENDMETHOD.
  METHOD CLEANUP_FINALIZE ##NEEDED.
  ENDMETHOD.
ENDCLASS.
CLASS LHC_YR_EXT_SINGLETONTABLETP DEFINITION FINAL INHERITING FROM CL_ABAP_BEHAVIOR_HANDLER.
  PRIVATE SECTION.
    METHODS:
*      VALIDATETRANSPORTREQUEST FOR VALIDATE ON SAVE
*        IMPORTING
*          KEYS FOR SingletonTable~ValidateTransportRequest,
      GET_GLOBAL_FEATURES FOR GLOBAL FEATURES
        IMPORTING
          REQUEST REQUESTED_FEATURES FOR SingletonTable
        RESULT result.
ENDCLASS.

CLASS LHC_YR_EXT_SINGLETONTABLETP IMPLEMENTATION.
*  METHOD VALIDATETRANSPORTREQUEST.
*    DATA change TYPE REQUEST FOR CHANGE YI_EXT_SingletonTable_S.
*    SELECT SINGLE TransportRequestID
*      FROM YTEXT_0004_S
*      WHERE SingletonID = 1
*      INTO @DATA(TransportRequestID).
*    lhc_rap_tdat_cts=>get( )->validate_changes(
*                                transport_request = TransportRequestID
*                                table             = 'YTEXT_0004_A'
*                                keys              = REF #( keys )
*                                reported          = REF #( reported )
*                                failed            = REF #( failed )
*                                change            = REF #( change-SingletonTable ) ).
*  ENDMETHOD.
  METHOD GET_GLOBAL_FEATURES.
    DATA lv_edit_flag TYPE abp_behv_flag VALUE if_abap_behv=>fc-o-enabled.
*    IF lhc_rap_tdat_cts=>get( )->is_editable( ) = abap_false.
*      edit_flag = if_abap_behv=>fc-o-disabled.
*    ENDIF.
    result-%UPDATE = lv_edit_flag.
    result-%DELETE = lv_edit_flag.
  ENDMETHOD.
ENDCLASS.
