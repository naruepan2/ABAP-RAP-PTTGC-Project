@EndUserText.label: 'Singleton Table Singleton'
@AccessControl.authorizationCheck: #NOT_REQUIRED
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define root view entity YI_EXT_SingletonTable_S
  as select from I_Language
    left outer join ytext_0004_a on 0 = 0
  composition [0..*] of YR_EXT_SingletonTableTP as _SingletonTable
{
  key 1 as SingletonID,
  _SingletonTable,
  max( ytext_0004_a.last_changed_at ) as LastChangedAtMax,
  cast( '' as sxco_transport) as TransportRequestID,
  cast( 'X' as abap_boolean preserving type) as HideTransport
  
}
where I_Language.Language = $session.system_language
