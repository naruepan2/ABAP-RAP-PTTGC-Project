class YBP_EXT_SINGLETONTABLE_S definition
  public
  abstract
  final
  for behavior of YI_EXT_SINGLETONTABLE_S .

public section.
protected section.
private section.
ENDCLASS.



CLASS YBP_EXT_SINGLETONTABLE_S IMPLEMENTATION.
ENDCLASS.
