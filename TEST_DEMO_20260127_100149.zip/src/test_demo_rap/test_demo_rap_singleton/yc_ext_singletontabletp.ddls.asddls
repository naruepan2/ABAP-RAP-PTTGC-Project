@EndUserText.label: 'Maintain Singleton Table'
@AccessControl.authorizationCheck: #CHECK
@Metadata.allowExtensions: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity YC_EXT_SingletonTableTP
  as projection on YR_EXT_SingletonTableTP
//  association [0..1] to YC_TEST_CUSTOMENTITY_ROOT_CE as _TEST_CUSTOMENTITY_ROOT_CE on $projection.SingletonID = _TEST_CUSTOMENTITY_ROOT_CE.KeySingleton
{
  key MyKey1,
  key MyKey2,
  MyField1,
  MyField2,
  LocalCreatedBy,
  LocalCreatedAt,
  @Consumption.hidden: true
  LocalLastChangedBy,
  @Consumption.hidden: true
  LocalLastChangedAt,
  LastChangedAt,
  @Consumption.hidden: true
  SingletonID,
  _SingletonTabAll : redirected to parent YC_EXT_SingletonTable_S
//  _TEST_CUSTOMENTITY_ROOT_CE
  
}
