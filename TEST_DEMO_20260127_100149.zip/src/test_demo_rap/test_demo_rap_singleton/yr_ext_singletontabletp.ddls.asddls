@EndUserText.label: 'Singleton Table'
@AccessControl.authorizationCheck: #CHECK
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity YR_EXT_SingletonTableTP
  as select from ytext_0004_a
  association to parent YI_EXT_SingletonTable_S as _SingletonTabAll on $projection.SingletonID = _SingletonTabAll.SingletonID
{

  key my_key1               as MyKey1,
  key my_key2               as MyKey2,
      my_field1             as MyField1,
      my_field2             as MyField2,
      @Semantics.user.createdBy: true
      local_created_by      as LocalCreatedBy,
      @Semantics.systemDateTime.createdAt: true
      local_created_at      as LocalCreatedAt,
      @Semantics.user.localInstanceLastChangedBy: true
      local_last_changed_by as LocalLastChangedBy,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at as LocalLastChangedAt,
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at       as LastChangedAt,
      1                     as SingletonID,
      _SingletonTabAll

}
