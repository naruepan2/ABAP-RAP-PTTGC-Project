*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: YTEXT_0004_A....................................*
DATA:  BEGIN OF STATUS_YTEXT_0004_A                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_YTEXT_0004_A                  .
CONTROLS: TCTRL_YTEXT_0004_A
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *YTEXT_0004_A                  .
TABLES: YTEXT_0004_A                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
