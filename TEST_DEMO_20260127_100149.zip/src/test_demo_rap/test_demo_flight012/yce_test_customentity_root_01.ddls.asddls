@EndUserText.label: 'YUI_TEST_CUSTOMENTITY_ROOT'
@ObjectModel.query.implementedBy: 'ABAP:YCL_TEST_CUSTOMENTITY002'

@UI.headerInfo: { typeName: 'Custom Entity',
                  typeNamePlural: 'Custom Entities'
                }

define root custom entity YCE_TEST_CUSTOMENTITY_ROOT_01
{
      @UI.facet          : [{ position: 10,
                    id   : 'generalID',
                    label: 'General Information',
                    purpose: #STANDARD,
                    type : #IDENTIFICATION_REFERENCE },
                  { position: 20,
                    id   : 'ChildID',
                    label: 'Child Information',
                    purpose: #STANDARD,
                    type : #LINEITEM_REFERENCE,
                    targetElement: '_Child' } ]

      @UI.lineItem       : [{ position: 10 }]
      @UI.identification : [{ position: 10 }]
  key PurchaseOrder      : ebeln;
      @UI.lineItem       : [{ position: 20 }]
      @UI.identification : [{ position: 20 }]
      Vendor             : lifnr;

//      @Semantics.systemDateTime.lastChangedAt: true
//      LastChangedAt      : abp_locinst_lastchange_tstmpl;
//      @Semantics.systemDateTime.localInstanceLastChangedAt: true
//      LocalLastChangedAt : abp_locinst_lastchange_tstmpl;

      _Child             : composition [0..*] of YCE_TEST_CUSTOMENTITY_CHILD_01;

}
