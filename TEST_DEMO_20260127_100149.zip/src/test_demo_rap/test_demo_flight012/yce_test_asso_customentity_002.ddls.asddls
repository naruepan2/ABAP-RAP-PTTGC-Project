@AccessControl.authorizationCheck: #NOT_REQUIRED

@EndUserText.label: 'YCE_TEST_ASSO_CUSTOMENTITY_002'

@UI.headerInfo: { typeName: 'Custom Entity', typeNamePlural: 'Custom Entities' }

define root view entity YCE_TEST_ASSO_CUSTOMENTITY_002
  as projection on YCE_TEST_ASSO_CUSTOMENTITY_001

  association [0..*] to YCE_TEST_CUSTOMENTITY_ROOT_01 as _TEST_CUSTOMENTITY_ROOT_01 on $projection.PurchaseOrder = _TEST_CUSTOMENTITY_ROOT_01.PurchaseOrder
                                                                             
{
      @UI.facet: [ { position: 10,
                     id: 'generalID',
                     label: 'General Information',
                     purpose: #STANDARD,
                     type: #IDENTIFICATION_REFERENCE } ]
      @UI.identification: [ { position: 10 } ]
      @UI.lineItem: [ { position: 10 } ]
  key PurchaseOrder,

      @UI.identification: [ { position: 20 } ]
      @UI.lineItem: [ { position: 20 } ]
      PurchaseOrderType,

      @UI.identification: [ { position: 30 } ]
      @UI.lineItem: [ { position: 30 } ]
      PurchaseOrderSubtype,

      @UI.identification: [ { position: 40 } ]
      @UI.lineItem: [ { position: 40 } ]
      PurchasingDocumentOrigin,

      @UI.identification: [ { position: 50 } ]
      @UI.lineItem: [ { position: 50 } ]
      CreatedByUser,

      @UI.identification: [ { position: 60 } ]
      @UI.lineItem: [ { position: 60 } ]
      CreationDate,
      PurchaseOrderDate,

      _TEST_CUSTOMENTITY_ROOT_01
}
