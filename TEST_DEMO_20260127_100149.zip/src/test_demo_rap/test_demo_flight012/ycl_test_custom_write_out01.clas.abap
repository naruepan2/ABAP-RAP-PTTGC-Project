CLASS ycl_test_custom_write_out01 DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
ENDCLASS.


CLASS ycl_test_custom_write_out01 IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.
    DATA(lo_entity) = xco_cp_cds=>custom_entity( 'YCE_TEST_CUSTOMENTITY_ROOT_01' ).
    DATA(lt_names) = lo_entity->fields->all->get_names( ).

    LOOP AT lt_names INTO DATA(ls_name).
      DATA(lo_field) = lo_entity->field( ls_name ).
      lo_field->content( )->get_alias(
*        RECEIVING
*          rv_alias =
      )..
    ENDLOOP.


  ENDMETHOD.
ENDCLASS.
