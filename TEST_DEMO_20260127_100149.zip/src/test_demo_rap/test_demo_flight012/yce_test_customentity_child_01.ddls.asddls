@EndUserText.label: 'YUI_TEST_CUSTOMENTITY_CHILD'
@ObjectModel.query.implementedBy: 'ABAP:YCL_TEST_CUSTOMENTITY002'
define custom entity YCE_TEST_CUSTOMENTITY_CHILD_01

{
      @UI.lineItem       : [{ position: 10 }]
      @UI.identification : [{ position: 10 }]
  key PurchaseOrder      : ebeln;
      @UI.lineItem       : [{ position: 20 }]
      @UI.identification : [{ position: 20 }]
  key PurchaseOrderItem  : ebelp;
      @UI.lineItem       : [{ position: 30 }]
      @UI.identification : [{ position: 30 }]
      Vendor             : lifnr;
      @UI.lineItem       : [{ position: 40 }]
      @UI.identification : [{ position: 40 }]
      Material           : matnr;
      @UI.lineItem       : [{ position: 50 }]
      @UI.identification : [{ position: 50 }]
      Plant              : werks_d;
      @UI.lineItem       : [{ position: 60 }]
      @UI.identification : [{ position: 60 }]
      Location           : lgort_d;
      @UI.lineItem       : [{ position: 70 }]
      @UI.identification : [{ position: 70 }]
      @Semantics.quantity.unitOfMeasure: 'Unit'
      Quantity           : menge_d;
      @UI.lineItem       : [{ position: 80 }]
      @UI.identification : [{ position: 80 }]
      Unit               : meins;
      @UI.lineItem       : [{ position: 90 }]
      @UI.identification : [{ position: 90 }]
      IsHidden           : abap_boolean;

//      @Semantics.systemDateTime.lastChangedAt: true
//      LastChangedAt      : abp_locinst_lastchange_tstmpl;
//      @Semantics.systemDateTime.localInstanceLastChangedAt: true
//      LocalLastChangedAt : abp_locinst_lastchange_tstmpl;

      _Parent            : association to parent YCE_TEST_CUSTOMENTITY_ROOT_01 on $projection.PurchaseOrder = _Parent.PurchaseOrder;
}
