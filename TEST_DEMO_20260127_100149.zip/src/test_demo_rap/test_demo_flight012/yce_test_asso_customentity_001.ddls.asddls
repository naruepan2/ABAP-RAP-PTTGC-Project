@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YCE_TEST_ASSO_CUSTOMENTITY_001'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YCE_TEST_ASSO_CUSTOMENTITY_001
  as select from I_PurchaseOrderAPI01
{
  key I_PurchaseOrderAPI01.PurchaseOrder,
      I_PurchaseOrderAPI01.PurchaseOrderType,
      I_PurchaseOrderAPI01.PurchaseOrderSubtype,
      I_PurchaseOrderAPI01.PurchasingDocumentOrigin,
      I_PurchaseOrderAPI01.CreatedByUser,
      I_PurchaseOrderAPI01.CreationDate,
      I_PurchaseOrderAPI01.PurchaseOrderDate
}
where
  PurchaseOrder = '1050000091'
