@AccessControl.authorizationCheck: #CHECK
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for ZR_YTEXT_0013_A'
@ObjectModel.semanticKey: [ 'TravelID' ]
define root view entity ZC_YTEXT_0013_A
  provider contract transactional_query
  as projection on ZR_YTEXT_0013_A
{
  key TravelID,
  AgencyID,
  CustomerID,
  BeginDate,
  EndDate,
  BookingFee,
  TotalPrice,
  CurrencyCode,
  Description,
  LocalLastChangedAt
  
}
