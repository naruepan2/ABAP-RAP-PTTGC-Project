class ZBP_YTEXT_0013_A definition
  public
  abstract
  final
  for behavior of ZR_YTEXT_0013_A .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZBP_YTEXT_0013_A IMPLEMENTATION.
ENDCLASS.
