@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'INVENTORY CONSUMPATION VIEW'
@Metadata.ignorePropagatedAnnotations: true

define root view entity YSCN_C_INVENTORY
  provider contract transactional_query
  as projection on YSCN_i_INVENTORY
{
      @UI.facet: [{ type: #IDENTIFICATION_REFERENCE }]

      @UI.lineItem: [{ position: 10 , label: 'Product Id' }]
      @UI.identification:[{ position: 10 , label: 'Product Id' }]
  key ProductId,
      @UI.lineItem: [{ position: 20 , label: 'Stock Level' }]
      @UI.identification:[{ position: 20 , label: 'Stock Level' }]
      StockLevel,
      @UI.lineItem: [{ position: 30 , label: 'Product Name' }]
      @UI.identification:[{ position: 30 , label: 'Product Name' }]
      ProductName,
      @Semantics.systemDateTime.createdAt: true
      CreateAt,
      @Semantics.systemDateTime.lastChangedAt: true
      LastChdate
}
