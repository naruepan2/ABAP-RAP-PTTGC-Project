@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'SALESORD CONSUMPATION VIEW'
@Metadata.ignorePropagatedAnnotations: true

define root view entity YSCN_C_SALESORD
  provider contract transactional_query
  as projection on YSCN_I_SALESORD
{
      @UI.facet: [{ type: #IDENTIFICATION_REFERENCE }]

      @UI.lineItem: [{ position: 10 , label: 'Sales Order Id' }]
      @UI.identification:[{ position: 10 , label: 'Sales Order Id' }]
  key SalesOrderId,
      @UI.lineItem: [{ position: 20 , label: 'Product Id' }]
      @UI.identification:[{ position: 20 , label: 'Product Id' }]
      @Consumption.valueHelpDefinition: [{
      entity: { name: 'YSCN_C_INVENTORY', element: 'ProductId' } }]
      ProductId,
      @UI.lineItem: [{ position: 30 , label: 'Quantity' }]
      @UI.identification:[{ position: 30 , label: 'Quantity' }]
      Quantity,
      @UI.lineItem: [{ position: 40 , label: 'Customer Id' }]
      @UI.identification:[{ position: 40 , label: 'Customer Id' }]
      CustomerId,
      @UI.lineItem: [{ position: 50 , label: 'Order Date' }]
      @UI.identification:[{ position: 50 , label: 'Order Date' }]
      OrderDate,
      @UI.lineItem: [{ position: 60 , label: 'Total Amount' }]
      @UI.identification:[{ position: 60 , label: 'Total Amount' }]
      @Semantics.amount.currencyCode: 'Currency'
      TotalAmount,
      Currency,
      @Semantics.systemDateTime.createdAt: true
      CreateAt,
      @Semantics.systemDateTime.lastChangedAt: true
      LastChanged
}
