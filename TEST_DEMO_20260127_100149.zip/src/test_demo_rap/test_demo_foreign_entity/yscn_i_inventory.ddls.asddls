@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'INTERFACE VIEW INVERNTORY'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YSCN_i_INVENTORY
  as select from yscn_t_inventory
{
  key product_id   as ProductId,
      stock_level  as StockLevel,
      product_name as ProductName,
      create_at    as CreateAt,
      last_chdate  as LastChdate
}
