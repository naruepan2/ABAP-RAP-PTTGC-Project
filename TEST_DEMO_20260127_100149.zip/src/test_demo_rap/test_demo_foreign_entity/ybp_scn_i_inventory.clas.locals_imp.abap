CLASS lhc_yscn_i_inventory DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR yscn_i_inventory RESULT result.

    METHODS vali_stock FOR VALIDATE ON SAVE
      IMPORTING keys FOR yscn_i_inventory~vali_stock.

ENDCLASS.


CLASS lhc_yscn_i_inventory IMPLEMENTATION.
  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD vali_stock.
    READ ENTITY IN LOCAL MODE yscn_i_inventory
         ALL FIELDS WITH CORRESPONDING #( keys )
         RESULT DATA(lt_result).

    LOOP AT lt_result INTO DATA(lv_result).
      IF lv_result-stocklevel < 0.
        APPEND VALUE #( %tky = lv_result-%tky  ) TO failed-yscn_i_inventory.

        APPEND VALUE #( %tky                = lv_result-%tky
                        %msg                = new_message_with_text(
                            severity = if_abap_behv_message=>severity-error
                            text     = |Stock value should not be negative value{ lv_result-stocklevel }| )
                        %element-stocklevel = if_abap_behv=>mk-on  ) TO reported-yscn_i_inventory.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.


CLASS lsc_yscn_i_inventory DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.
    METHODS adjust_numbers   REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.


CLASS lsc_yscn_i_inventory IMPLEMENTATION.
  METHOD adjust_numbers.
    IF mapped-yscn_i_inventory IS NOT INITIAL.

      SELECT FROM yscn_t_inventory
        FIELDS product_id
        ORDER BY product_id DESCENDING
        INTO @DATA(lv_product_id)
        UP TO 1 ROWS.
      ENDSELECT.

      LOOP AT mapped-yscn_i_inventory ASSIGNING FIELD-SYMBOL(<yscn_i_inventory>).
        lv_product_id += 1.
        <yscn_i_inventory>-productid = lv_product_id.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.

  METHOD cleanup_finalize.
  ENDMETHOD.
ENDCLASS.
