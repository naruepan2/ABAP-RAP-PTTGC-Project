CLASS lhc_yscn_i_salesord DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR yscn_i_salesord RESULT result.

    METHODS earlynumbering_create FOR NUMBERING
      IMPORTING entities FOR CREATE yscn_i_salesord.

    METHODS stock_upadte FOR DETERMINE ON SAVE
      IMPORTING keys FOR yscn_i_salesord~stock_upadte.
    METHODS valid_productid FOR VALIDATE ON SAVE
      IMPORTING keys FOR yscn_i_salesord~valid_productid.

ENDCLASS.


CLASS lhc_yscn_i_salesord IMPLEMENTATION.
  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD earlynumbering_create.
    SELECT FROM yscn_dt_salesord
      FIELDS sales_order_id
      ORDER BY sales_order_id DESCENDING
      INTO @DATA(lv_sales_order_id)
      UP TO 1 ROWS.
    ENDSELECT.

    LOOP AT entities ASSIGNING FIELD-SYMBOL(<ls_entity>).
      lv_sales_order_id += 1.

      INSERT VALUE #( %cid         = <ls_entity>-%cid
                      %is_draft    = <ls_entity>-%is_draft
                      SalesOrderID = lv_sales_order_id  ) INTO TABLE mapped-yscn_i_salesord.
    ENDLOOP.
  ENDMETHOD.

  METHOD stock_upadte.
    READ ENTITY IN LOCAL MODE yscn_i_salesord
         ALL FIELDS WITH CORRESPONDING #( keys )
         RESULT DATA(lt_result).

    LOOP AT lt_result INTO DATA(lv_result).
      READ ENTITY yscn_i_inventory
           ALL FIELDS WITH VALUE #( ( productid = lv_result-productid ) )
           RESULT DATA(lt_result_inventory).

      LOOP AT lt_result_inventory INTO DATA(lv_inventory).

        DATA(lv_stock) = CONV i( lv_inventory-stocklevel - lv_result-quantity ).

        MODIFY ENTITY yscn_i_inventory UPDATE FIELDS ( stocklevel )
               WITH VALUE #( ( %key-productid = lv_inventory-%key-productid
                               stocklevel     = lv_stock ) ) REPORTED DATA(ltreported).

        IF ltreported IS NOT INITIAL.
          DATA lt_dummy LIKE reported-_inventory.
          lt_dummy = CORRESPONDING #( ltreported-yscn_i_inventory ).

          APPEND LINES OF lt_dummy TO reported-_inventory.
        ENDIF.
      ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD valid_productid.
    READ ENTITY IN LOCAL MODE yscn_i_salesord
         ALL FIELDS WITH CORRESPONDING #( keys )
         RESULT DATA(lt_result).

    LOOP AT lt_result INTO DATA(lv_result).
      READ ENTITY yscn_i_inventory
           ALL FIELDS WITH VALUE #( ( productid = lv_result-productid ) )
           RESULT DATA(lt_result_inventory)
           FAILED DATA(ls_failed_inventory).

      IF ls_failed_inventory-yscn_i_inventory IS NOT INITIAL.
*        failed-yscn_i_salesord = CORRESPONDING #( DEEP ls_failed_inventory-yscn_i_inventory ).
*        reported-yscn_i_salesord = VALUE #( ( %msg               = new_message_with_text(
*                                                                       severity = if_abap_behv_message=>severity-error
*                                                                       text     = 'Product Id is not found' )
*                                              %element-productid = if_abap_behv=>mk-on ) ).

        failed-_inventory = CORRESPONDING #( ls_failed_inventory-yscn_i_inventory ).
        reported-_inventory = VALUE #( ( %msg               = new_message_with_text(
                                                                  severity = if_abap_behv_message=>severity-error
                                                                  text     = 'Product Id is not found' )
                                         %element-productid = if_abap_behv=>mk-on ) ).
      ELSEIF lt_result_inventory IS INITIAL.
*        failed-yscn_i_salesord = VALUE #( ( %fail-cause = if_abap_behv=>cause-not_found ) ).
*        reported-yscn_i_salesord = VALUE #( ( %msg               = new_message_with_text(
*                                                                       severity = if_abap_behv_message=>severity-error
*                                                                       text     = 'Product Id is not found' )
*                                              %element-productid = if_abap_behv=>mk-on ) ).

        failed-_inventory = VALUE #( ( %fail-cause = if_abap_behv=>cause-not_found ) ).
        reported-_inventory = VALUE #( ( %msg               = new_message_with_text(
                                                                  severity = if_abap_behv_message=>severity-error
                                                                  text     = 'Product Id is not found' )
                                         %element-productid = if_abap_behv=>mk-on ) ).
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
