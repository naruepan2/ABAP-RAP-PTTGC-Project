@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'SALESORD INTERFACE VIEW'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YSCN_I_SALESORD
  as select from yscn_dt_salesord

  association [1..1] to YSCN_i_INVENTORY as _INVENTORY on $projection.ProductId = _INVENTORY.ProductId

{
  key sales_order_id as SalesOrderId,
      product_id     as ProductId,
      quantity       as Quantity,
      customer_id    as CustomerId,
      order_date     as OrderDate,
      @Semantics.amount.currencyCode: 'Currency'
      total_amount   as TotalAmount,
      currency       as Currency,
      create_at      as CreateAt,
      last_changed   as LastChanged,

      _INVENTORY
}
