CLASS ycl_scn_salesord_test DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
ENDCLASS.


CLASS ycl_scn_salesord_test IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.
    SELECT FROM yscn_i_salesord
      FIELDS yscn_i_salesord~salesorderid,
             yscn_i_salesord~productid,
             yscn_i_salesord~quantity,
             yscn_i_salesord~customerid,
             yscn_i_salesord~orderdate,
             yscn_i_salesord~totalamount,
             yscn_i_salesord~\_inventory-stocklevel

      INTO TABLE @DATA(lt_salesord).

    out->write( lt_salesord ).
  ENDMETHOD.
ENDCLASS.
