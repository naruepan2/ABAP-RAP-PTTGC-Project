@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Managed Query'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
  serviceQuality: #X,
  sizeCategory: #S,
  dataClass: #MIXED
}
define view entity YA_EXT_DemoSimpleManageQuery
  as select from    I_Language as Lang
    inner join      YI_CALENDARDATEFUNCBYDATE(
                    p_date     : $session.system_date,
                    p_language : $session.system_language
                    )          as _Cal     on _Cal.Today = $session.system_date
    left outer join I_Currency as Currency on Currency.Currency = 'USD4'
{
      @Consumption.filter.mandatory: true
      //      @Consumption.filter.selectionType: #INTERVAL
      //      @Consumption.filter.multipleSelections: false
  key Lang.Language,
      Lang.LanguageISOCode,
      //      cast( Currency.Currency as abap.sstring(5) ) as Currr,
      @EndUserText.label: 'Source Currency'
      cast(
        case Currency.Currency
          when 'ZZZZZ' then ''
            else Currency.Currency
        end as abap.char(5)  )  as Currency2,
      @EndUserText.label: 'Source Currency'
      cast(
        concat( '', Currency.Currency )
        as abap.char(5)  )  as Currency3,
      Currency.Currency,
      Currency.Decimals,
      Currency.CurrencyISOCode,
      Currency.AlternativeCurrencyKey,
      Currency.IsPrimaryCurrencyForISOCrcy,
      /* Associations */
      Lang._Text,
      _Cal.Today                                                 as CurrentDate,
      _Cal.currenTime                                            as Currenttime,
      cast( _Cal.currentTimeStamp as timestamp preserving type ) as CurrentTimestamp
}
