@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YC_DEMO_MONTHTP'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YC_DEMO_MONTHTP
  provider contract transactional_query
  as projection on YI_DEMO_MONTHTP
{

      @Consumption.valueHelpDefinition: [ { entity: { name: 'YI_DEMO_MONTHVH', element: 'CalendarMonth' },
                                            useForValidation: true } ]
      @UI.lineItem: [{ position: 10 }]
      @UI.identification: [{ position: 10 }]
      @UI.selectionField: [{ position: 10 }]
      @Consumption.filter.selectionType: #SINGLE
  key CalendarMonth,
      @UI.lineItem: [{ position: 20 }]
      @UI.identification: [{ position: 20 }]
      CalendarMonthName,
      /* Associations */
      _Text
}
