@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YI_DEMO_MONTHVH'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.resultSet.sizeCategory: #XS
define view entity YI_DEMO_MONTHVH
  as select from I_CalendarMonthVH
{
      @ObjectModel.text.element: [ 'CalendarMonthName' ]
      @UI.textArrangement: #TEXT_LAST
      //      @ObjectModel.text.association: '_Text'
  key CalendarMonth,

      @Semantics.text: true
      concat('Test',CalendarMonth) as CalendarMonthName
      //      _Text[ exact one to exact one: Language = $session.system_language].CalendarMonthName as CalendarMonthName,
      //
      //      /* Associations */
      //      _Text
}
