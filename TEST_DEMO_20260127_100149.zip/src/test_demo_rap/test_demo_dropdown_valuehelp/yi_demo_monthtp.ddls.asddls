@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YI_DEMO_MONTHTP'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YI_DEMO_MONTHTP
  as select from I_CalendarMonth
{
  key CalendarMonth,
      @Semantics.text: true
      _Text[ exact one to exact one: Language = $session.system_language].CalendarMonthName as CalendarMonthName,
      /* Associations */
      _Text
}
