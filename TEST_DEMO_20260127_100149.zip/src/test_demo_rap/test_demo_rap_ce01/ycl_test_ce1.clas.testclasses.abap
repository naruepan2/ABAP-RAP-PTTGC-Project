*"* use this source file for your ABAP unit test classes
class ltcl_ definition final for testing
  duration short
  risk level harmless.

  private section.
    methods:
      first_test for testing raising cx_static_check.
endclass.


class ltcl_ implementation.

  method first_test.



*  cl_xco_cp_gen_ddls_template_fc
  xco_cp_ddl=>data_source->entity(
    EXPORTING
      iv_entity             = 'YCE_TEST_CE1_ROOT'
    RECEIVING
      ro_entity_data_source = data(data_source)
  ).

  data_source->set_alias(
    EXPORTING
      iv_alias = 'TEST'
    RECEIVING
      ro_me    = data(ro_me)
  ).


  DATA(lo_tabdescr) = CAST cl_abap_tabledescr(
      cl_abap_typedescr=>describe_by_name( p_name = 'YCE_TEST_CE1_ROOT' )
    ).

    data(keyyy) = lo_tabdescr->get_keys(
*      RECEIVING
*        p_keys =
    ).
*  XCO_GENERATION_DDLS=>option->
*  cl_dd_ddl_handler=>if_dd_ddl_handler~read_technical_settings(
*    EXPORTING
**      get_state       = 'M'
**      prid            = 0
*      name            = 'YCE_TEST_CE1_ROOT'
**    IMPORTING
**      ddddlsrc09bv_wa =
**      got_state       =
*  ).
*  CATCH cx_dd_ddl_read.
*  XCO_CP_DDL
*XCO_CP_GENERATION_DDLS
*XCO_CP_DDL=>
*  data ldata tyPE ref to data .
*
*  create ldata
*   ZCL_EXT_ABAP_UTILITIES=>get_dynamic_descr(
*     EXPORTING
*       ir_data        =
**     IMPORTING
**       eo_object      =
**       ev_object_name =
**       et_components  =
*   ).
*data(ro_table_desc) = ZCL_EXT_ABAP_UTILITIES=>get_table_desc_from_view(
*  EXPORTING
*    iv_view       = 'YCE_TEST_CE1_ROOT'
**  RECEIVING
**    ro_table_desc =
*).
  endmethod.

endclass.
