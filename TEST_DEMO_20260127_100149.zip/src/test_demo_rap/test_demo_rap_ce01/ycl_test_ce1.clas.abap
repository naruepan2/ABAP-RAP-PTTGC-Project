CLASS ycl_test_ce1 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_rap_query_provider .

    TYPES: BEGIN OF ts_header,
             purchaseorder TYPE i_purchaseorderapi01-purchaseorder,
             supplier      TYPE i_purchaseorderapi01-supplier,
           END OF ts_header.
    TYPES: BEGIN OF ts_items,
             purchaseorder             TYPE i_purchaseorderitemapi01-purchaseorder,
             purchaseorderitem         TYPE i_purchaseorderitemapi01-purchaseorderitem,
             vendor                    TYPE i_purchaseorderapi01-supplier,
             material                  TYPE i_purchaseorderitemapi01-material,
             plant                     TYPE i_purchaseorderitemapi01-plant,
             location                  TYPE i_purchaseorderitemapi01-storagelocation,
             orderquantity             TYPE i_purchaseorderitemapi01-orderquantity,
             purchaseorderquantityunit TYPE i_purchaseorderitemapi01-purchaseorderquantityunit,
           END OF ts_items.

    DATA: mt_header TYPE STANDARD TABLE OF ts_header.
    DATA: mt_items TYPE STANDARD TABLE OF ts_items.

  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_test_ce1 IMPLEMENTATION.


  METHOD if_rap_query_provider~select.
    DATA lt_output_parent TYPE TABLE OF yce_test_customentity_root_01.
    DATA lt_output_child TYPE TABLE OF yce_test_customentity_child_01.

*    DATA(lo_entity) = xco_cp_cds=>entity( iv_name = 'YCE_TEST_CE1_ROOT' ).
*    if lo_entity is BOUND.
*        lo_entity->field(
*          EXPORTING
*            iv_name  = 'YCE_TEST_CE1_ROOT'
*          RECEIVING
*            ro_field = DATA(lo_field)
*        ).
*
**        lo_field->
*    ENDIF.

    zcl_ext_custom_entity_utils=>get_sql_query_provider(
      EXPORTING
        io_request                = io_request
      IMPORTING
        ev_orderby_string         =  DATA(lv_orderby_string)
        ev_select_string          =  DATA(lv_select_string)
        ev_sql_where_string       =  DATA(lv_sql_where_string)
        ev_entity_id              =  DATA(lv_entity_id)
        ev_up_to_rows             =  DATA(lv_up_to_rows)
        ev_offset                 =  DATA(lv_offset)
        ev_is_ui_identification   =  DATA(lv_is_ui_identification)
        et_filter_cond            =  DATA(lt_filter_cond)
        eo_filter_as_tree         =  DATA(lo_filter_as_tree)
        et_parameters             =  DATA(lt_parameters)
        et_requested_elements     =  DATA(lt_requested_elements)
        ev_search_expression      =  DATA(lv_search_expression)
        et_sort_elements          =  DATA(lt_sort_elements)
        et_aggregated_elements    =  DATA(lt_aggregated_elements)
        et_aggr_grouped_elements  =  DATA(lt_aggr_grouped_elements)
        ev_is_data_requested      =  DATA(lv_is_data_requested)
        ev_is_total_rec_requested =  DATA(lv_is_total_rec_requested) ).

    IF lv_is_data_requested IS INITIAL.
      RETURN.
    ENDIF.

    CASE lv_entity_id.
      WHEN 'YCE_TEST_CE1_ROOT'.
        SELECT FROM i_purchaseorderapi01
        FIELDS purchaseorder,
               supplier
          WHERE (lv_sql_where_string)
          ORDER BY (lv_orderby_string)
          INTO TABLE @mt_header
          OFFSET @lv_offset
          UP TO @lv_up_to_rows ROWS.

        SORT mt_header BY purchaseorder.

        LOOP AT mt_header INTO DATA(ls_header).
          INSERT VALUE #( purchaseorder = ls_header-purchaseorder
                          vendor = ls_header-supplier ) INTO TABLE lt_output_parent.
        ENDLOOP.

        TRY.
            io_response->set_total_number_of_records( iv_total_number_of_records = lines( lt_output_parent ) ).
            io_response->set_data( it_data = lt_output_parent ).
          CATCH cx_rap_query_response_set_twic.
        ENDTRY.

      WHEN 'YCE_TEST_CE1_CHILD'.
        SELECT FROM i_purchaseorderitemapi01
        FIELDS purchaseorder,
               purchaseorderitem,
               \_purchaseorder-supplier AS vendor,
               material,
               plant,
               storagelocation AS location,
               orderquantity,
               purchaseorderquantityunit
          WHERE (lv_sql_where_string)
          ORDER BY (lv_orderby_string)
          INTO TABLE @mt_items
          OFFSET @lv_offset
          UP TO @lv_up_to_rows ROWS.

        SORT mt_header BY purchaseorder.

        LOOP AT mt_items INTO DATA(ls_items).
          INSERT INITIAL LINE INTO TABLE lt_output_child ASSIGNING FIELD-SYMBOL(<ls_output_child>).
          <ls_output_child> = CORRESPONDING #( ls_items ).
        ENDLOOP.

        TRY.
            io_response->set_total_number_of_records( iv_total_number_of_records = lines( lt_output_child ) ).
            io_response->set_data( it_data = lt_output_child ).
          CATCH cx_rap_query_response_set_twic.
        ENDTRY.

    ENDCASE.
  ENDMETHOD.
ENDCLASS.
