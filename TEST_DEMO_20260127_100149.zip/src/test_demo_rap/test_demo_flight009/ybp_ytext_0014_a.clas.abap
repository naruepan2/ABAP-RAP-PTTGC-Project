class YBP_YTEXT_0014_A definition
  public
  abstract
  final
  for behavior of YR_YTEXT_0014_A .

public section.
protected section.
private section.
ENDCLASS.



CLASS YBP_YTEXT_0014_A IMPLEMENTATION.
ENDCLASS.
