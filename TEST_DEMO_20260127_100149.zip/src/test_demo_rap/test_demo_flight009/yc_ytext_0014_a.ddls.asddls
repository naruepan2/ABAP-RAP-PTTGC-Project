@AccessControl.authorizationCheck: #CHECK
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for YR_YTEXT_0014_A'
@ObjectModel.semanticKey: [ 'TravelID' ]
define root view entity YC_YTEXT_0014_A
  provider contract transactional_query
  as projection on YR_YTEXT_0014_A

  association [0..1] to I_CalendarDate as _CurrentDate on _CurrentDate.CalendarDate = $session.system_date
{
  key TravelID,
      AgencyID,
      CustomerID,
//      @Consumption.derivation: { 
//        lookupEntity: 'ZI_EXT_CALENDARDATEFUNCTIONS',
//        resultElement: 'Today',
//        binding:[{targetParameter: 'BeginDate', type: #SYSTEM_FIELD, value: '#SYSTEM_DATE'}] }      
      @Consumption.filter.selectionType: #SINGLE
      BeginDate,
      EndDate,
      BookingFee,
      TotalPrice,
      CurrencyCode,
      Description,

//      @Consumption.filter.selectionType: #SINGLE
//      @Consumption.filter.hierarchyAssociation: '_CurrentDate'
//      @Consumption.filter.defaultHierarchyNode.node: [{element: '_CurrentDate.CalendarYear'}]
      FiscalYear,
      
      LocalLastChangedAt,

      _CurrentDate

}
