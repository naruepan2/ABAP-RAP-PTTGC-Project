@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '##GENERATED YTEXT_0014_A'
define root view entity YR_YTEXT_0014_A
  as select from    ytext_0014_a
{
  key ytext_0014_a.travel_id             as TravelID,
      ytext_0014_a.agency_id             as AgencyID,
      ytext_0014_a.customer_id           as CustomerID,
      ytext_0014_a.begin_date            as BeginDate,
      ytext_0014_a.end_date              as EndDate,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      ytext_0014_a.booking_fee           as BookingFee,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      ytext_0014_a.total_price           as TotalPrice,
      ytext_0014_a.currency_code         as CurrencyCode,
      ytext_0014_a.description           as Description,

      @Semantics.fiscal.year: true
      left( ytext_0014_a.begin_date, 4)  as FiscalYear, 

      @Semantics.user.createdBy: true
      ytext_0014_a.created_by            as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      ytext_0014_a.created_at            as CreatedAt,
      @Semantics.user.lastChangedBy: true
      ytext_0014_a.last_changed_by       as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      ytext_0014_a.last_changed_at       as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      ytext_0014_a.local_last_changed_at as LocalLastChangedAt

}
