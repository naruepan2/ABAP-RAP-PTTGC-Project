CLASS lhc_travel DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING
      REQUEST requested_authorizations FOR travel
      RESULT result.
    METHODS testrepeatableaction FOR MODIFY
      IMPORTING keys FOR ACTION travel~testrepeatableaction RESULT result.
    METHODS testaction FOR MODIFY
      IMPORTING keys FOR ACTION travel~testaction RESULT result.
ENDCLASS.


CLASS lhc_travel IMPLEMENTATION.
  METHOD get_global_authorizations.
  ENDMETHOD.

  METHOD testrepeatableaction.

    LOOP AT keys INTO DATA(ls_key).

    ENDLOOP.

  ENDMETHOD.

  METHOD TestAction.

    LOOP AT keys INTO DATA(ls_key).

    ENDLOOP.

  ENDMETHOD.

ENDCLASS.
