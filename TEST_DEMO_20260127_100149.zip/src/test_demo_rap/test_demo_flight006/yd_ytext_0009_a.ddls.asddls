@EndUserText.label: 'YD_YTEXT_0009_A'
define abstract entity YD_YTEXT_0009_A
{   
    @Consumption.defaultValue: 'Parameter1'
    @UI.dataFieldDefault: [{value: 'Parameter1'}]
    Parameter1 : abap.char(20);
    @Consumption.defaultValue: 'Parameter2'
    @UI.dataFieldDefault: [{value: 'Parameter2'}]
    Parameter2 : abap.char(20);
}
