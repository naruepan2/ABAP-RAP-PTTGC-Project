class YBP_YTEXT_0009_A definition
  public
  abstract
  final
  for behavior of YR_YTEXT_0009_A .

public section.
protected section.
private section.
ENDCLASS.



CLASS YBP_YTEXT_0009_A IMPLEMENTATION.
ENDCLASS.
