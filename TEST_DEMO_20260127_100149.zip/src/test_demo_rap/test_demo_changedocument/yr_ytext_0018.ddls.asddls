@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '##GENERATED YTEXT_0018_A'
define root view entity YR_YTEXT_0018
  as select from ytext_0018_a

  association of one to many YI_Demo_ChangeDocuItem001 as _ChangeDocsItem on _ChangeDocsItem.ChangeDocObject = $projection.TravelID

{
  key travel_id                                                       as TravelID,
      agency_id                                                       as AgencyID,
      customer_id                                                     as CustomerID,
      begin_date                                                      as BeginDate,
      end_date                                                        as EndDate,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      cast( booking_fee as YDEMO_TYPE_BOOKING_FEE_1 preserving type ) as BookingFee,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      cast( total_price as YDEMO_TYPE_TOTAL_PRICE_1 preserving type ) as TotalPrice,
      currency_code                                                   as CurrencyCode,
      description                                                     as Description,
      //Field with flag for change documents
      cast( status as ydemo_type_travel_status preserving type )      as Status,
      @Semantics.user.createdBy: true
      created_by                                                      as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      created_at                                                      as CreatedAt,
      @Semantics.user.lastChangedBy: true
      last_changed_by                                                 as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at                                                 as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at                                           as LocalLastChangedAt,

      _ChangeDocsItem

}
