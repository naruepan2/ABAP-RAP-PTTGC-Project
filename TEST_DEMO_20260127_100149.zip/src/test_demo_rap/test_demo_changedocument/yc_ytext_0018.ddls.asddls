@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for YR_YTEXT_0018'
@ObjectModel.semanticKey: [ 'TravelID' ]
define root view entity YC_YTEXT_0018
  provider contract transactional_query
  as projection on YR_YTEXT_0018
{
  key TravelID,
      AgencyID,
      CustomerID,
      BeginDate,
      EndDate,
      BookingFee,
      TotalPrice,
      CurrencyCode,
      Description,
      Status,
      LocalLastChangedAt,
      
      _ChangeDocsItem

}
