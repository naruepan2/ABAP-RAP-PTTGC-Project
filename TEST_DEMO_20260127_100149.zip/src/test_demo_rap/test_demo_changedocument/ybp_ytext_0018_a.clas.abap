class YBP_YTEXT_0018_A definition
  public
  abstract
  final
  for behavior of YR_YTEXT_0018 .

public section.
protected section.
private section.
ENDCLASS.



CLASS YBP_YTEXT_0018_A IMPLEMENTATION.
ENDCLASS.
