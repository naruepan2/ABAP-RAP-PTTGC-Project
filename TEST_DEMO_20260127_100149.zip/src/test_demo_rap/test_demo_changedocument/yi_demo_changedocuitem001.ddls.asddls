@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YI_Demo_ChangeDocuItem001'
define view entity YI_Demo_ChangeDocuItem001
  as select from I_ChangeDocumentItem
{
      @UI.lineItem: [{ position: 10, cssDefault.width: '10rem' }]
  key ChangeDocObject,
      //  @UI.lineItem: [{ position: 20 }]
  key ChangeDocObjectClass,
      //  @UI.lineItem: [{ position: 30 }]
  key ChangeDocument,
      //  @UI.lineItem: [{ position: 40 }]
  key DatabaseTable,
      //  @UI.lineItem: [{ position: 50 }]
  key ChangeDocTableKey,
      @UI.lineItem: [{ position: 20, cssDefault.width: '10rem' } ]
  key ChangeDocDatabaseTableField,
      @UI.lineItem: [{ position: 30, cssDefault.width: '8rem' } ]
  key ChangeDocItemChangeType,
      ChangeDocPreviousUnit,
      ChangeDocNewUnit,
      ChangeDocPreviousCurrency,
      ChangeDocNewCurrency,
      @UI.lineItem: [{ position: 50, cssDefault.width: '12rem' } ]
      ChangeDocNewFieldValue,
      @UI.lineItem: [{ position: 40, cssDefault.width: '12rem' } ]
      ChangeDocPreviousFieldValue,
      ChangeDocTextIsChanged,

      @UI.lineItem: [{ position: 60, cssDefault.width: '6rem' } ]
      _ChangeDocument.CreatedByUser,
      @UI.lineItem: [{ position: 70, cssDefault.width: '6rem' } ]
      _ChangeDocument.CreationDate,
      @UI.lineItem: [{ position: 80, cssDefault.width: '6rem' } ]
      _ChangeDocument.CreationTime,

      /* Associations */
      _ChangeDocLongTableKey,
      _ChangeDocument,
      _ChangeDocumentItemExtension,
      _FieldTextDDIC,
      _FieldTextLabel,
      _FieldTextReplace,
      _FieldTextView,
      _TableTextDDIC,
      _TableTextView
}
where
  ChangeDocObjectClass = 'YCHM_EXT_0018';
