@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YI_DMO_Travel_NW001'
define view entity YI_DMO_Travel_NW001
  as select from /DMO/I_Travel_M
  association [1..*] to YI_DMO_Booking_NW001 as _Booking on $projection.travel_id = _Booking.travel_id
{
  key travel_id,
      agency_id,
      customer_id,
      begin_date,
      end_date,
      booking_fee,
      total_price,
      currency_code,
      overall_status,
      description,

      _Booking.booking_date,
      
      _Booking
}
