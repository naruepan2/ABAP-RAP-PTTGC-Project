@EndUserText.label: 'Maintain YTEXT 0015 A Singleton'
@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: true
@ObjectModel.semanticKey: [ 'SingletonID' ]
define root view entity YC_Ytext0015A_S
  provider contract transactional_query
  as projection on YI_Ytext0015A_S
{
  key SingletonID,
      PurchaseOrder,
      Vendor,
      LastChangedAtMax,
      TransportRequestID,
      HideTransport,
      _Ytext0015A : redirected to composition child YC_Ytext0015A

}
