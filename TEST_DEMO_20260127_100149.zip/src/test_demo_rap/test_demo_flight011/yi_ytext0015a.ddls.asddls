@EndUserText.label: 'YTEXT 0015 A'
@AccessControl.authorizationCheck: #CHECK
define view entity YI_Ytext0015A
  as select from ytext_0015_a
  association to parent YI_Ytext0015A_S as _Ytext0015AAll on $projection.SingletonID = _Ytext0015AAll.SingletonID
{
  key purchase_order                         as PurchaseOrder,
  key purchase_order_item                    as PurchaseOrderItem,
      vendor                                 as Vendor,
      material                               as Material,
      plant                                  as Plant,
      location                               as Location,
      @Semantics.quantity.unitOfMeasure: 'Unit'
      quantity                               as Quantity,
      unit                                   as Unit,
      cast( 'X' as boolean preserving type ) as IsHidden,
      @Semantics.user.createdBy: true
      created_by                             as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      created_at                             as CreatedAt,
      @Semantics.user.lastChangedBy: true
      last_changed_by                        as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at                        as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at                  as LocalLastChangedAt,
      1                                      as SingletonID,
      _Ytext0015AAll

}
