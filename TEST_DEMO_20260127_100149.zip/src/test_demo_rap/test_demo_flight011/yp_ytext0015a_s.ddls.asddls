@EndUserText.label: 'YTEXT 0015 A Singleton'
@AccessControl.authorizationCheck: #NOT_REQUIRED
define root view entity YP_YTEXT0015A_S
  as select from    I_Language
    left outer join ytext_0015_a on 0 = 0
{
  key 1                                   as SingletonID,
      max( ytext_0015_a.last_changed_at ) as LastChangedAtMax

}
where
  I_Language.Language = $session.system_language
