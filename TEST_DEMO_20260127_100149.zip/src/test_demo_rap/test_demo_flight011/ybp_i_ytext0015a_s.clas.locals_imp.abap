CLASS lhc_rap_tdat_cts DEFINITION FINAL.
  PUBLIC SECTION.
    CLASS-METHODS get
      RETURNING VALUE(result) TYPE REF TO if_mbc_cp_rap_tdat_cts.

ENDCLASS.


CLASS lhc_rap_tdat_cts IMPLEMENTATION.
  METHOD get.
    result = mbc_cp_api=>rap_tdat_cts( tdat_name              = 'YYTEXT0015A'
                                       table_entity_relations = VALUE #(
                                           ( entity = 'Ytext0015A' table = 'YTEXT_0015_A' ) ) )
                                       ##NO_TEXT.
  ENDMETHOD.
ENDCLASS.


CLASS lhc_yi_ytext0015a_s DEFINITION INHERITING FROM cl_abap_behavior_handler FINAL.
  PRIVATE SECTION.
    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING
                keys   REQUEST requested_features FOR ytext0015aall
      RESULT    result.
    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING
      REQUEST requested_authorizations FOR ytext0015aall
      RESULT result.
    METHODS purchaseordertoitems FOR DETERMINE ON SAVE
      IMPORTING keys FOR ytext0015aall~purchaseordertoitems.
ENDCLASS.


CLASS lhc_yi_ytext0015a_s IMPLEMENTATION.
  METHOD get_instance_features.
    DATA edit_flag TYPE abp_behv_flag VALUE if_abap_behv=>fc-o-enabled.

*    IF lhc_rap_tdat_cts=>get( )->is_editable( ) = abap_false.
*      edit_flag = if_abap_behv=>fc-o-disabled.
*    ENDIF.

    READ ENTITIES OF yi_ytext0015a_s IN LOCAL MODE
         ENTITY ytext0015aall
         ALL FIELDS WITH CORRESPONDING #( keys )
         RESULT DATA(all).
    IF all[ 1 ]-%is_draft = if_abap_behv=>mk-off.
    ENDIF.

    result = VALUE #( ( %tky               = all[ 1 ]-%tky
                        %action-edit       = edit_flag
                        %assoc-_ytext0015a = edit_flag ) ).
  ENDMETHOD.

  METHOD get_global_authorizations.
*    AUTHORITY-CHECK OBJECT 'S_TABU_NAM' ID 'TABLE' FIELD 'YI_YTEXT0015A' ID 'ACTVT' FIELD '02'.
*    DATA(is_authorized) = COND #( WHEN sy-subrc = 0 THEN if_abap_behv=>auth-allowed
*                                  ELSE if_abap_behv=>auth-unauthorized ).
*    result-%update      = is_authorized.
*    result-%action-edit = is_authorized.
  ENDMETHOD.

  METHOD purchaseordertoitems.
    READ ENTITIES OF yi_ytext0015a_s IN LOCAL MODE
         ENTITY ytext0015aall
         ALL FIELDS WITH CORRESPONDING #( keys )
         RESULT DATA(result_all).

    DATA lt_purchaseorder TYPE RANGE OF i_purchaseorderitemapi01-purchaseorder.
    DATA lt_supplier      TYPE RANGE OF i_purchaseorderapi01-supplier.

    IF VALUE #( result_all[ 1 ]-purchaseorder ) IS NOT INITIAL.
      lt_purchaseorder = VALUE #( sign   = 'I'
                                  option = 'EQ'
                                  ( low = result_all[ 1 ]-purchaseorder ) ).
    ENDIF.
    IF VALUE #( result_all[ 1 ]-vendor ) IS NOT INITIAL.
      lt_supplier = VALUE #( sign   = 'I'
                             option = 'EQ'
                             ( low = result_all[ 1 ]-vendor ) ).
    ENDIF.

    SELECT FROM i_purchaseorderitemapi01
      FIELDS purchaseorder,
             purchaseorderitem,
             \_purchaseorder-supplier AS vendor,
             material,
             plant,
             storagelocation          AS location,
             orderquantity            AS quantity,
             baseunit                 AS unit
      WHERE purchaseorder            IN @lt_purchaseorder
        AND \_purchaseorder-supplier IN @lt_supplier
      INTO TABLE @DATA(lt_purchaseorderitem).

    DATA lt_yi_ytext0015a_s   TYPE TABLE FOR CREATE yi_ytext0015a_s\_ytext0015a.
    DATA lt_yi_ytext0015a_del TYPE TABLE FOR DELETE yi_ytext0015a.

    SELECT FROM yi_ytext0015a
      FIELDS purchaseorder,
             purchaseorderitem
      INTO CORRESPONDING FIELDS OF TABLE @lt_yi_ytext0015a_del.

*    LOOP AT lt_yi_ytext0015a_del ASSIGNING FIELD-SYMBOL(<ls_yi_ytext0015a_del>).
*      <ls_yi_ytext0015a_del>-%is_draft = keys[ 1 ]-%is_draft.
*    ENDLOOP.

    TRY.
        INSERT INITIAL LINE INTO TABLE lt_yi_ytext0015a_s ASSIGNING FIELD-SYMBOL(<ls_yi_ytext0015a_s>).
        <ls_yi_ytext0015a_s>-%key-singletonid = 1.
*        <ls_yi_ytext0015a_s>-%is_draft = keys[ 1 ]-%is_draft.

        LOOP AT lt_purchaseorderitem INTO DATA(ls_purchaseorderitem).
          INSERT CORRESPONDING #( ls_purchaseorderitem ) INTO TABLE <ls_yi_ytext0015a_s>-%target
                 ASSIGNING FIELD-SYMBOL(<target>).
          <target>-%cid      = cl_uuid_factory=>create_system_uuid( )->create_uuid_c32( ).
*          <target>-%is_draft = keys[ 1 ]-%is_draft.
          <target>-%control  = VALUE #( purchaseorder     = if_abap_behv=>mk-on
                                        purchaseorderitem = if_abap_behv=>mk-on
                                        vendor            = if_abap_behv=>mk-on
                                        material          = if_abap_behv=>mk-on
                                        plant             = if_abap_behv=>mk-on
                                        location          = if_abap_behv=>mk-on
                                        quantity          = if_abap_behv=>mk-on
                                        unit              = if_abap_behv=>mk-on ).
        ENDLOOP.
      CATCH cx_uuid_error.
    ENDTRY.

    MODIFY ENTITIES OF yi_ytext0015a_s IN LOCAL MODE
           ENTITY ytext0015a
           DELETE FROM lt_yi_ytext0015a_del

           ENTITY ytext0015aall
           CREATE BY \_ytext0015a
           FROM lt_yi_ytext0015a_s
           " TODO: variable is assigned but never used (ABAP cleaner)
           FAILED DATA(failed1)
           " TODO: variable is assigned but never used (ABAP cleaner)
           REPORTED DATA(reported1).
  ENDMETHOD.
ENDCLASS.


CLASS lsc_yi_ytext0015a_s DEFINITION INHERITING FROM cl_abap_behavior_saver FINAL.
  PROTECTED SECTION.
    METHODS save_modified    REDEFINITION.
    METHODS cleanup_finalize REDEFINITION.
ENDCLASS.


CLASS lsc_yi_ytext0015a_s IMPLEMENTATION.
  METHOD save_modified.
    READ TABLE update-ytext0015aall INDEX 1 INTO DATA(all).
    IF all-transportrequestid IS NOT INITIAL.
      lhc_rap_tdat_cts=>get( )->record_changes( transport_request = all-transportrequestid
                                                create            = REF #( create )
                                                update            = REF #( update )
                                                delete            = REF #( delete ) ).
    ENDIF.
  ENDMETHOD.

  METHOD cleanup_finalize ##NEEDED.
  ENDMETHOD.
ENDCLASS.


CLASS lhc_yi_ytext0015a DEFINITION INHERITING FROM cl_abap_behavior_handler FINAL.
  PRIVATE SECTION.
    METHODS get_global_features FOR GLOBAL FEATURES
      IMPORTING
      REQUEST requested_features FOR ytext0015a
      RESULT result.
*    METHODS createdeletepurchaseorder FOR DETERMINE ON MODIFY
*      IMPORTING keys FOR ytext0015a~createdeletepurchaseorder.
ENDCLASS.


CLASS lhc_yi_ytext0015a IMPLEMENTATION.
  METHOD get_global_features.
    DATA edit_flag TYPE abp_behv_flag VALUE if_abap_behv=>fc-o-enabled.

*    IF lhc_rap_tdat_cts=>get( )->is_editable( ) = abap_false.
*      edit_flag = if_abap_behv=>fc-o-disabled.
*    ENDIF.
    result-%update = edit_flag.
    result-%delete = edit_flag.
  ENDMETHOD.

*  METHOD createdeletepurchaseorder.
*
*    DATA(lt_key) = keys.
*
*  ENDMETHOD.

ENDCLASS.
