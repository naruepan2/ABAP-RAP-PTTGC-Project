@EndUserText.label: 'Maintain YTEXT 0015 A'
@AccessControl.authorizationCheck: #CHECK
@Metadata.allowExtensions: true

@Search.searchable: true

define view entity YC_Ytext0015A
  as projection on YI_Ytext0015A
{
  @Search.defaultSearchElement: true
  key PurchaseOrder,
  key PurchaseOrderItem,
  @Search.defaultSearchElement: true
  Vendor,
  @Search.defaultSearchElement: true
  Material,
  @Search.defaultSearchElement: true
//  @Consumption.filter.defaultValue: '1000'
  Plant,
  Location,
  Quantity,
  Unit,
  IsHidden,
  CreatedBy,
  CreatedAt,
  LastChangedBy,
  LastChangedAt,
  @Consumption.hidden: true
  LocalLastChangedAt,
  @Consumption.hidden: true
  SingletonID,
  _Ytext0015AAll : redirected to parent YC_Ytext0015A_S
  
}
