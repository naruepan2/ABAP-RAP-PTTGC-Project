class YBP_I_YTEXT0015A_S definition
  public
  abstract
  final
  for behavior of YI_YTEXT0015A_S .

public section.
protected section.
private section.
ENDCLASS.



CLASS YBP_I_YTEXT0015A_S IMPLEMENTATION.
ENDCLASS.
