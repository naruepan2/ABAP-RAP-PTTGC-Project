@EndUserText.label: 'YTEXT 0015 A Singleton'
@AccessControl.authorizationCheck: #NOT_REQUIRED
define root view entity YI_Ytext0015A_S
  as select from    I_Language
    left outer join ytext_0015_a on 0 = 0
  //    inner join      YP_YTEXT0015A_S as _YTEXT0015A_S on 1 = _YTEXT0015A_S.SingletonID
  composition [0..*] of YI_Ytext0015A as _Ytext0015A
  //  association [1..1] to YP_YTEXT0015A_S as _YTEXT0015A_S on $projection.SingletonID = _YTEXT0015A_S.SingletonID
{
  key 1                                             as SingletonID,
      _Ytext0015A,
      cast( '          ' as ebeln preserving type ) as PurchaseOrder,
      cast( '          ' as lifnr preserving type ) as Vendor,
      max( ytext_0015_a.last_changed_at )           as LastChangedAtMax,
      //      _YTEXT0015A_S.LastChangedAtMax                as LastChangedAtMax,
      cast( '' as sxco_transport)                   as TransportRequestID,
      cast( 'X' as abap_boolean preserving type)    as HideTransport
}
where
  I_Language.Language = $session.system_language
