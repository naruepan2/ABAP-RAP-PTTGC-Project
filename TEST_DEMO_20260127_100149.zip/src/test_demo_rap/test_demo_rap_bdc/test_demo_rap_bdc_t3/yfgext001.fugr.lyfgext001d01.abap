CLASS lcl_bdc DEFINITION CREATE PRIVATE.

  PUBLIC SECTION.
    CONSTANTS:
      BEGIN OF c_dismode,
        display_all_screens   TYPE ctu_params-dismode VALUE 'A',
        background_processing TYPE ctu_params-dismode VALUE 'N',
      END OF c_dismode,

      BEGIN OF c_updmode,
        synchronous TYPE ctu_params-updmode VALUE 'S',
      END OF c_updmode.

    CLASS-METHODS create
      IMPORTING
        iv_transaction  TYPE tcode
      RETURNING
        VALUE(r_result) TYPE REF TO lcl_bdc.

    METHODS constructor
      IMPORTING
        iv_transaction TYPE tcode.

    METHODS:
      bdc_dynpro
        IMPORTING
          iv_program    TYPE bdcdata-program
          iv_dynpro     TYPE bdcdata-dynpro
        RETURNING
          VALUE(ro_bdc) TYPE REF TO lcl_bdc,
      bdc_field
        IMPORTING
          iv_fnam       TYPE bdcdata-fnam
          iv_fval       TYPE clike
        RETURNING
          VALUE(ro_bdc) TYPE REF TO lcl_bdc,
      bdc_transaction
        RETURNING
          VALUE(rt_message) TYPE tab_bdcmsgcoll.

  PROTECTED SECTION.
  PRIVATE SECTION.
    DATA:
      mt_bdcdata     TYPE STANDARD TABLE OF bdcdata WITH DEFAULT KEY,
      mv_transaction TYPE tcode.

ENDCLASS.
