*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LYFGEXT001TOP.                     " Global Declarations
  INCLUDE LYFGEXT001UXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LYFGEXT001F...                     " Subroutines
* INCLUDE LYFGEXT001O...                     " PBO-Modules
* INCLUDE LYFGEXT001I...                     " PAI-Modules
* INCLUDE LYFGEXT001E...                     " Events
* INCLUDE LYFGEXT001P...                     " Local class implement.
* INCLUDE LYFGEXT001T99.                     " ABAP Unit tests
