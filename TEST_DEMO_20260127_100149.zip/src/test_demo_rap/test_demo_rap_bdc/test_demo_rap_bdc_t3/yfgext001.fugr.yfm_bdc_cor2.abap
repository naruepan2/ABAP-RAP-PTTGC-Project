FUNCTION yfm_bdc_cor2.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_ORDERNUMBER) TYPE  AUFNR
*"  EXPORTING
*"     VALUE(ES_RETURN) TYPE  BAPIRET2
*"----------------------------------------------------------------------
  FINAL(lo_bdc) = lcl_bdc=>create( 'COR2' ).

  FINAL(lt_msg) = lo_bdc->bdc_dynpro(
    iv_program = 'SAPLCOKO'
    iv_dynpro  = '5110'
  )->bdc_field(
    iv_fnam = 'BDC_OKCODE'
    iv_fval = '/00'
  )->bdc_field(
    iv_fnam = 'CAUFVD-AUFNR'
    iv_fval = iv_ordernumber
  )->bdc_field(
    iv_fnam = 'R62CLORD-FLG_COMPL'
    iv_fval = abap_true
  )->bdc_dynpro(
    iv_program = 'SAPLCOKO'
    iv_dynpro  = '5115'
  )->bdc_field(
    iv_fnam = 'BDC_OKCODE'
    iv_fval = '=RABK'
  )->bdc_dynpro(
    iv_program = 'SAPLCOKO'
    iv_dynpro  = '5115'
  )->bdc_field(
    iv_fnam = 'BDC_OKCODE'
    iv_fval = '=BU'
  )->bdc_transaction( ).


  READ TABLE lt_msg ASSIGNING FIELD-SYMBOL(<ls_message>)
    WITH KEY msgtyp = 'S'
             msgid = '40'
             msgnr = '581'.
  IF sy-subrc <> 0.
    READ TABLE lt_msg ASSIGNING <ls_message>
      WITH KEY msgtyp = 'E'.
    IF sy-subrc <> 0.
      READ TABLE lt_msg ASSIGNING <ls_message>
        WITH KEY msgtyp = 'A'.
      IF sy-subrc <> 0.
        READ TABLE lt_msg ASSIGNING <ls_message> INDEX 1.
      ENDIF.
    ENDIF.
  ENDIF.

  es_return = CORRESPONDING #( <ls_message>
    MAPPING
      message_v1 = msgv1
      message_v2 = msgv2
      message_v3 = msgv3
      message_v4 = msgv4
      type = msgtyp
      number = msgnr
      id = msgid
  ).

  MESSAGE ID <ls_message>-msgid TYPE <ls_message>-msgtyp
    NUMBER <ls_message>-msgnr
    WITH <ls_message>-msgv1 <ls_message>-msgv2 <ls_message>-msgv3 <ls_message>-msgv4
    INTO es_return-message.

ENDFUNCTION.
