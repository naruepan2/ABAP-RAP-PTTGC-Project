FUNCTION-POOL YFGEXT001.                    "MESSAGE-ID ..

* INCLUDE LYFGEXT001D...                     " Local class definition

INCLUDE LYFGEXT001d01.                    " Local class definition
INCLUDE LYFGEXT001p01.                    " Local class implementation
