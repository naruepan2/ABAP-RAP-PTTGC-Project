
CLASS lcl_bdc IMPLEMENTATION.

  METHOD constructor.

    me->mv_transaction = iv_transaction.

  ENDMETHOD.

  METHOD create.

    r_result = NEW #( iv_transaction = iv_transaction ).

  ENDMETHOD.

  METHOD bdc_dynpro.
    ro_bdc = me.
    APPEND INITIAL LINE TO mt_bdcdata ASSIGNING FIELD-SYMBOL(<ls_bdcdata>).
    <ls_bdcdata>-program = iv_program.
    <ls_bdcdata>-dynpro = iv_dynpro.
    <ls_bdcdata>-dynbegin = abap_true.
  ENDMETHOD.

  METHOD bdc_field.
    ro_bdc = me.
    CHECK iv_fval IS NOT INITIAL.

    APPEND INITIAL LINE TO mt_bdcdata ASSIGNING FIELD-SYMBOL(<ls_bdcdata>).
    <ls_bdcdata>-fnam = iv_fnam.
    <ls_bdcdata>-fval = iv_fval.
  ENDMETHOD.

  METHOD bdc_transaction.
    DATA: ls_bdc_opt TYPE ctu_params.

    ls_bdc_opt-dismode  = c_dismode-background_processing.
    ls_bdc_opt-updmode  = c_updmode-synchronous.
    ls_bdc_opt-defsize  = abap_true.
    ls_bdc_opt-racommit = abap_true.

    CALL TRANSACTION mv_transaction
      USING mt_bdcdata
      OPTIONS FROM ls_bdc_opt
      MESSAGES INTO rt_message.
  ENDMETHOD.

ENDCLASS.
