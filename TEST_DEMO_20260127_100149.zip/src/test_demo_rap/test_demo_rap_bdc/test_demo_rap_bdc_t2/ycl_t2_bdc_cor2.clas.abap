CLASS ycl_t2_bdc_cor2 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .


  PUBLIC SECTION.


    CLASS-METHODS YFM_BDC_COR2
      IMPORTING
        !iv_ordernumber TYPE aufnr
        !iv_dest         TYPE rfcdest DEFAULT 'NONE'
      EXPORTING
        !es_message     TYPE bapiret2
      RAISING
        cx_aco_application_exception
        cx_aco_communication_failure
        cx_aco_system_failure .


  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_t2_bdc_cor2 IMPLEMENTATION.


  METHOD yfm_bdc_cor2.
    DATA: _rfc_message_ TYPE aco_proxy_msg_type.

    CALL FUNCTION 'YFM_BDC_COR2' DESTINATION iv_dest
      EXPORTING
        iv_ordernumber        = iv_ordernumber
      IMPORTING
        es_return             = es_message
      EXCEPTIONS
        communication_failure = 1 MESSAGE _rfc_message_
        system_failure        = 2 MESSAGE _rfc_message_
        OTHERS                = 3.
    IF sy-subrc NE 0.
      DATA __sysubrc TYPE sy-subrc.
      DATA __textid TYPE aco_proxy_textid_type.
      __sysubrc = sy-subrc.
      __textid-msgid = sy-msgid.
      __textid-msgno = sy-msgno.
      __textid-attr1 = sy-msgv1.
      __textid-attr2 = sy-msgv2.
      __textid-attr3 = sy-msgv3.
      __textid-attr4 = sy-msgv4.
      CASE __sysubrc.
        WHEN 1 .
          RAISE EXCEPTION TYPE cx_aco_communication_failure
            EXPORTING
              rfc_msg = _rfc_message_.
        WHEN 2 .
          RAISE EXCEPTION TYPE cx_aco_system_failure
            EXPORTING
              rfc_msg = _rfc_message_.
        WHEN 3 .
          RAISE EXCEPTION TYPE cx_aco_application_exception
            EXPORTING
              exception_id = 'OTHERS'
              textid       = __textid.
      ENDCASE.
    ENDIF.

  ENDMETHOD.

ENDCLASS.
