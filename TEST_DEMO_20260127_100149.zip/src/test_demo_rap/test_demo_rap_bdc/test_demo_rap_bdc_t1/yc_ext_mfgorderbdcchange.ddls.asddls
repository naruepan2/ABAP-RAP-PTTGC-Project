@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Manufacturing Order - BDC Change'
define root view entity YC_EXT_MfgOrderBdcChange
  provider contract transactional_query
  as projection on YI_EXT_MfgOrderBdcChange
{
  key ManufacturingOrder,
      ManufacturingOrderItem,
      ManufacturingOrderCategory,
      ManufacturingOrderType,
      ManufacturingOrderText,
      ProdnProcgIsFlexible,
      @Consumption.filter.mandatory: true
      @Consumption.filter.selectionType: #INTERVAL
      CreationDate,
      CreationTime,
      CreatedByUser,
      LastChangeDate,
      LastChangeTime,
      LastChangedByUser,
      Material,
      Product,
      StorageLocation,
      Batch,
      ProductionPlant,
      /* Associations */
      _Batch,
      _Batch_2,
      _CreatedByUser,
      _LastChangedByUser,
      _LongText,
      _Material,
      _MfgOrderCategory,
      _MfgOrderDocdGoodsMovement,
      _MfgOrderDocInfoRecord,
      _MfgOrderDocumentLink,
      _MfgOrderItem,
      _MfgOrderMainItem,
      _MfgOrderMaterialDocItem,
      _MfgOrderSequence,
      _MfgOrderType,
      _OrderTypeDetails,
      _Product,
      _ProductionPlant,
      _ProductPlant,
      _ProductPlant2,
      _ProductStorageLocation,
      _ProductStorageLocation2,
      _ProductUnitsOfMeasure,
      _StorageLocation
}
