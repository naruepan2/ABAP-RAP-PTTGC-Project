CLASS zbp_i_ext_mfgorderbdcchange DEFINITION PUBLIC ABSTRACT FINAL FOR BEHAVIOR OF yi_ext_mfgorderbdcchange.
ENDCLASS.

CLASS zbp_i_ext_mfgorderbdcchange IMPLEMENTATION.
ENDCLASS.
