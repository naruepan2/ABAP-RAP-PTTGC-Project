@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Manufacturing Order - BDC Change'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
  serviceQuality: #B,
  sizeCategory: #L,
  dataClass: #TRANSACTIONAL
}
//@Analytics.dataCategory: #CUBE
define root view entity YI_EXT_MfgOrderBdcChange
  as select from I_ManufacturingOrder
{
  key ManufacturingOrder,
      ManufacturingOrderItem,
      ManufacturingOrderCategory,
      ManufacturingOrderType,
      ManufacturingOrderText,
      ProdnProcgIsFlexible,
      CreationDate,
      CreationTime,
      CreatedByUser,
      LastChangeDate,
      LastChangeTime,
      LastChangedByUser,
      Material,
      Product,
      StorageLocation,
      Batch,
      ProductionPlant,

      /* Associations */
      _Batch,
      _Batch_2,
      _CreatedByUser,
      _LastChangedByUser,
      _LongText,
      _Material,
      _MfgOrderCategory,
      _MfgOrderDocdGoodsMovement,
      _MfgOrderDocInfoRecord,
      _MfgOrderDocumentLink,
      _MfgOrderItem,
      _MfgOrderMainItem,
      _MfgOrderMaterialDocItem,
      _MfgOrderSequence,
      _MfgOrderType,
      _OrderTypeDetails,
      _Product,
      _ProductionPlant,
      _ProductPlant,
      _ProductPlant2,
      _ProductStorageLocation,
      _ProductStorageLocation2,
      _ProductUnitsOfMeasure,
      _StorageLocation
}
where
  ManufacturingOrderCategory = '40';
