@EndUserText.label: 'Input Order for Action'
define abstract entity YD_EXT_MfgOrderBdcChg_ZAction
  //  with parameters parameter_name : parameter_type
{
  //    element_name : element_type;

  OrderNumber : aufnr;

}
