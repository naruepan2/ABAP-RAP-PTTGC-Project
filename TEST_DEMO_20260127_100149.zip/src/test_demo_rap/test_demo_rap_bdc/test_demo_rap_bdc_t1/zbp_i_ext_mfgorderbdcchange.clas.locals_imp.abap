CLASS lhc_mochange DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR mochange RESULT result.

    METHODS read FOR READ
      IMPORTING keys FOR READ mochange RESULT result.

    METHODS lock FOR LOCK
      IMPORTING keys FOR LOCK mochange.

    METHODS customaction FOR MODIFY
      IMPORTING keys FOR ACTION mochange~customaction.

    METHODS revoke FOR MODIFY
      IMPORTING keys FOR ACTION mochange~revoke RESULT result.

ENDCLASS.

CLASS lhc_mochange IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD read.
  ENDMETHOD.

  METHOD lock.
  ENDMETHOD.

  METHOD customaction.
    LOOP AT keys ASSIGNING FIELD-SYMBOL(<ls_key>).
      TRY.
          ycl_t2_bdc_cor2=>yfm_bdc_cor2(
            EXPORTING
              iv_ordernumber = <ls_key>-%param-ordernumber
            IMPORTING
              es_message = FINAL(ls_message)
          ).
        CATCH cx_aco_application_exception cx_aco_communication_failure cx_aco_system_failure.
          "handle exception
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD revoke.
    LOOP AT keys ASSIGNING FIELD-SYMBOL(<ls_key>).
      INSERT CORRESPONDING #( <ls_key> ) INTO TABLE result ASSIGNING FIELD-SYMBOL(<ls_result>).
      TRY.
          ycl_t2_bdc_cor2=>yfm_bdc_cor2(
            EXPORTING
              iv_ordernumber = <ls_key>-manufacturingorder
            IMPORTING
              es_message = FINAL(ls_message)
          ).

          CASE ls_message-type.
            WHEN 'S'.
            WHEN OTHERS.
              INSERT CORRESPONDING #( <ls_key> ) INTO TABLE failed-mochange ASSIGNING FIELD-SYMBOL(<ls_failed>).
              <ls_failed>-%fail-cause = if_abap_behv=>cause-unspecific.

          ENDCASE.

          INSERT CORRESPONDING #( <ls_key> ) INTO TABLE reported-mochange ASSIGNING FIELD-SYMBOL(<ls_reported>).
          <ls_reported>-%msg = new_message(
                                 id       = ls_message-id
                                 number   = ls_message-number
                                 severity = if_abap_behv_message=>severity-information
                                 v1       = ls_message-message_v1
                                 v2       = ls_message-message_v2
                                 v3       = ls_message-message_v3
                                 v4       = ls_message-message_v4
                               ).

        CATCH cx_aco_application_exception cx_aco_communication_failure cx_aco_system_failure.
          "handle exception
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

ENDCLASS.

CLASS lsc_yi_ext_mfgorderbdcchange DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS finalize REDEFINITION.

    METHODS check_before_save REDEFINITION.

    METHODS save REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_yi_ext_mfgorderbdcchange IMPLEMENTATION.

  METHOD finalize.
  ENDMETHOD.

  METHOD check_before_save.
  ENDMETHOD.

  METHOD save.
  ENDMETHOD.

  METHOD cleanup.
  ENDMETHOD.

  METHOD cleanup_finalize.
  ENDMETHOD.

ENDCLASS.
