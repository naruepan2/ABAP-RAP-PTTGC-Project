@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Booking Interface'
@Metadata.ignorePropagatedAnnotations: true

define root view entity YI_EXT_DEMO_TRAVEL001
  as select from /dmo/travel_m as Travel -- the travel table is the data source for this view

  composition [0..*] of YI_EXT_DEMO_BOOKING001   as _Booking

  association [0..1] to /DMO/I_Agency            as _Agency        on $projection.agency_id = _Agency.AgencyID
  association [0..1] to /DMO/I_Customer          as _Customer      on $projection.customer_id = _Customer.CustomerID
  association [0..1] to I_Currency               as _Currency      on $projection.currency_code = _Currency.Currency
  association [1..1] to /DMO/I_Overall_Status_VH as _OverallStatus on $projection.overall_status = _OverallStatus.OverallStatus


{
  key travel_id,
      agency_id,
      customer_id,

      case
        when _Customer.Title is not initial
            then concat_with_space( _Customer.Title , concat_with_space( _Customer.FirstName, _Customer.LastName, 1 ), 1 )
        else concat_with_space( _Customer.FirstName, _Customer.LastName, 1 )
      end as customer_name,

      begin_date,
      end_date,
      @Semantics.amount.currencyCode: 'currency_code'
      booking_fee,
      @Semantics.amount.currencyCode: 'currency_code'
      total_price,
      currency_code,
      overall_status,

      case overall_status
       when 'O' then 2 // Opened
       when 'A' then 3 // Accepted
       when 'X' then 1 // Cancelled
       else 0
      end as overall_criticality,

      description,
      @Semantics.user.createdBy: true
      created_by,
      @Semantics.systemDateTime.createdAt: true
      created_at,
      @Semantics.user.lastChangedBy: true
      last_changed_by,
      //local ETag field --> OData ETag
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      last_changed_at,

      /* Associations */
      _Booking,
      _Agency,
      _Customer,
      _Currency,
      _OverallStatus
}
