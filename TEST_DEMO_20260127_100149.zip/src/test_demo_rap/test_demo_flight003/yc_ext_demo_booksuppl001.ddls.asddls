@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Booking Supplement Projection'

@Metadata.allowExtensions: true

@Search.searchable: true

define view entity YC_EXT_DEMO_BOOKSUPPL001
  as projection on YI_EXT_DEMO_BOOKSUPPL001 as BookSupplement
{

      @Search.defaultSearchElement: true
  key travel_id                   as TravelID,
      @Search.defaultSearchElement: true
  key booking_id                  as BookingID,
      @Search.defaultSearchElement: true
  key booking_supplement_id       as BookingSupplementID,
      @Search.defaultSearchElement: true
      @Consumption.valueHelpDefinition: [ {entity: {name: '/DMO/I_SUPPLEMENT', element: 'SupplementID' } ,
                                         additionalBinding: [ { localElement: 'Price',  element: 'Price' },
                                                              { localElement: 'CurrencyCode', element: 'CurrencyCode' }] }]
      @ObjectModel.text.element: ['SupplementDescription']
      supplement_id               as SupplementID,
      _SupplementText.Description as SupplementDescription : localized,

      @Semantics.amount.currencyCode: 'CurrencyCode'
      price                       as Price,

      @Consumption.valueHelpDefinition: [{entity: {name: 'I_Currency', element: 'Currency' }}]
      currency_code               as CurrencyCode,

      @UI.hidden: true
      last_changed_at,
      /* Associations */
      _Booking : redirected to parent YC_EXT_DEMO_BOOKING001,
      _Product,
      _SupplementText,
      _Travel  : redirected to YC_EXT_DEMO_TRAVEL001
}
