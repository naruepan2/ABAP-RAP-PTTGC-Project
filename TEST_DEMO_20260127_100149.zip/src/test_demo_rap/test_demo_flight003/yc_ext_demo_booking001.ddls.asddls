@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Booking Projection'

@Metadata.allowExtensions: true

@Search.searchable: true

define view entity YC_EXT_DEMO_BOOKING001
  as projection on YI_EXT_DEMO_BOOKING001 as Booking
{
      @Search.defaultSearchElement: true
  key travel_id                 as TravelID,
      @Search.defaultSearchElement: true
  key booking_id                as BookingID,
      booking_date              as BookingDate,

      @Search.defaultSearchElement: true
      @Consumption.valueHelpDefinition: [{ entity : {name: '/DMO/I_Customer_StdVH', element: 'CustomerID' }, useForValidation: true }]
      @ObjectModel.text.element: [ 'CustomerName' ]
      customer_id               as CustomerID,
      _Customer.LastName        as CustomerName,

      @Consumption.valueHelpDefinition: [{entity: {name: '/DMO/I_Carrier', element: 'AirlineID' }}]
      @ObjectModel.text.element: ['CarrierName']
      carrier_id                as CarrierID,
      _Carrier.Name             as CarrierName,

      @Consumption.valueHelpDefinition: [ {entity: {name: '/DMO/I_Flight', element: 'ConnectionID'},
                                           additionalBinding: [ { localElement: 'FlightDate',   element: 'FlightDate'},
                                                                { localElement: 'CarrierID',    element: 'AirlineID'},
                                                                { localElement: 'FlightPrice',  element: 'Price'},
                                                                { localElement: 'CurrencyCode', element: 'CurrencyCode' } ] } ]
      connection_id             as ConnectionID,

      @Consumption.valueHelpDefinition: [ {entity: {name: '/DMO/I_Flight', element: 'FlightDate' },
                                           additionalBinding: [ { localElement: 'ConnectionID', element: 'ConnectionID'},
                                                                { localElement: 'CarrierID',    element: 'AirlineID'},
                                                                { localElement: 'FlightPrice',  element: 'Price' },
                                                                { localElement: 'CurrencyCode', element: 'CurrencyCode' }]}]
      flight_date               as FlightDate,

      @Semantics.amount.currencyCode: 'CurrencyCode'
      flight_price              as FlightPrice,

      @Consumption.valueHelpDefinition: [{entity: {name: 'I_Currency', element: 'Currency' }}]
      currency_code             as CurrencyCode,

      @ObjectModel.text.element: [ 'BookingStatusText' ]
      booking_status            as BookingStatus,
      _BookingStatus._Text.Text as BookingStatusText : localized,

      @UI.hidden: true
      last_changed_at,
      /* Associations */
      _BookingStatus,
      _BookSupplement : redirected to composition child YC_EXT_DEMO_BOOKSUPPL001,
      _Carrier,
      _Connection,
      _Customer,
      _Travel         : redirected to parent YC_EXT_DEMO_TRAVEL001
}
