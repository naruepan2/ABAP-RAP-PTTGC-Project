@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Async'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YA_EXT_DemoAsync
  provider contract transactional_query
  as projection on YR_EXT_DemoAsync
{
  key     Language,
  virtual Test1 : abap.char( 1 )
}
