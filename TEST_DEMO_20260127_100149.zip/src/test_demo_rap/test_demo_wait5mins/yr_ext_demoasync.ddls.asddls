@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Async'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YR_EXT_DemoAsync
  as select from I_Language
{
  key Language
}
where
  Language = $session.system_language
