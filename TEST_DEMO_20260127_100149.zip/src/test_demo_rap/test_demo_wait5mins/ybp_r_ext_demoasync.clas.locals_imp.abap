CLASS lsc_yr_ext_demoasync DEFINITION INHERITING FROM cl_abap_behavior_saver.

  PROTECTED SECTION.

    METHODS finalize REDEFINITION.

    METHODS check_before_save REDEFINITION.

    METHODS save REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_yr_ext_demoasync IMPLEMENTATION.

  METHOD finalize.
  ENDMETHOD.

  METHOD check_before_save.
  ENDMETHOD.

  METHOD cleanup.
  ENDMETHOD.

  METHOD cleanup_finalize.
  ENDMETHOD.

  METHOD save.

  ENDMETHOD.

ENDCLASS.

CLASS lhc_dummy DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS read FOR READ
      IMPORTING keys FOR READ dummy RESULT result.

    METHODS lock FOR LOCK
      IMPORTING keys FOR LOCK dummy.

    METHODS wait5mins FOR MODIFY
      IMPORTING keys FOR ACTION dummy~wait5mins.
    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR dummy RESULT result.

    METHODS wait5seconds FOR MODIFY
      IMPORTING keys FOR ACTION dummy~wait5seconds.

ENDCLASS.


CLASS lhc_dummy IMPLEMENTATION.
  METHOD lock.

  ENDMETHOD.

  METHOD read.

  ENDMETHOD.

  METHOD wait5mins.
    CASE cl_abap_context_info=>get_user_technical_name( ).
      WHEN 'Z0012280'
        OR 'Z0012261'
        OR 'Z0010571'
        OR 'T_POSTMAN'
        OR 'SAP_CPIS'.

      WHEN OTHERS.
        RETURN.
    ENDCASE.

    WAIT UP TO 300 SECONDS.
  ENDMETHOD.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD Wait5Seconds.
    CASE cl_abap_context_info=>get_user_technical_name( ).
      WHEN 'Z0012280'
        OR 'Z0012261'
        OR 'Z0010571'
        OR 'T_POSTMAN'
        OR 'SAP_CPIS'.

      WHEN OTHERS.
        RETURN.
    ENDCASE.

    WAIT UP TO 5 SECONDS.
  ENDMETHOD.

ENDCLASS.
