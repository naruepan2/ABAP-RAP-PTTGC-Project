CLASS ycl_get_demo_chdo_001 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_oo_adt_classrun .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_get_demo_chdo_001 IMPLEMENTATION.


  METHOD if_oo_adt_classrun~main.

    READ ENTITY yr_ext_demo_flight001
    ALL FIELDS WITH VALUE #( ( %key-travelid = '00000001' ) )
    RESULT DATA(lt_travel).

    MODIFY ENTITY yr_ext_demo_flight001
    UPDATE FIELDS ( currencycode )
    WITH VALUE #( FOR ls_travel IN lt_travel
                  ( %key = ls_travel-%key
                    currencycode = 'USD' ) ).
    COMMIT ENTITIES.

    TRY.
        cl_chdo_read_tools=>changedocument_read(
          EXPORTING
            i_objectclass    = 'YTEXT_0002_CHDO'
*        it_objectid      =
i_date_of_change = cl_abap_context_info=>get_system_date( )
*        i_time_of_change =
*        i_date_until     =
*        i_time_until     =
*        it_username      =
*        iv_read_archive  =
*        is_read_options  =
      IMPORTING
        et_cdredadd_tab  = DATA(lt_cdredadd_tab)
*      CHANGING
*        ct_cdhdr         =
        ).
      CATCH cx_chdo_read_error INTO DATA(error).
        out->write( error->get_text( ) ).
        RETURN.
    ENDTRY.

    out->write( lt_cdredadd_tab ).

  ENDMETHOD.
ENDCLASS.
