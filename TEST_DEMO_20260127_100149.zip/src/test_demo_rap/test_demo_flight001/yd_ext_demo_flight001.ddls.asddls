@EndUserText.label: 'Default Company'
define abstract entity YD_EXT_DEMO_FLIGHT001
{
  @Semantics.largeObject : {
        mimeType: 'Mimetype',
        fileName: 'Filename',
        contentDispositionPreference: #INLINE
      }
  attachment : abap.rawstring( 0 );
  filename   : abap.string;
  @Semantics.mimeType: true
  mimetype   : abap.string;

}
