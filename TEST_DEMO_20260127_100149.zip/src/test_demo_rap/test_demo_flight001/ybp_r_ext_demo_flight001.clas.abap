class YBP_R_EXT_DEMO_FLIGHT001 definition
  public
  abstract
  final
  for behavior of YR_EXT_DEMO_FLIGHT001 .

public section.
protected section.
private section.
ENDCLASS.



CLASS YBP_R_EXT_DEMO_FLIGHT001 IMPLEMENTATION.
ENDCLASS.
