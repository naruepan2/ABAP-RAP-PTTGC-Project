@EndUserText.label: 'YD_EXT_DEMO_FLIGHT002'
define abstract entity YD_EXT_DEMO_FLIGHT002
{
  @UI.defaultValue: #( 'ELEMENT_OF_REFERENCED_ENTITY: TravelID' )
  TravelID   : /dmo/travel_id;
  @UI.defaultValue: #( 'ELEMENT_OF_REFERENCED_ENTITY: AgencyID' )
  AgencyID   : /dmo/agency_id;
  @UI.defaultValue: #( 'ELEMENT_OF_REFERENCED_ENTITY: CustomerID' )
  CustomerID : /dmo/customer_id;
}
