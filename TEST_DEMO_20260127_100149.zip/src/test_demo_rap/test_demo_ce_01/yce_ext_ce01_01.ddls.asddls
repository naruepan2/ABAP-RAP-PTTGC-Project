@EndUserText.label: 'Root'
define root custom entity YCE_EXT_CE01_01
{
  key CompanyCode : bukrs;

      _02         : association [1..*] to YCE_EXT_CE01_02 on _02.CompanyCode = $projection.CompanyCode;

}
