@EndUserText.label: 'Item 1'
define custom entity YCE_EXT_CE01_02
{
  key CompanyCode : bukrs;
  key Plant       : werks_d;

}
