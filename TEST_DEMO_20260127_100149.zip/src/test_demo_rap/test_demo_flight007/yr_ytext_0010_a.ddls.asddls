@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '##GENERATED YTEXT_0010_A'
define root view entity YR_YTEXT_0010_A
  as select from ytext_0010_a as Travel
  composition [0..*] of YR_YTEXT_0011_A as _Child
{
  key travel_id             as TravelID,
      agency_id             as AgencyID,
      customer_id           as CustomerID,
      begin_date            as BeginDate,
      end_date              as EndDate,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      booking_fee           as BookingFee,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      total_price           as TotalPrice,
      currency_code         as CurrencyCode,
      description           as Description,

      case when customer_id is not initial
        then cast ( 'X' as abap_boolean preserving type )
      else
        null
      end                   as Checkbox,

      @Semantics.user.createdBy: true
      created_by            as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      created_at            as CreatedAt,
      @Semantics.user.lastChangedBy: true
      last_changed_by       as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at       as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at as LocalLastChangedAt,

      _Child

}
