CLASS lhc_travel DEFINITION INHERITING FROM cl_abap_behavior_handler.

  PRIVATE SECTION.

    METHODS augment_update FOR MODIFY
      IMPORTING entities FOR UPDATE travel.

ENDCLASS.

CLASS lhc_travel IMPLEMENTATION.

  METHOD augment_update.

    DATA(lt_entities) = entities.

    ycl_ytext_0010_buffer=>gt_buffer = lt_entities.

    MODIFY AUGMENTING ENTITIES OF yr_ytext_0010_a
      ENTITY travel
       EXECUTE store_buffer
       FROM CORRESPONDING #( entities ).

  ENDMETHOD.

ENDCLASS.

*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations
