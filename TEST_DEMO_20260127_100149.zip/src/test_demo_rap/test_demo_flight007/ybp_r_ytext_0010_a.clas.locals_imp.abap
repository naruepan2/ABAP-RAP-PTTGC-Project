CLASS lsc_yr_ytext_0010_a DEFINITION INHERITING FROM cl_abap_behavior_saver.

  PROTECTED SECTION.

    METHODS save_modified REDEFINITION.

ENDCLASS.

CLASS lsc_yr_ytext_0010_a IMPLEMENTATION.

  METHOD save_modified.

    DATA(lt_buffer) = ycl_ytext_0010_buffer=>gt_buffer.

  ENDMETHOD.

ENDCLASS.

CLASS lhc_travel DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR travel RESULT result.
    METHODS store_buffer FOR MODIFY
      IMPORTING keys FOR ACTION travel~store_buffer.

ENDCLASS.

CLASS lhc_travel IMPLEMENTATION.

  METHOD get_global_authorizations.
  ENDMETHOD.

  METHOD store_buffer.

    DATA(lt_buffer) = ycl_ytext_0010_buffer=>gt_buffer.

  ENDMETHOD.

ENDCLASS.
