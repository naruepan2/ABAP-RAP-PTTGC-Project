@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for YR_YTEXT_0011_A'
@ObjectModel.semanticKey: [ 'TravelID', 'BookingID' ]
define view entity YC_YTEXT_0011_A
  as projection on YR_YTEXT_0011_A
{
  key TravelID,
  key BookingID,
      BookingDate,
      CustomerID,
      CarrierID,
      ConnectionID,
      FlightDate,
      FlightPrice,
      CurrencyCode,      
      LocalLastChangedAt,

      _Parent : redirected to parent YC_YTEXT_0010_A

}
