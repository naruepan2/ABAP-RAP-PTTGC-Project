@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for YR_YTEXT_0010_A'
@ObjectModel.semanticKey: [ 'TravelID' ]
define root view entity YC_YTEXT_0010_A
  provider contract transactional_query
  as projection on YR_YTEXT_0010_A
{
  key     TravelID,
          AgencyID,
          CustomerID,
          BeginDate,
          EndDate,
          BookingFee,
          TotalPrice,
          CurrencyCode,
          Description,
          Checkbox,

          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_TEST_VIRTUAL_ELEMENT01'
          @UI.multiLineText: true
  virtual virtialField : abap.char(100),


          LocalLastChangedAt,

          _Child : redirected to composition child YC_YTEXT_0011_A

}
