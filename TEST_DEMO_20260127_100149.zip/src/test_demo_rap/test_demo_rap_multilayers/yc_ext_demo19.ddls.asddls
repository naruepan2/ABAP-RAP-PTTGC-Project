@EndUserText.label: 'Demo 19: Header Projection'
@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: false
@Search.searchable: true
define root view entity YC_EXT_Demo19
  provider contract transactional_query
  as projection on YR_EXT_Demo19_TP
{
  key UUID,

      @Search.defaultSearchElement: true
      @Search.fuzzinessThreshold: 0.7
      CLRNumber,

      Amount,
      Currency,
      CreditComment,
      NextApprover,
      
      IsMyTask,
      
      Status,
      Field1,

      /* Audit Fields */
      CreatedBy,
      CreatedAt,
      LastChangedBy,
      LastChangedAt,
      LocalLastChangedAt,

      /* Associations: Redirect to Child Projections */
      _Comment  : redirected to composition child YC_EXT_Demo19Comment,
      _Workflow : redirected to composition child YC_EXT_Demo19Workflow
}
