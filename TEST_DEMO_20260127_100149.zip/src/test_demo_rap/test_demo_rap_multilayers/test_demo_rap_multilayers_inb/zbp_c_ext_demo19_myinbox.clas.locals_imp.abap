CLASS lhc_header DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS dosomething1 FOR MODIFY
      IMPORTING keys FOR ACTION header~dosomething1.

ENDCLASS.

CLASS lhc_header IMPLEMENTATION.

  METHOD dosomething1.
  ENDMETHOD.

ENDCLASS.
