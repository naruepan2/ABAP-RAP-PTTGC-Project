@EndUserText.label: 'Demo 19: Header Projection'
@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: false
@Search.searchable: true
define root view entity YC_EXT_Demo19_MyInbox
  provider contract transactional_query
  as projection on YR_EXT_Demo19_TP
{
  key UUID,

      @Search.defaultSearchElement: true
      @Search.fuzzinessThreshold: 0.7
      CLRNumber,

      Amount,
      Currency,
      CreditComment,
      NextApprover,

      Status,
      Field1,

      /* Audit Fields */
      CreatedBy,
      CreatedAt,
      LastChangedBy,
      LastChangedAt,
      LocalLastChangedAt,

            /* Associations: Redirect to Child Projections */
            _Comment  : redirected to composition child YC_EXT_DEMO19_MYINBOXCOMMENT,
            _Workflow : redirected to composition child YC_EXT_Demo19_MyInboxWorkflow
}
where
      NextApprover = $session.user
  and Status       != 'C'
