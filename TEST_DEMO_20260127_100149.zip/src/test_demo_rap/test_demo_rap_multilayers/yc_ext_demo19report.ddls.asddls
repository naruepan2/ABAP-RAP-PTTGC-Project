@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Demo 19: Report'
//@Metadata.ignorePropagatedAnnotations: true
define view entity YC_EXT_Demo19Report
  as select from YI_EXT_Demo19Report
{
  key UUID,
  key CommentUUID,
      CLRNumber,
      Amount,
      Currency,
      CreditComment,
      NextApprover,
      Status,
      Field1,
      CommentText
}
