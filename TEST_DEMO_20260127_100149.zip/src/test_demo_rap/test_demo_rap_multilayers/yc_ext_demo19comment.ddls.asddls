@EndUserText.label: 'Demo 19: Comment Projection'
@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: false
define view entity YC_EXT_Demo19Comment
  as projection on YR_EXT_Demo19Comment_TP
{
  key UUID,
      ParentUUID,
      CommentText,
      
      /* Audit Fields */
      CreatedBy,
      CreatedAt,
      LastChangedBy,
      LastChangedAt,
      
      /* Associations: Redirect to Parent Projection */
      _Header : redirected to parent YC_EXT_Demo19
}
