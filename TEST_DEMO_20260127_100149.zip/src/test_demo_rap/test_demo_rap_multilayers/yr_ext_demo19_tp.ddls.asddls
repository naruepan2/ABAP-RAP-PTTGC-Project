@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Demo 19: Header'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YR_EXT_Demo19_TP
  as select from ytext_0019_01_a

  /* Compositions */
  composition [0..*] of YR_EXT_Demo19Comment_TP  as _Comment
  composition [0..*] of YR_EXT_Demo19Workflow_TP as _Workflow
{
  key uuid                  as UUID,
      @EndUserText.label: 'CLR Number'
      clr_number            as CLRNumber,
      @Semantics.amount.currencyCode: 'Currency'
      @EndUserText.label: 'Amount'
      amount                as Amount,
      currency              as Currency,
      @EndUserText.label: 'Credit Comment'
      credit_comment        as CreditComment,
      @EndUserText.label: 'Next Approver'
      next_approver         as NextApprover,
      @EndUserText.label: 'Status'
      status                as Status,
      @EndUserText.label: 'Field 1'
      field_1               as Field1,

      case
        when $projection.NextApprover = $session.user
          then 'X'
        else ''
      end                   as IsMyTask,

      @Semantics.user.createdBy: true
      created_by            as CreatedBy,

      @Semantics.systemDateTime.createdAt: true
      created_at            as CreatedAt,

      @Semantics.user.lastChangedBy: true
      last_changed_by       as LastChangedBy,

      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at       as LastChangedAt,

      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at as LocalLastChangedAt,

      /* Associations */
      _Comment,
      _Workflow
}
