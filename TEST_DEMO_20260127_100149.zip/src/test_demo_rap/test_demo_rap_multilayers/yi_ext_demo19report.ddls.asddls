@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Demo 19: Report'
//@Metadata.ignorePropagatedAnnotations: true
define view entity YI_EXT_Demo19Report
  as select from YR_EXT_Demo19_TP
{
  key UUID,
  key _Comment.UUID as CommentUUID,
      CLRNumber,
      Amount,
      Currency,
      CreditComment,
      NextApprover,
      Status,
      Field1,
      _Comment.CommentText
}
