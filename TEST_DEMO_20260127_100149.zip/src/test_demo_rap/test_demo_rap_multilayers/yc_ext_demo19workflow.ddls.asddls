@EndUserText.label: 'Demo 19: Workflow Projection'
@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: false
define view entity YC_EXT_Demo19Workflow
  as projection on YR_EXT_Demo19Workflow_TP
{
  key UUID,
      ParentUUID,
      StepNumber,
      Approver,
      ApproveAt,
      
      /* Audit Fields */
      CreatedBy,
      CreatedAt,
      LastChangedBy,
      LastChangedAt,
      
      /* Associations: Redirect to Parent Projection */
      _Header : redirected to parent YC_EXT_Demo19
}
