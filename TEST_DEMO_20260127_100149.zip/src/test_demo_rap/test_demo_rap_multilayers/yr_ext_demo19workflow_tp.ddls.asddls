@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Demo 19: Workflow'
@Metadata.ignorePropagatedAnnotations: true
define view entity YR_EXT_Demo19Workflow_TP
  as select from ytext_0019_03_a
  association to parent YR_EXT_Demo19_TP as _Header on $projection.ParentUUID = _Header.UUID
{
  key uuid                  as UUID,
      parent_uuid           as ParentUUID,
      
      @EndUserText.label: 'Step Number'
      step_number           as StepNumber,
      
      @EndUserText.label: 'Approver'
      approver              as Approver,
      
      @EndUserText.label: 'Approved At'
      approve_at            as ApproveAt,
      
      @Semantics.user.createdBy: true
      created_by            as CreatedBy,
      
      @Semantics.systemDateTime.createdAt: true
      created_at            as CreatedAt,
      
      @Semantics.user.lastChangedBy: true
      last_changed_by       as LastChangedBy, 
      
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at       as LastChangedAt,
      
      /* Associations */
      _Header
}
