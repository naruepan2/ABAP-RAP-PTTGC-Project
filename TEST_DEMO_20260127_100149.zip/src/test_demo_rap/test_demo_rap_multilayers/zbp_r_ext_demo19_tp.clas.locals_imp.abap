CLASS lhc_header DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR header RESULT result.
    METHODS approve FOR MODIFY
      IMPORTING keys FOR ACTION header~approve.

    METHODS reject FOR MODIFY
      IMPORTING keys FOR ACTION header~reject.

    METHODS submita FOR MODIFY
      IMPORTING keys FOR ACTION header~submita.

    METHODS submitb FOR MODIFY
      IMPORTING keys FOR ACTION header~submitb.
    METHODS generateclr FOR DETERMINE ON SAVE
      IMPORTING keys FOR header~generateclr.
    METHODS determineworkflow FOR DETERMINE ON SAVE
      IMPORTING keys FOR header~determineworkflow.


ENDCLASS.

CLASS lhc_header IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD approve.
  ENDMETHOD.

  METHOD reject.
  ENDMETHOD.

  METHOD submita.
  ENDMETHOD.

  METHOD submitb.
  ENDMETHOD.

  METHOD generateclr.
    DATA:
      lt_update_header TYPE TABLE FOR UPDATE yr_ext_demo19_tp,
      lv_lastest_clr   TYPE yr_ext_demo19_tp-clrnumber,
      lv_n             TYPE n LENGTH 7.
    SELECT SINGLE FROM yr_ext_demo19_tp AS a
      FIELDS
        MAX( clrnumber )
     INTO @lv_lastest_clr.
    IF sy-subrc = 0.
      lv_n = lv_lastest_clr+3(7).
    ENDIF.

    READ ENTITIES OF yr_ext_demo19_tp IN LOCAL MODE
      ENTITY header
        FIELDS ( clrnumber )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).

    LOOP AT lt_result ASSIGNING FIELD-SYMBOL(<ls_result>).
      IF <ls_result>-clrnumber IS NOT INITIAL.
        CONTINUE.
      ENDIF.
      lv_n += 1.
      <ls_result>-clrnumber = |CLR{ lv_n }|.
      APPEND CORRESPONDING #( <ls_result> ) TO lt_update_header.
    ENDLOOP.

    IF lt_update_header IS NOT INITIAL.
      MODIFY ENTITIES OF yr_ext_demo19_tp IN LOCAL MODE
        ENTITY header
          UPDATE FIELDS ( clrnumber )
          WITH lt_update_header.
    ENDIF.

  ENDMETHOD.


  METHOD determineworkflow.
    DATA:
      lt_create_workflow TYPE TABLE FOR CREATE yr_ext_demo19_tp\_workflow.

    " สมมติว่า Add Approver ใหม่ทุกครั้งที่มีการ save (ไม่ make sense ช่างมันครับ แค่เทส)

    READ ENTITIES OF yr_ext_demo19_tp IN LOCAL MODE
      ENTITY header
        FIELDS ( amount currency )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_headers).


    LOOP AT lt_headers INTO DATA(ls_header).
      DATA(ls_cba_entry) = VALUE #( lt_create_workflow[ KEY draft %tky = ls_header-%tky ] OPTIONAL ).

      IF ls_cba_entry IS INITIAL.
        ls_cba_entry-%tky = ls_header-%tky.
      ENDIF.

      APPEND VALUE #(
        %cid        = |{ ls_header-uuid }_STEP1|
        stepnumber  = 1
        approver    = cl_abap_context_info=>get_user_technical_name( )
      ) TO ls_cba_entry-%target.

      APPEND ls_cba_entry TO lt_create_workflow.

    ENDLOOP.

    IF lt_create_workflow IS NOT INITIAL.
      MODIFY ENTITIES OF yr_ext_demo19_tp IN LOCAL MODE
        ENTITY header
          CREATE BY \_workflow
          FIELDS ( stepnumber approver )
          WITH lt_create_workflow
        MAPPED DATA(mapped_cba)
        REPORTED DATA(reported_cba).
    ENDIF.

  ENDMETHOD.

ENDCLASS.
