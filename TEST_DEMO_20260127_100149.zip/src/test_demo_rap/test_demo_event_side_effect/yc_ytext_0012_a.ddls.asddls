@AccessControl.authorizationCheck: #CHECK
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for YR_YTEXT_0012_A'
@ObjectModel.semanticKey: [ 'TravelID' ]
define root view entity YC_YTEXT_0012_A
  provider contract transactional_query
  as projection on YR_YTEXT_0012_A
{
  key TravelID,
  AgencyID,
  CustomerID,
  BeginDate,
  EndDate,
  BookingFee,
  TotalPrice,
  CurrencyCode,
  Description,
  Status,
  LocalLastChangedAt
  
}
