CLASS ycl_insert_ytext_0020_a DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_oo_adt_classrun .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_insert_ytext_0020_a IMPLEMENTATION.


  METHOD if_oo_adt_classrun~main.

    DELETE FROM ytext_0020_a.

    DATA lt_ytext_0020_a TYPE TABLE OF ytext_0020_a.

    DO 1000 TIMES.
      DATA(lv_index) = sy-index.

      APPEND INITIAL LINE TO lt_ytext_0020_a ASSIGNING FIELD-SYMBOL(<ls_ytext_0020_a>).
      TRY.
          <ls_ytext_0020_a>-key_uuid = cl_uuid_factory=>create_system_uuid( )->create_uuid_x16( ).
        CATCH cx_uuid_error.
          "handle exception
      ENDTRY.

      <ls_ytext_0020_a>-line_no = lv_index.
      <ls_ytext_0020_a>-status  = 'O'.
    ENDDO.

    MODIFY ytext_0020_a FROM TABLE @lt_ytext_0020_a.



  ENDMETHOD.
ENDCLASS.
