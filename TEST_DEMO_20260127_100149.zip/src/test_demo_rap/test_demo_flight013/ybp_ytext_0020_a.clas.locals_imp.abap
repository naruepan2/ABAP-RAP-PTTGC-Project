CLASS lhc_yr_ytext_0020_a DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
              IMPORTING
              REQUEST requested_authorizations FOR yr_ytext_0020_a
              RESULT result.
    METHODS setstatus FOR MODIFY
              IMPORTING keys FOR ACTION yr_ytext_0020_a~setstatus.
ENDCLASS.


CLASS lhc_yr_ytext_0020_a IMPLEMENTATION.
  METHOD get_global_authorizations.
  ENDMETHOD.

  METHOD setstatus.
    READ ENTITIES OF yr_ytext_0020_a IN LOCAL MODE
         ENTITY yr_ytext_0020_a
         ALL FIELDS WITH CORRESPONDING #( keys )
         RESULT DATA(lt_result).

    LOOP AT lt_result ASSIGNING FIELD-SYMBOL(<ls_result>).
      IF <ls_result>-status = 'O'.
        <ls_result>-status = 'A'.
      ELSEIF <ls_result>-status = 'A'.
        <ls_result>-status = 'X'.
      ELSEIF <ls_result>-status = 'X'.
        <ls_result>-status = 'O'.
      ENDIF.
    ENDLOOP.

    MODIFY ENTITIES OF yr_ytext_0020_a IN LOCAL MODE
           ENTITY yr_ytext_0020_a
           UPDATE FIELDS ( status ) WITH VALUE #( FOR <ls_update> IN lt_result
                                                  ( %tky   = <ls_update>-%tky
                                                    status = <ls_update>-status ) ).
  ENDMETHOD.
ENDCLASS.
