@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '##GENERATED YTEXT_0020_A'
define root view entity YR_YTEXT_0020_A
  as select from ytext_0020_a
  association of one to one /DMO/I_Overall_Status_VH as _OverallStatus on $projection.Status = _OverallStatus.OverallStatus
{
  key key_uuid              as KeyUUID,
      line_no               as KeyLineNo,
      @ObjectModel.text.association: '_OverallStatus'
      status                as Status,
      @Semantics.user.createdBy: true
      created_by            as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      created_at            as CreatedAt,
      @Semantics.user.lastChangedBy: true
      last_changed_by       as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at       as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at as LocalLastChangedAt,

      _OverallStatus

}
