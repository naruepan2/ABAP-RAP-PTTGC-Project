@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for YR_YTEXT_0020_A'
define root view entity YC_YTEXT_0020_A
  provider contract transactional_query
  as projection on YR_YTEXT_0020_A
{
  key KeyUUID,
      KeyLineNo,
      @ObjectModel.text.association: '_OverallStatus'
      @ObjectModel.text.element: [ 'OverallStatusText' ]
      Status,

      @UI.hidden: true
      _OverallStatus._Text.Text as OverallStatusText : localized,

      LocalLastChangedAt,

      _OverallStatus

}
