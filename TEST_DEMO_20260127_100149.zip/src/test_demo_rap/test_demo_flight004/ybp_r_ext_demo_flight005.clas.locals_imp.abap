CLASS lhc_travel DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING
      REQUEST requested_authorizations FOR travel
      RESULT result.
    METHODS calculatetotalprice FOR DETERMINE ON MODIFY
      IMPORTING keys FOR travel~calculatetotalprice.
    METHODS get_global_features FOR GLOBAL FEATURES
      IMPORTING REQUEST requested_features FOR travel RESULT result.
    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR travel RESULT result.
    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR travel RESULT result.

ENDCLASS.


CLASS lhc_travel IMPLEMENTATION.
  METHOD get_global_authorizations.
  ENDMETHOD.

  METHOD calculatetotalprice.
    READ ENTITIES OF yr_ext_demo_flight005 IN LOCAL MODE
         ENTITY travel
         ALL FIELDS WITH CORRESPONDING #( keys )
         RESULT DATA(lt_travels).

    LOOP AT lt_travels ASSIGNING FIELD-SYMBOL(<travel>) WHERE virtualfield1 IS NOT INITIAL.
      SPLIT <travel>-virtualfield1 AT '-' INTO DATA(lv_low_val) DATA(lv_high_val).

      IF CONV i( lv_low_val ) > CONV i( lv_high_val ).
        CONTINUE.
      ENDIF.

      IF CONV i( lv_low_val ) >= 0 AND CONV i( lv_high_val ) <= 25.
        <travel>-bookingfee += 10.
        <travel>-totalprice += 10.
      ELSEIF CONV i( lv_low_val ) >= 25 AND CONV i( lv_high_val ) <= 50.
        <travel>-bookingfee += 20.
        <travel>-totalprice += 20.
      ELSEIF CONV i( lv_low_val ) >= 50 AND CONV i( lv_high_val ) <= 75.
        <travel>-bookingfee += 30.
        <travel>-totalprice += 30.
      ELSEIF CONV i( lv_low_val ) >= 75 AND CONV i( lv_high_val ) <= 100.
        <travel>-bookingfee += 40.
        <travel>-totalprice += 40.
      ENDIF.
    ENDLOOP.

    MODIFY ENTITIES OF yr_ext_demo_flight005 IN LOCAL MODE
           ENTITY travel
           UPDATE FIELDS ( bookingfee totalprice )
           WITH VALUE #( FOR travel IN lt_travels
                         ( CORRESPONDING #( travel ) ) )
           REPORTED FINAL(lt_reported).

    reported = CORRESPONDING #( DEEP lt_reported ).
  ENDMETHOD.

  METHOD get_global_features.
    IF requested_features-%create IS NOT INITIAL.
      result-%create = if_abap_behv=>fc-o-disabled.
    ENDIF.
  ENDMETHOD.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD get_instance_features.
    DATA(ls_key) = keys[ 1 ].

    DATA(lv_behv_field) = VALUE if_abap_behv=>t_xflag(  ).
    lv_behv_field = if_abap_behv=>fc-f-read_only.

    APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<ls_result>).
    <ls_result>-%tky   = ls_key-%tky.
    <ls_result>-%field = VALUE #( AgencyID      = lv_behv_field
                                  CustomerID    = lv_behv_field
                                  BeginDate     = lv_behv_field
                                  EndDate       = lv_behv_field
                                  Description   = lv_behv_field
                                  OverallStatus = lv_behv_field
                                  CurrencyCode  = lv_behv_field
                                  BookingFee    = lv_behv_field
                                  TotalPrice    = lv_behv_field ).
  ENDMETHOD.
ENDCLASS.
