@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '##GENERATED YTEXT_0007_A'
define root view entity YR_EXT_DEMO_FLIGHT005
  as select from ytext_0007_a as Travel
{
  key travel_id                             as TravelID,
      agency_id                             as AgencyID,
      customer_id                           as CustomerID,
      begin_date                            as BeginDate,
      end_date                              as EndDate,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      booking_fee                           as BookingFee,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      total_price                           as TotalPrice,
      currency_code                         as CurrencyCode,
      description                           as Description,
      overall_status                        as OverallStatus,

      @Semantics.largeObject: { mimeType: 'MimeType',   //case-sensitive
                                fileName: 'FileName',   //case-sensitive
                                contentDispositionPreference: #INLINE }
      attachment                            as Attachment,
      @Semantics.mimeType: true
      mime_type                             as MimeType,
      file_name                             as FileName,

      cast( '          ' as abap.char(10) ) as virtualField1,


      @Semantics.user.createdBy: true
      created_by                            as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      created_at                            as CreatedAt,
      @Semantics.user.lastChangedBy: true
      last_changed_by                       as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at                       as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at                 as LocalLastChangedAt

}
