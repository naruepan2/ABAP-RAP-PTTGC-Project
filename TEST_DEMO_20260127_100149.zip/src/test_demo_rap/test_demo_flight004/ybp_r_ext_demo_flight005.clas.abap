class YBP_R_EXT_DEMO_FLIGHT005 definition
  public
  abstract
  final
  for behavior of YR_EXT_DEMO_FLIGHT005 .

public section.
protected section.
private section.
ENDCLASS.



CLASS YBP_R_EXT_DEMO_FLIGHT005 IMPLEMENTATION.
ENDCLASS.
