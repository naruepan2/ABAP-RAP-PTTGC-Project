@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for YR_EXT_DEMO_FLIGHT005'
@ObjectModel.semanticKey: [ 'TravelID' ]


define root view entity YC_EXT_DEMO_FLIGHT005
  provider contract transactional_query
  as projection on YR_EXT_DEMO_FLIGHT005
{
  key     TravelID,
          AgencyID,
          CustomerID,
          BeginDate,
          EndDate,
          BookingFee,
          TotalPrice,
          CurrencyCode,
          Description,
          OverallStatus,
          Attachment,
          MimeType,
          FileName,
          virtualField1,
          LocalLastChangedAt,

          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_EXT_DEMO_FLIGHT005_VE'
  virtual HiddenCreate : boole_d

}
