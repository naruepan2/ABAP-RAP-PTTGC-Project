CLASS ycl_z0012353_002_01 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_oo_adt_classrun .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_z0012353_002_01 IMPLEMENTATION.


  METHOD if_oo_adt_classrun~main.
*    DATA lt_travel TYPE TABLE FOR CREATE yr_ext_demo_flight002.
*
*    SELECT FROM yr_ext_demo_flight002
*    FIELDS *
*     ORDER BY travelid DESCENDING
*     INTO CORRESPONDING FIELDS OF TABLE @lt_travel
*     UP TO 1 ROWS.
*
*    out->write( lt_travel ).
*
*    lt_travel[ 1 ]-travelid = 99999999.
*
*    ASSIGN lt_travel[ 1 ]-%control TO FIELD-SYMBOL(<travel>).
*    IF sy-subrc = 0.
*      DO.
*        ASSIGN COMPONENT sy-index OF STRUCTURE <travel> TO FIELD-SYMBOL(<lv_val>) ELSE UNASSIGN.
*        IF sy-subrc = 0.
*          <lv_val> = if_abap_behv=>mk-on.
*        ELSE.
*          EXIT.
*        ENDIF.
*      ENDDO.
*    ENDIF.
*
*    CLEAR <travel>-createdat.
*    CLEAR <travel>-createdby.
*    CLEAR <travel>-lastchangedat.
*    CLEAR <travel>-lastchangedby.
*    CLEAR <travel>-locallastchangedat.
*
*    MODIFY ENTITIES OF yr_ext_demo_flight002
*    ENTITY travel
*    CREATE AUTO FILL CID WITH lt_travel
*    FAILED FINAL(failed)
*    REPORTED FINAL(reported)
*    MAPPED FINAL(mapped).
*
*    IF failed-travel IS INITIAL.
*      COMMIT ENTITIES.
*
*      out->write( lt_travel ).
*
*      MODIFY ENTITIES OF yr_ext_demo_flight002
*      ENTITY travel
*      DELETE FROM VALUE #( ( travelid = 99999999 ) ).
*
*      COMMIT ENTITIES.
*    ELSE.
*      out->write( failed-travel ).
*    ENDIF.

    MODIFY ENTITIES OF yr_ext_demo_flight002
    ENTITY travel
    execute Test
    FROM VALUE #( ( ) ).

  ENDMETHOD.
ENDCLASS.
