@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Overall Status'
//@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
  serviceQuality: #X,
  sizeCategory: #S,
  dataClass: #MIXED
}
@ObjectModel.resultSet.sizeCategory: #XS
define view entity YI_EXT_Demo_OverallStatusVH
  as select from /DMO/I_Overall_Status_VH
{
  key OverallStatus,
  
      case OverallStatus
        when 'A'
          then 3
        when 'X'
          then 1
        else 0
      end as OverallStatusCriticallity,
      
      /* Associations */
      _Text
}
