CLASS lhc_travel DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING
      REQUEST requested_authorizations FOR travel
      RESULT result.
    METHODS test FOR MODIFY
      IMPORTING keys FOR ACTION travel~test.
    METHODS testactionuu01 FOR MODIFY
      IMPORTING keys FOR ACTION travel~testactionuu01 RESULT result.

    METHODS testactionuuf01 FOR MODIFY
      IMPORTING keys FOR ACTION travel~testactionuuf01.

*    METHODS earlynumbering_create FOR NUMBERING
*      IMPORTING entities FOR CREATE travel.
ENDCLASS.


CLASS lhc_travel IMPLEMENTATION.
  METHOD get_global_authorizations.
  ENDMETHOD.

*  METHOD earlynumbering_create.
*    DATA entity        TYPE STRUCTURE FOR CREATE yr_ext_demo_flight002.
*    DATA travel_id_max TYPE /dmo/travel_id.
*    " change to abap_false if you get the ABAP Runtime error 'BEHAVIOR_ILLEGAL_STATEMENT'
*
*    " Ensure Travel ID is not set yet (idempotent)- must be checked when BO is draft-enabled
*    LOOP AT entities INTO entity WHERE travelid IS NOT INITIAL.
*      APPEND CORRESPONDING #( entity ) TO mapped-travel.
*    ENDLOOP.
*
*    DATA(entities_wo_travelid) = entities.
*    " Remove the entries with an existing Travel ID
*    DELETE entities_wo_travelid WHERE travelid IS NOT INITIAL.
*
*    " determine the first free travel ID without number range
*    " Get max travel ID from active table
*    SELECT SINGLE FROM ytext_0003_a FIELDS MAX( travel_id ) AS travelid INTO @travel_id_max.
*    " Get max travel ID from draft table
*    SELECT SINGLE FROM ytext_0003_d FIELDS MAX( travelid ) INTO @DATA(max_travelid_draft).
*    IF max_travelid_draft > travel_id_max.
*      travel_id_max = max_travelid_draft.
*    ENDIF.
*
*    " Set Travel ID for new instances w/o ID
*    LOOP AT entities_wo_travelid INTO entity.
*      travel_id_max += 1.
*      entity-travelid = travel_id_max.
*
*      APPEND VALUE #( %cid = entity-%cid
*                      %key = entity-%key
**                      %is_draft = entity-%is_draft
*                      )
*             TO mapped-travel.
*    ENDLOOP.
*  ENDMETHOD.

  METHOD test.
    DATA lt_travel TYPE TABLE FOR CREATE yr_ext_demo_flight002.

    SELECT FROM yr_ext_demo_flight002
    FIELDS *
     ORDER BY travelid DESCENDING
     INTO CORRESPONDING FIELDS OF TABLE @lt_travel
     UP TO 1 ROWS.

    lt_travel[ 1 ]-travelid = 99999999.

    ASSIGN lt_travel[ 1 ]-%control TO FIELD-SYMBOL(<travel>).
    IF sy-subrc = 0.
      DO.
        ASSIGN COMPONENT sy-index OF STRUCTURE <travel> TO FIELD-SYMBOL(<lv_val>) ELSE UNASSIGN.
        IF sy-subrc = 0.
          <lv_val> = if_abap_behv=>mk-on.
        ELSE.
          EXIT.
        ENDIF.
      ENDDO.
    ENDIF.

    CLEAR <travel>-createdat.
    CLEAR <travel>-createdby.
    CLEAR <travel>-lastchangedat.
    CLEAR <travel>-lastchangedby.
    CLEAR <travel>-locallastchangedat.

    MODIFY ENTITIES OF yr_ext_demo_flight002 IN LOCAL MODE
    ENTITY travel
    CREATE AUTO FILL CID WITH lt_travel
    FAILED failed
    REPORTED reported
    MAPPED mapped.


*    MODIFY ENTITIES OF yr_ext_demo_flight002 IN LOCAL MODE
*    ENTITY travel
*    DELETE FROM VALUE #( ( travelid = 99999999 ) ).
  ENDMETHOD.

  METHOD TestActionUu01.
  ENDMETHOD.

  METHOD TestActionUuF01.
  ENDMETHOD.

ENDCLASS.
