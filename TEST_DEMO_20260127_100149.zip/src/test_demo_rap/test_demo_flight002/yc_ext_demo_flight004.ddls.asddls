@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Projection view YC_EXT_DEMO_FLIGHT004'

@Metadata.allowExtensions: true

@ObjectModel.semanticKey: [ 'TravelID' ]

@Search.searchable: true

define root view entity YC_EXT_DEMO_FLIGHT004
  provider contract transactional_query
  as projection on YR_EXT_DEMO_FLIGHT004
{

      @Search.defaultSearchElement: true
      @Search.fuzzinessThreshold: 0.90
  key TravelID,

      @Search.defaultSearchElement: true
      @Consumption.valueHelpDefinition: [{ entity : {name: '/DMO/I_Agency_StdVH', element: 'AgencyID' }, useForValidation: true }]
      @ObjectModel.text.element: [ 'AgencyName' ]
      AgencyID,
      _Agency.Name              as AgencyName,

      @Search.defaultSearchElement: true
      @Consumption.valueHelpDefinition: [{ entity : {name: '/DMO/I_Customer_StdVH', element: 'CustomerID' }, useForValidation: true }]
      @ObjectModel.text.element: [ 'CustomerName' ]
      CustomerID,
      _Customer.LastName        as CustomerName,

      BeginDate,
      EndDate,
      BookingFee,
      TotalPrice,
      
      @Consumption.valueHelpDefinition: [{ entity: {name: 'I_CurrencyStdVH', element: 'Currency' }, useForValidation: true }]
      CurrencyCode,
      Description,
      @ObjectModel.text.element: ['OverallStatusText']
      OverallStatus,

      @EndUserText.label: 'Overall Status Text'
      _OverallStatus._Text.Text as OverallStatusText : localized
}
