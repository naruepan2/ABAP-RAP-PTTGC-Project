@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '##GENERATED YTEXT_0003_A'
define root view entity YR_EXT_DEMO_FLIGHT004
  as select from /DMO/I_Travel_M as Travel
  association [0..1] to /DMO/I_Agency            as _Agency        on $projection.AgencyID = _Agency.AgencyID
  association [0..1] to /DMO/I_Customer          as _Customer      on $projection.CustomerID = _Customer.CustomerID
  association [1..1] to /DMO/I_Overall_Status_VH as _OverallStatus on $projection.OverallStatus = _OverallStatus.OverallStatus
  association [0..1] to I_Currency               as _Currency      on $projection.CurrencyCode = _Currency.Currency
{
  key travel_id      as TravelID,
      agency_id      as AgencyID,
      customer_id    as CustomerID,
      begin_date     as BeginDate,
      end_date       as EndDate,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      booking_fee    as BookingFee,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      total_price    as TotalPrice,
      currency_code  as CurrencyCode,
      description    as Description,
      overall_status as OverallStatus,

      //public associations
      _Customer,
      _Agency,
      _OverallStatus,
      _Currency

}
