CLASS ybp_c_test_customentity_root_c DEFINITION PUBLIC ABSTRACT FINAL FOR BEHAVIOR OF yc_test_customentity_root_ce.
ENDCLASS.

CLASS ybp_c_test_customentity_root_c IMPLEMENTATION.
ENDCLASS.
