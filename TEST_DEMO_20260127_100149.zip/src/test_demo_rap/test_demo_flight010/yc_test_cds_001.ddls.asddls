@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YC_TEST_CDS_001'
@Metadata.ignorePropagatedAnnotations: true
define view entity YC_TEST_CDS_001
  as select from I_Language

  association [0..*] to YC_TEST_CUSTOMENTITY_CHILD_CE on $projection.KeySingleton = YC_TEST_CUSTOMENTITY_CHILD_CE.KeySingleton

{
  key cast( '1' as abap.char(1) ) as KeySingleton,

      YC_TEST_CUSTOMENTITY_CHILD_CE
}
where
  I_Language.Language = $session.system_language
