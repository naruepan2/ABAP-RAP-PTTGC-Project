CLASS ycl_test_customentity001 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_rap_query_provider .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_test_customentity001 IMPLEMENTATION.


  METHOD if_rap_query_provider~select.
    DATA lt_output_parent TYPE TABLE OF yc_test_customentity_root_ce.
    DATA lt_output_child TYPE TABLE OF yc_test_customentity_child_ce.

    zcl_ext_custom_entity_utils=>get_sql_query_provider(
      EXPORTING
        io_request                = io_request
      IMPORTING
        ev_orderby_string         = DATA(lv_orderby_string)
        ev_select_string          =  DATA(lv_select_string)
        ev_sql_where_string       =  DATA(lv_sql_where_string)
        ev_entity_id              =  DATA(lv_entity_id)
        ev_up_to_rows             =  DATA(lv_up_to_rows)
        ev_offset                 =  DATA(lv_offset)
        ev_is_ui_identification   =  DATA(lv_is_ui_identification)
        et_filter_cond            =  DATA(lt_filter_cond)
        eo_filter_as_tree         =  DATA(lo_filter_as_tree)
        et_parameters             =  DATA(lt_parameters)
        et_requested_elements     =  DATA(lt_requested_elements)
        ev_search_expression      =  DATA(lv_search_expression)
        et_sort_elements          =  DATA(lt_sort_elements)
        et_aggregated_elements    =  DATA(lt_aggregated_elements)
        et_aggr_grouped_elements  =  DATA(lt_aggr_grouped_elements)
        ev_is_data_requested      =  DATA(lv_is_data_requested)
        ev_is_total_rec_requested =  DATA(lv_is_total_rec_requested)
    ).

    IF lv_is_data_requested IS INITIAL.
      RETURN.
    ENDIF.

    CASE lv_entity_id.
      WHEN 'YC_TEST_CUSTOMENTITY_ROOT_CE'.

        INSERT VALUE #( keysingleton = '1' ) INTO TABLE lt_output_parent.

        TRY.
            io_response->set_total_number_of_records( iv_total_number_of_records = lines( lt_output_parent ) ).
            io_response->set_data( it_data = lt_output_parent ).
          CATCH cx_rap_query_response_set_twic.
        ENDTRY.

      WHEN 'YC_TEST_CUSTOMENTITY_CHILD_CE'.

    ENDCASE.


  ENDMETHOD.
ENDCLASS.
