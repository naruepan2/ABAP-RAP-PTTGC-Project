@EndUserText.label: 'YUI_TEST_CUSTOMENTITY_ROOT'
@ObjectModel.query.implementedBy: 'ABAP:YCL_TEST_CUSTOMENTITY001'
define root custom entity YC_TEST_CUSTOMENTITY_ROOT_CE
{
      @UI.facet          : [{ position: 10,
                    id   : 'generalID',
                    label: 'General Information',
                    purpose: #STANDARD,
                    type : #IDENTIFICATION_REFERENCE },
                  { position: 20,
                    id   : 'ChildID',
                    label: 'Child Information',
                    purpose: #STANDARD,
                    type : #LINEITEM_REFERENCE,
                    targetElement: '_Child' } ]

      @UI.lineItem       : [{ position: 10 }]
      @UI.identification : [{ position: 10 }]
  key KeySingleton       : abap.char(1);
      @UI.lineItem       : [{ position: 20 }]
      @UI.identification : [{ position: 20 }]
      PurchaseOrder      : ebeln;
      @UI.lineItem       : [{ position: 30 }]
      @UI.identification : [{ position: 30 }]
      Vendor             : lifnr;
      @UI.lineItem       : [{ position: 40 }]
      @UI.identification : [{ position: 40 }]
      IsHidden           : abap_boolean;

      @Semantics.systemDateTime.lastChangedAt: true
      LastChangedAt      : abp_locinst_lastchange_tstmpl;
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      LocalLastChangedAt : abp_locinst_lastchange_tstmpl;

      _Child             : composition [0..*] of YC_TEST_CUSTOMENTITY_CHILD_CE;

}
