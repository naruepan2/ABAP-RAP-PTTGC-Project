@EndUserText.label: 'YUI_TEST_CUSTOMENTITY_ROOT'
define custom entity YC_TEST_CUSTOMENTITY_CHILD_CE

{

      @UI.lineItem       : [{ position: 10 }]
      @UI.identification : [{ position: 10 }]
  key KeyChild           : uuid;
      @UI.lineItem       : [{ position: 20 }]
      @UI.identification : [{ position: 20 }]
  key KeySingleton       : abap.char(1);
      @UI.lineItem       : [{ position: 30 }]
      @UI.identification : [{ position: 30 }]
      PurchaseOrder      : ebeln;
      @UI.lineItem       : [{ position: 40 }]
      @UI.identification : [{ position: 40 }]
      PurchaseOrderItem  : ebelp;
      @UI.lineItem       : [{ position: 50 }]
      @UI.identification : [{ position: 50 }]
      Vendor             : lifnr;
      @UI.lineItem       : [{ position: 60 }]
      @UI.identification : [{ position: 60 }]
      Material           : matnr;
      @UI.lineItem       : [{ position: 70 }]
      @UI.identification : [{ position: 70 }]
      Plant              : werks_d;
      @UI.lineItem       : [{ position: 80 }]
      @UI.identification : [{ position: 80 }]
      Location           : lgort_d;
      @UI.lineItem       : [{ position: 90 }]
      @UI.identification : [{ position: 90 }]
      @Semantics.quantity.unitOfMeasure: 'Unit'
      Quantity           : menge_d;
      @UI.lineItem       : [{ position: 100 }]
      @UI.identification : [{ position: 100 }]
      Unit               : meins;
      @UI.lineItem       : [{ position: 110 }]
      @UI.identification : [{ position: 110 }]
      IsHidden           : abap_boolean;

      @Semantics.systemDateTime.lastChangedAt: true
      LastChangedAt      : abp_locinst_lastchange_tstmpl;
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      LocalLastChangedAt : abp_locinst_lastchange_tstmpl;

      _Parent            : association to parent YC_TEST_CUSTOMENTITY_ROOT_CE on $projection.KeySingleton = _Parent.KeySingleton;
}
