CLASS lhc_root DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR root RESULT result.

    METHODS create FOR MODIFY
      IMPORTING entities FOR CREATE root.

    METHODS update FOR MODIFY
      IMPORTING entities FOR UPDATE root.

    METHODS delete FOR MODIFY
      IMPORTING keys FOR DELETE root.

    METHODS read FOR READ
      IMPORTING keys FOR READ root RESULT result.

    METHODS lock FOR LOCK
      IMPORTING keys FOR LOCK root.

    METHODS rba_child FOR READ
      IMPORTING keys_rba FOR READ root\_child FULL result_requested RESULT result LINK association_links.

    METHODS cba_child FOR MODIFY
      IMPORTING entities_cba FOR CREATE root\_child.

ENDCLASS.

CLASS lhc_root IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD create.
  ENDMETHOD.

  METHOD update.
  ENDMETHOD.

  METHOD delete.
  ENDMETHOD.

  METHOD read.

    DATA(lt_keys) = keys.

  ENDMETHOD.

  METHOD lock.
  ENDMETHOD.

  METHOD rba_child.

    DATA(lt_keys_rba) = keys_rba.

  ENDMETHOD.

  METHOD cba_child.
  ENDMETHOD.

ENDCLASS.

CLASS lhc_child DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS update FOR MODIFY
      IMPORTING entities FOR UPDATE child.

    METHODS delete FOR MODIFY
      IMPORTING keys FOR DELETE child.

    METHODS read FOR READ
      IMPORTING keys FOR READ child RESULT result.

    METHODS rba_parent FOR READ
      IMPORTING keys_rba FOR READ child\_parent FULL result_requested RESULT result LINK association_links.

ENDCLASS.

CLASS lhc_child IMPLEMENTATION.

  METHOD update.
  ENDMETHOD.

  METHOD delete.
  ENDMETHOD.

  METHOD read.
  ENDMETHOD.

  METHOD rba_parent.
  ENDMETHOD.

ENDCLASS.

CLASS lsc_yc_test_customentity_root_ DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS finalize REDEFINITION.

    METHODS check_before_save REDEFINITION.

    METHODS save REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_yc_test_customentity_root_ IMPLEMENTATION.

  METHOD finalize.
  ENDMETHOD.

  METHOD check_before_save.
  ENDMETHOD.

  METHOD save.
  ENDMETHOD.

  METHOD cleanup.
  ENDMETHOD.

  METHOD cleanup_finalize.
  ENDMETHOD.

ENDCLASS.
