CLASS ycl_ytext_0008_ve DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_sadl_exit.
    INTERFACES if_sadl_exit_calc_element_read.
ENDCLASS.


CLASS ycl_ytext_0008_ve IMPLEMENTATION.
  METHOD if_sadl_exit_calc_element_read~calculate.
    " Check the field for your condition and return either abap_true or abap_false for the
    " virtual field.

    DATA lt_original_data TYPE STANDARD TABLE OF yc_ytext_0008_a WITH DEFAULT KEY.

    lt_original_data = CORRESPONDING #( it_original_data ).

    LOOP AT lt_original_data ASSIGNING FIELD-SYMBOL(<fs_original_data>).
      <fs_original_data>-IsTrueVirtual     = abap_true.
      <fs_original_data>-IsTrueVirtualText = 'Test - Is True Text (Virtual Field)'.
    ENDLOOP.

    ct_calculated_data = CORRESPONDING #( lt_original_data ).
  ENDMETHOD.

  METHOD if_sadl_exit_calc_element_read~get_calculation_info.
  ENDMETHOD.
ENDCLASS.
