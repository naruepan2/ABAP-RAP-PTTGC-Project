@AccessControl.authorizationCheck: #NOT_REQUIRED
@Metadata.allowExtensions: true
@EndUserText.label: 'Projection View for YR_YTEXT_0008_A'
@ObjectModel.semanticKey: [ 'TravelID' ]
define root view entity YC_YTEXT_0008_A
  provider contract transactional_query
  as projection on YR_YTEXT_0008_A
{
  key     TravelID,
          AgencyID,
          CustomerID,
          BeginDate,
          EndDate,
          BookingFee,
          TotalPrice,
          CurrencyCode,
          Description,
          OverallStatus,
          Attachment,
          MimeType,
          FileName,
          
          @EndUserText.label: 'Test - Is True'
          IsTrue,
          
          @EndUserText.label: 'Test - Is True (Virtual Field)'
          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_YTEXT_0008_VE'
  virtual IsTrueVirtual : abap_boolean,
          
          @EndUserText.label: 'Test - Is True Text (Virtual Field)'
          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_YTEXT_0008_VE'
  virtual IsTrueVirtualText : abap.char(40),

          LocalLastChangedAt

}
