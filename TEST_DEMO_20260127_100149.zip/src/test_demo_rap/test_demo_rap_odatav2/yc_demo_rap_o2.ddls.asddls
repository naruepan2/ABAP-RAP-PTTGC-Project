@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Form'
//@Metadata.ignorePropagatedAnnotations: true
define root view entity YC_DEMO_RAP_O2
//    provider contract transactional_query
//    as projection on YR_Demo_Form01
  as select from YR_Demo_Form01
  //  association [1..1] to I_CompanyCodeStdVH as _CompanyCode on _CompanyCode.CompanyCode = $projection.CompanyCode
  //  association [1..1] to I_Supplier_VH      as _Supplier    on _Supplier.Supplier = $projection.Supplier
{
          @Consumption.filter.mandatory: true
          @Consumption.filter.defaultValue: '10'
  key     CompanyCode,
  key     AccountingDocument,
  key     FiscalYear,

          ClearingDate,
          ClearingJournalEntryFiscalYear,
          ClearingJournalEntry,
          AssignmentReference,
          Supplier,
          PaymentMethod,
          PaymentBlockingReason,
          BPBankAccountInternalID,
          NetDueDate,
          TransactionCurrency,
          @Aggregation.default: #SUM
          AmountInTransactionCurrency,
          WHTAmountInTransacCrcy,
          NetAmountDocCurr,
          Status,

          @ObjectModel.filter.enabled: false
          ReportingDate,


          _BPTaxID.BPTaxNumber,

          _SupplierCompany.AccountingClerk,

          @Consumption.filter: {
            selectionType: #RANGE,
            multipleSelections: true
          }
          _JournalEntry.DocumentDate,
          _JournalEntry.AccountingDocumentType,
          _JournalEntry.DocumentReferenceID,
          @Consumption.filter.defaultValue: ''
          _JournalEntry.IsReversed,

          _OutgoingCheck.OutgoingCheque,

//          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
//          @ObjectModel.filter.enabled: false
//          @ObjectModel.sort.enabled: false
//          @EndUserText.label: 'Run Cheque Date'
//          //  virtual RunChequeDate : abap.dats,
//          cast ('00000000' as abap.dats)                   as RunChequeDate,
//
//          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
//          @ObjectModel.filter.enabled: false
//          @ObjectModel.sort.enabled: false
//          @EndUserText.label: 'Cheque Date'
//          //  virtual ChequeDate    : abap.dats,
//          cast ('00000000' as abap.dats)                   as ChequeDate,
//
//          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
//          @ObjectModel.filter.enabled: false
//          @ObjectModel.sort.enabled: false
//          @EndUserText.label: 'Bank Number'
//          //  virtual BankNumber    : abap.char(4),
//          cast ('' as abap.char(4))                        as BankNumber,

//          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
          @EndUserText.label: 'Updated By'
          //  virtual UpdatedBy     : syuname,
          cast ('RFC' as syuname)                          as UpdatedBy,

//          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
          //  virtual UpdatedOn     : timestamp,
          cast (tstmp_current_utctimestamp() as timestamp) as UpdatedOn,

//          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
          @EndUserText.label: 'Created By'
          //  virtual CreatedBy     : syuname,
          cast ('ME' as syuname)                           as CreatedBy,

//          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
          //  virtual CreatedOn     : timestamp,
          //  cast ('' as abap.char(4)) as BankNumber,
          cast (tstmp_current_utctimestamp() as timestamp) as CreatedOn,

          /* Associations */
          _BPTaxID,
          _JournalEntry,
          _OutgoingCheck,
          _Supplier,
          _CompanyCode,
          _SupplierCompany
}
