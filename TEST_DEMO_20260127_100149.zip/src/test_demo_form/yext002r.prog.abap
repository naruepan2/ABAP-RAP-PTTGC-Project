*&---------------------------------------------------------------------*
*& Report yext002r
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT yext002r.

TABLES: bkpf.

PARAMETERS:
  p_bukrs TYPE bkpf-bukrs OBLIGATORY,
  p_belnr TYPE bkpf-belnr OBLIGATORY,
  p_gjahr TYPE bkpf-gjahr OBLIGATORY.

START-OF-SELECTION.


  TRY.
      FINAL(lo_fdp_api) = cl_fp_fdp_services=>get_instance(
                           iv_service_definition = 'YUI_DEMO_FORM01_O4'
                           iv_root_node          = 'YC_DEMO_FORM01'
                         ).
      DATA(lt_keys) = lo_fdp_api->get_keys( ).
    CATCH cx_fp_fdp_error INTO DATA(lx_sd).
      MESSAGE lx_sd.
  ENDTRY.

  TRY.
      DATA(lv_xdp) = zcl_t2_somu_form_services=>get_xdp( 'YY_TEST_PDF_FORM02' ).
    CATCH zcx_ext_general_error INTO DATA(lx_somu).
      MESSAGE lx_somu.
  ENDTRY.


  lt_keys[ name = 'COMPANYCODE' ]-value = p_bukrs.
  lt_keys[ name = 'ACCOUNTINGDOCUMENT' ]-value = p_belnr.
  lt_keys[ name = 'FISCALYEAR' ]-value = p_gjahr.

  TRY.
      DATA(lv_xml) = lo_fdp_api->read_to_xml_v2( lt_keys ).
    CATCH cx_fp_fdp_error INTO DATA(lx_fdp).
      MESSAGE lx_fdp.
  ENDTRY.

  TRY.
      cl_fp_ads_util=>render_pdf(
        EXPORTING
          iv_xml_data     = lv_xml
          iv_xdp_layout   = lv_xdp
          iv_locale       = 'en_US'
*          is_options      =
        IMPORTING
          ev_pdf          = DATA(lv_pdf)
      ).
    CATCH cx_fp_ads_util INTO DATA(lx_ads).
      MESSAGE lx_ads.
  ENDTRY.
*  xco_cp=>xstring( lv_xml )->as_string(  IF_XCO_CHAR_CP ).
