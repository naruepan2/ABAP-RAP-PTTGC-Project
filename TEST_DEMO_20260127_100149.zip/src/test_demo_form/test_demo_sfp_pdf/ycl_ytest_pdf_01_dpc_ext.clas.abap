class YCL_YTEST_PDF_01_DPC_EXT definition
  public
  inheriting from YCL_YTEST_PDF_01_DPC
  create public .

public section.
protected section.

  methods TRAVELSET_GET_ENTITY
    redefinition .
  methods TRAVELSET_GET_ENTITYSET
    redefinition .
  PRIVATE SECTION.
ENDCLASS.



CLASS YCL_YTEST_PDF_01_DPC_EXT IMPLEMENTATION.


  METHOD travelset_get_entity.
**TRY.
*CALL METHOD SUPER->TRAVELSET_GET_ENTITY
*  EXPORTING
*    IV_ENTITY_NAME          =
*    IV_ENTITY_SET_NAME      =
*    IV_SOURCE_NAME          =
*    IT_KEY_TAB              =
**    io_request_object       =
**    io_tech_request_context =
*    IT_NAVIGATION_PATH      =
**  IMPORTING
**    er_entity               =
**    es_response_context     =
*    .
**  CATCH /iwbep/cx_mgw_busi_exception.
**  CATCH /iwbep/cx_mgw_tech_exception.
**ENDTRY.

    CASE iv_entity_set_name.
      WHEN 'TravelSet'.
        SELECT SINGLE FROM yi_ext_demo_travel002
          FIELDS *
          INTO CORRESPONDING FIELDS OF @er_entity.
    ENDCASE.
  ENDMETHOD.


  METHOD travelset_get_entityset.
    " TRY.
    " CALL METHOD SUPER->TRAVELSET_GET_ENTITYSET
    "   EXPORTING
    "     IV_ENTITY_NAME           =
    "     IV_ENTITY_SET_NAME       =
    "     IV_SOURCE_NAME           =
    "     IT_FILTER_SELECT_OPTIONS =
    "     IS_PAGING                =
    "     IT_KEY_TAB               =
    "     IT_NAVIGATION_PATH       =
    "     IT_ORDER                 =
    "     IV_FILTER_STRING         =
    "     IV_SEARCH_STRING         =
    " io_tech_request_context  =
    " IMPORTING
    " et_entityset             =
    " es_response_context      =
    "     .
    " CATCH /iwbep/cx_mgw_busi_exception.
    " CATCH /iwbep/cx_mgw_tech_exception.
    " ENDTRY.

    CASE iv_entity_set_name.
      WHEN 'TravelSet'.
        SELECT FROM yi_ext_demo_travel002
          FIELDS *
          INTO CORRESPONDING FIELDS OF TABLE @et_entityset.
    ENDCASE.
  ENDMETHOD.
ENDCLASS.
