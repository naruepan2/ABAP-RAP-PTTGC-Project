@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YC_EXT_DEMO_TRAVEL002'

@Metadata.allowExtensions: true

@Search.searchable: true

@ObjectModel.semanticKey: [ 'TravelID' ]

define root view entity YC_EXT_DEMO_TRAVEL002
  provider contract transactional_query
  as projection on YI_EXT_DEMO_TRAVEL002
{
      @Search.defaultSearchElement: true
      
  key travel_id                 as TravelID,

      @Search.defaultSearchElement: true
      @Consumption.valueHelpDefinition: [{ entity : {name: '/DMO/I_Agency_StdVH', element: 'AgencyID' }, useForValidation: true }]
      @ObjectModel.text.element: [ 'AgencyName' ]
      agency_id                 as AgencyID,
      _Agency.Name              as AgencyName,

      @Search.defaultSearchElement: true
      @Consumption.valueHelpDefinition: [{ entity : {name: '/DMO/I_Customer_StdVH', element: 'CustomerID' }, useForValidation: true }]
      @ObjectModel.text.element: [ 'CustomerName' ]
      customer_id               as CustomerID,
      customer_name             as CustomerName,

      begin_date                as BeginDate,
      end_date                  as EndDate,

      @Semantics.amount.currencyCode: 'CurrencyCode'
      booking_fee               as BookingFee,

      @Semantics.amount.currencyCode: 'CurrencyCode'
      total_price               as TotalPrice,
      currency_code             as CurrencyCode,

      @ObjectModel.text.element: ['OverallStatusText']
      @Consumption.valueHelpDefinition: [{ entity : {name: '/DMO/I_Overall_Status_VH', element: 'OverallStatus' }, useForValidation: true }]
      overall_status            as OverallStatus,
      @EndUserText.label: 'Overall Status Text'
      _OverallStatus._Text.Text as OverallStatusText : localized,
      overall_criticality       as OverallCriticality,

      description               as Description,

      @UI.hidden: true
      created_by,
      @UI.hidden: true
      created_at,
      @UI.hidden: true
      last_changed_by,
      @UI.hidden: true
      last_changed_at,
      
      /* Associations */
      _Agency,
      _Currency,
      _Customer,
      _OverallStatus
}
