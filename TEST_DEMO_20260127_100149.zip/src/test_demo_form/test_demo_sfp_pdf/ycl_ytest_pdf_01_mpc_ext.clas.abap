class YCL_YTEST_PDF_01_MPC_EXT definition
  public
  inheriting from YCL_YTEST_PDF_01_MPC
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS YCL_YTEST_PDF_01_MPC_EXT IMPLEMENTATION.
ENDCLASS.
