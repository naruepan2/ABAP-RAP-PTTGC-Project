CLASS ybp_i_ext_demo_travel002 DEFINITION PUBLIC ABSTRACT FINAL FOR BEHAVIOR OF yi_ext_demo_travel002.
  PUBLIC SECTION.
    CLASS-METHODS print_pdf_form
      IMPORTING iv_data       TYPE xstring
      RETURNING VALUE(rv_pdf) TYPE xstring.
ENDCLASS.


CLASS ybp_i_ext_demo_travel002 IMPLEMENTATION.
  METHOD print_pdf_form.
*    rv_pdf = zcl_classic_sfp_form_services=>get_pdf( iv_name        = 'YY_TEST_PDF_FORM01'
*                                                     iv_docxml_data = iv_data ).
  ENDMETHOD.
ENDCLASS.
