@EndUserText.label: 'YD_EXT_DEMO_TRAVEL002'
define abstract entity YD_EXT_DEMO_TRAVEL002
  //  with parameters parameter_name : parameter_type
{
  mimeType : abap.string(0);
  value    : abap.string(0);
  xvalue   : abap.string(0);
}
