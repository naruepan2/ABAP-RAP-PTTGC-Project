CLASS lhc_travel DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR travel RESULT result.

    METHODS printpdf FOR MODIFY
      IMPORTING keys FOR ACTION travel~printpdf RESULT result.

ENDCLASS.


CLASS lhc_travel IMPLEMENTATION.
  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD printpdf.
    TYPES: BEGIN OF ts_footer,
             footer1 TYPE string,
             footer2 TYPE string,
             footer3 TYPE string,
           END OF ts_footer.

    TYPES: BEGIN OF ts_output,
             logo   TYPE xstring,
             data   TYPE TABLE OF yi_ext_demo_travel002 WITH EMPTY KEY,
             footer TYPE ts_footer,
           END OF ts_output.

    READ ENTITIES OF yi_ext_demo_travel002 IN LOCAL MODE
         ENTITY travel
         ALL FIELDS WITH CORRESPONDING #( keys )
         RESULT DATA(lt_travels).

    DATA lv_docxml   TYPE xstring.
    DATA lv_mimetype TYPE zcl_ext_pdf_utilities=>ty_mimetype.
    DATA ls_output   TYPE ts_output.

    TRY.
        DATA(lv_logo) = cl_somu_form_services=>get_instance( )->get_graphic( iv_type = 'S'              " Output Management: Graphics Type
                                                                             iv_id   = 'SAP_LOGO' ).
      CATCH cx_somu_error.
        " handle exception
    ENDTRY.

    SORT lt_travels BY travel_id.

    ls_output-logo   = lv_logo.
    ls_output-data   = CORRESPONDING #( lt_travels ).
    ls_output-footer = VALUE #( footer1 = 'FOOTER1'
                                footer2 = 'FOOTER2'
                                footer3 = 'FOOTER3' ).

    zcl_ext_pdf_utilities=>get_instance( )->build_xml_pdf_to_xstring( IMPORTING ev_x_xmlpdf = lv_docxml
                                                                                ev_mimetype = lv_mimetype
                                                                      CHANGING  cs_data     = ls_output ).

    TRY.
        DATA(lv_xdp) = zcl_t2_somu_form_services=>get_xdp( 'YY_TEST_PDF_FORM01' ). "<< ปรับชื่อฟอร์ม

        TRY.
            FINAL(lo_fdp_api) = cl_fp_fdp_services=>get_instance( iv_service_definition = 'YUI_DEMO_FORM01_O4'
                                                                  iv_root_node          = 'YC_DEMO_FORM01' ).
            DATA(lt_keys) = lo_fdp_api->get_keys( ).
            DATA(lv_xdp2) = zcl_t2_somu_form_services=>get_xdp( 'YY_TEST_PDF_FORM02' )..

            lt_keys[ name = 'COMPANYCODE' ]-value = '10'.
            lt_keys[ name = 'ACCOUNTINGDOCUMENT' ]-value = '1058000047'.
            lt_keys[ name = 'FISCALYEAR' ]-value = '2025'.

            TRY.
                " TODO: variable is assigned but never used (ABAP cleaner)
                DATA(lv_cds_xml) = lo_fdp_api->read_to_xml_v2( lt_keys ).
              CATCH cx_fp_fdp_error.
                " handle exception
            ENDTRY.
          CATCH cx_fp_fdp_error INTO DATA(lx_sd). " TODO: variable is assigned but never used (ABAP cleaner)
        ENDTRY.
      CATCH zcx_ext_general_error.
        RETURN.
    ENDTRY.

    TRY.
        " Render PDF
        cl_fp_ads_util=>render_pdf( EXPORTING iv_xml_data     = lv_docxml
                                              iv_xdp_layout   = lv_xdp
                                              iv_locale       = 'en_US'
                                              is_options      = VALUE cl_fp_ads_util=>ty_gs_options_pdf( )
                                    IMPORTING ev_pdf          = DATA(lv_x_pdf)
                                    " TODO: variable is assigned but never used (ABAP cleaner)
                                              ev_pages        = DATA(lv_pages)
                                              ev_trace_string = DATA(ev_trace_string) ).

        " Render PDF
        cl_fp_ads_util=>render_pdf( EXPORTING iv_xml_data     = lv_cds_xml
                                              iv_xdp_layout   = lv_xdp2
                                              iv_locale       = 'en_US'
                                              is_options      = VALUE cl_fp_ads_util=>ty_gs_options_pdf( )
                                    IMPORTING ev_pdf          = DATA(lv_x_pdf2)
                                    " TODO: variable is assigned but never used (ABAP cleaner)
                                              ev_pages        = DATA(lv_pages2)
                                    " TODO: variable is assigned but never used (ABAP cleaner)
                                              ev_trace_string = DATA(ev_trace_string2) ).
      CATCH cx_fp_ads_util INTO DATA(lx_fp_ads_util).
        DATA(lv_msg_error) = lx_fp_ads_util->get_longtext( ).
    ENDTRY.

    " Test Merge 2 PDF into 1 PDF
    DATA lo_pdf_merger TYPE REF TO if_rspo_pdf_merger.

    lo_pdf_merger = cl_rspo_pdf_merger=>create_instance( ).

    IF lv_x_pdf IS NOT INITIAL.
      lo_pdf_merger->add_document( document = lv_x_pdf ).
    ENDIF.
    IF lv_x_pdf2 IS NOT INITIAL.
      lo_pdf_merger->add_document( document = lv_x_pdf2 ).
    ENDIF.

    TRY.
        DATA(lv_merged_document) = lo_pdf_merger->merge_documents( ).
      CATCH cx_rspo_pdf_merger.
    ENDTRY.

*    DATA(lv_x_pdf) = ybp_i_ext_demo_travel002=>print_pdf_form( lv_docxml ).

    DATA(lv_pdf) = zcl_ext_pdf_utilities=>get_instance( )->encode_xstring_to_x64( iv_xstring = lv_merged_document ).

    result = VALUE #( ( %cid_ref = keys[ 1 ]-%cid_ref
                        %key     = keys[ 1 ]-%key
                        %param   = VALUE #( mimetype = lv_mimetype
                                            value    = lv_pdf
                                            xvalue   = lv_x_pdf ) ) ).

    " result = VALUE #( FOR key IN keys
    " ( %cid_ref = key-%cid_ref
    " %key     = key-%key
    " %param   = VALUE #( mimetype = lv_mimetype
    " value    = lv_pdf
    " xvalue   = lv_x_pdf ) ) ).
  ENDMETHOD.
ENDCLASS.


CLASS lsc_yi_ext_demo_travel002 DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.
    METHODS save_modified    REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.


CLASS lsc_yi_ext_demo_travel002 IMPLEMENTATION.
  METHOD save_modified.
  ENDMETHOD.

  METHOD cleanup_finalize.
  ENDMETHOD.
ENDCLASS.
