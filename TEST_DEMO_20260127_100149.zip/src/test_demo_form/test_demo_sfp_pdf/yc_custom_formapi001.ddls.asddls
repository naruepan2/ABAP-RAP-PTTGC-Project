@EndUserText.label: 'YC_Custom_FormAPI001'
@ObjectModel.query.implementedBy: 'ABAP:YCL_CUSTOM_FORMAPI001'
define root custom entity YC_Custom_FormAPI001
// with parameters parameter_name : parameter_type
{
  key uuid : sysuuid_x16;
  logo : abap.rawstring( 0 );
  
}
