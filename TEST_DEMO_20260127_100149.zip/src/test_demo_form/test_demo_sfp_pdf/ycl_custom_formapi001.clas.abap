CLASS ycl_custom_formapi001 DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_rap_query_provider.
ENDCLASS.


CLASS ycl_custom_formapi001 IMPLEMENTATION.
  METHOD if_rap_query_provider~select.
    DATA lt_data    TYPE TABLE OF yc_custom_formapi001.
    " TODO: variable is assigned but never used (ABAP cleaner)
    DATA lt_travels TYPE TABLE OF yi_ext_demo_travel002.

    zcl_ext_custom_entity_utils=>get_sql_query_provider( io_request = io_request ).

    SELECT FROM yi_ext_demo_travel002
      FIELDS *
      INTO TABLE @lt_travels.

    TRY.
        lt_data = VALUE #( ( uuid = xco=>uuid( )->value
                             logo = cl_somu_form_services=>get_instance( )->get_graphic( iv_type = 'S'              " Output Management: Graphics Type
                                                                                         iv_id   = 'SAP_LOGO' ) ) ).
      CATCH cx_somu_error.
        "handle exception
    ENDTRY.

    TRY.
        io_response->set_data( it_data = lt_data ).
        io_response->set_total_number_of_records( iv_total_number_of_records = lines( lt_data ) ).
      CATCH cx_rap_query_response_set_twic.
        " handle exception
    ENDTRY.
  ENDMETHOD.
ENDCLASS.
