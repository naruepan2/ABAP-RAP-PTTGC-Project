CLASS ycl_test_print_sfp DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
ENDCLASS.


CLASS ycl_test_print_sfp IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.
    TYPES: BEGIN OF ts_output,
             logo TYPE xstring,
             data TYPE TABLE OF yi_ext_demo_travel002 WITH EMPTY KEY,
           END OF ts_output.

    TRY.
        SELECT FROM yi_ext_demo_travel002
          FIELDS *
          INTO TABLE @DATA(lt_travels)
          UP TO 10 ROWS.

        FINAL(form_service) = cl_somu_form_services=>get_instance( ).
        DATA(i_xml_content) = VALUE xstring(  ).
        DATA(result) = VALUE xstring(  ).

        TRY.
            DATA(lv_logo) = cl_somu_form_services=>get_instance( )->get_graphic( iv_type = 'S'              " Output Management: Graphics Type
                                                                                 iv_id   = 'SAP_LOGO' ).
          CATCH cx_somu_error.
            " handle exception
        ENDTRY.

        DATA ls_output   TYPE ts_output.
        ls_output-logo = lv_logo.
        ls_output-data = CORRESPONDING #( lt_travels ).

        CALL TRANSFORMATION id SOURCE itab = lt_travels
                               RESULT XML i_xml_content.

        form_service->get_document( EXPORTING
                                      iv_form_name      = 'YY_TEST_PDF_FORM01'
                                      iv_form_language  = sy-langu
                                      iv_form_country   = 'TH'
                                      is_render_options = VALUE #( create_pdf = abap_true )
                                      iv_xml            = i_xml_content
                                    IMPORTING
                                      ev_content        = result ).

        CALL FUNCTION 'EFG_DISPLAY_PDF'
          EXPORTING
            i_pdf = result.
      CATCH cx_somu_error.
        MESSAGE e185(edocument) INTO cl_edocument=>gv_error_txt.
        cl_edocument=>raise_edoc_exception( ).
    ENDTRY.

**    TRY.
**        DATA(lo_fdp_api) = cl_fp_fdp_services=>get_instance( iv_service_definition = 'YUI_CUSTOM_FORMAPI001_O4'
**                                                             iv_root_node          = 'YC_Custom_FormAPI001'
**                                                           ).
**        DATA(lt_keys) = lo_fdp_api->get_keys( ).
**
**        lt_keys[ name = 'UUID' ]-value = xco=>uuid( )->value.
**
**        " TODO: variable is assigned but never used (ABAP cleaner)
**        DATA(lv_xsd)  = lo_fdp_api->get_xsd_v2( ).
**        " TODO: variable is assigned but never used (ABAP cleaner)
**        DATA(lv_xmldata) = lo_fdp_api->read_to_xml_v2( lt_keys ).
**        " TODO: variable is assigned but never used (ABAP cleaner)
**        DATA(lt_data) = lo_fdp_api->read_to_data( lt_keys ).
**
**        out->write( lt_keys ).
**
**        call FUNCTION 'HR_IT_DISPLAY_WITH_PDF'
**          EXPORTING
**            iv_pdf    =  lv_xmldata
***          TABLES
***            otf_table =
**          .
***        CATCH cx_fp_ads_util.
**      CATCH cx_fp_fdp_error.
**    ENDTRY.

**    TYPES: BEGIN OF  ty_header,
**             logo    TYPE xstring,
**             header1 TYPE string,
**             header2 TYPE string,
**           END OF ty_header.
**
**    TYPES: BEGIN OF  ty_items,
**             item1 TYPE string,
**             item2 TYPE string,
**             item3 TYPE string,
**           END OF ty_items.
**
**    TYPES: BEGIN OF  ty_footer,
**             footer1 TYPE string,
**             footer2 TYPE string,
**           END OF ty_footer.
**
**    TYPES: BEGIN OF ty_toprint,
**             header TYPE ty_header,
**             items  TYPE TABLE OF ty_items WITH EMPTY KEY,
**             footer TYPE ty_footer,
**           END OF ty_toprint.
**
**    DATA ls_print TYPE ty_toprint.
**
**    TRY.
**        DATA(lv_logo) = cl_somu_form_services=>get_instance( )->get_graphic( iv_type = 'S'              " Output Management: Graphics Type
**                                                                             iv_id   = 'SAP_LOGO' ).
**      CATCH cx_somu_error.
**        " handle exception
**    ENDTRY.
**
**    ls_print = VALUE #( header = VALUE #( logo    = lv_logo
**                                          header2 = 'HEADER 2' )
**                        items  = VALUE #( ( item1 = 'ITEMS 11'
**                                            item2 = 'ITEMS 12'
**                                            item3 = 'ITEMS 13' )
**                                          ( item1 = 'ITEMS 21'
**                                            item2 = 'ITEMS 22'
**                                            item3 = 'ITEMS 23' ) )
**                        footer = VALUE #( footer1 = 'FOOTER 1'
**                                          footer2 = 'FOOTER 2' ) ).
**
**    DATA lv_funcname     TYPE funcname.
**    DATA ls_sfpdocparams TYPE sfpdocparams.
**    DATA lv_docxml       TYPE xstring.
**
**    DATA ls_outputparams TYPE sfpoutputparams.
**
**    " TODO: variable is assigned but never used (ABAP cleaner)
**    DATA lv_formout      TYPE fpformoutput.
**
**    NEW zcl_s4cloud_pdf_utilities( )->build_xml_pdf_to_xstring( EXPORTING iv_form_name     = 'TESTFORM'
**                                                                          iv_sub_form_name = 'form'
***                                                                          iv_encoding      =
**                                                                IMPORTING ev_x_xmlpdf      = lv_docxml
**                                                                CHANGING  cs_data          = ls_print ).
**
**    TRY.
**        CALL FUNCTION 'FP_FUNCTION_MODULE_NAME'
**          EXPORTING i_name     = 'YY_TEST_PDF_FORM01'
**          IMPORTING e_funcname = lv_funcname.
**
**        " Output Parameter für neues Interface
**        " Druckerdialog ausblenden
**        ls_outputparams-nodialog = 'X'.
**        " Druckvorschau
**        ls_outputparams-preview  = 'X'.
**        " Druckbutton ausblenden
**        " ls_outputparams-noprint  = 'X'.
**        " Druckvorschaubutton ausblenden
**        " ls_outputparams-nopreview   = 'X'.
**        " Name Ausgabegerät (Drucker)
**        ls_outputparams-dest     = 'LP01'.
***  ls_outputparams-nopdf    =
**** Spoolsteuerung
**** Neuen Spoolrequest anlegen
***  ls_outputparams-reqnew   = 'X'.
**** Spoolrequest schließen
***  ls_outputparams-reqfinal = 'X'.
**
*** PDF XSTRING anfordern
*** ls_outputparams-getpdf   = 'X'.
**
**        " Formularprozessierung: Job beginnen
**        CALL FUNCTION 'FP_JOB_OPEN'
**          CHANGING   ie_outputparams = ls_outputparams
**          EXCEPTIONS cancel          = 1
**                     usage_error     = 2
**                     system_error    = 3
**                     internal_error  = 4
**                     OTHERS          = 5.
**
**        IF sy-subrc = 0.
**          " Language and country setting (here US as an example)
**          ls_sfpdocparams-langu   = 'E'.
**          ls_sfpdocparams-country = 'US'.
**
**          CALL FUNCTION lv_funcname
**            EXPORTING  /1bcdwb/docparams  = ls_sfpdocparams
**                       /1bcdwb/docxml     = lv_docxml
**            IMPORTING  /1bcdwb/formoutput = lv_formout
**            EXCEPTIONS OTHERS             = 4.
**          IF sy-subrc <> 0.
**            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
**                    INTO FINAL(mtext)
**                    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
**            out->write( mtext ).
**          ENDIF.
**
**          " TODO: variable is assigned but never used (ABAP cleaner)
**          DATA lv_result TYPE sfpjoboutput.
**
**          " Formularprozessierung: Job beenden
**          CALL FUNCTION 'FP_JOB_CLOSE'
**            IMPORTING  e_result       = lv_result
**            EXCEPTIONS usage_error    = 1
**                       system_error   = 2
**                       internal_error = 3
**                       OTHERS         = 4.
**          IF sy-subrc <> 0.
**            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
**                    INTO FINAL(mtext2)
**                    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
**            out->write( mtext2 ).
**          ENDIF.
**        ELSE.
**          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
**                  INTO FINAL(mtext3)
**                  WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
**          out->write( mtext3 ).
**        ENDIF.
**      CATCH cx_fp_api_repository
**            cx_fp_api_usage
**            cx_fp_api_internal INTO DATA(lx_error).
**        out->write( lx_error->get_longtext( ) ).
**    ENDTRY.
  ENDMETHOD.
ENDCLASS.
