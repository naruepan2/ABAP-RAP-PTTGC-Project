@EndUserText.label: 'Preview'
define abstract entity YD_Demo_Form01_Preview_O
{
    Binary : abap.rawstring;
}
