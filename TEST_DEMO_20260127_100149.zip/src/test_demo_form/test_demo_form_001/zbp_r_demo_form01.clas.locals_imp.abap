CLASS lcl_buffer DEFINITION FINAL.

  PUBLIC SECTION.

    TYPES:
      BEGIN OF ty_rap,
        key      TYPE STRUCTURE FOR KEY OF yr_demo_form01,
        report_l TYPE TABLE FOR REPORTED LATE yr_demo_form01,
        failed_l TYPE TABLE FOR FAILED LATE yr_demo_form01,
      END OF ty_rap.

    CLASS-METHODS add
      IMPORTING
        is_key    TYPE ty_rap-key
        iv_itemid TYPE clike
        iv_qname  TYPE clike
        iv_pdl    TYPE xstring
        iv_name   TYPE clike.

    CLASS-METHODS print
      CHANGING
        ct_report TYPE ty_rap-report_l
        ct_failed TYPE ty_rap-failed_l.

  PROTECTED SECTION.

  PRIVATE SECTION.

    TYPES:
      BEGIN OF ty_queue,
        key    TYPE ty_rap-key,
        itemid TYPE string,
        qname  TYPE string,
        pdl    TYPE xstring,
        name   TYPE string,
      END OF ty_queue,
      tt_queue TYPE STANDARD TABLE OF ty_queue WITH EMPTY KEY.

    CLASS-DATA mt_queue TYPE tt_queue.


ENDCLASS.

CLASS lcl_buffer IMPLEMENTATION.

  METHOD add.
    INSERT
      VALUE ty_queue(
        key    = is_key
        itemid = iv_itemid
        qname  = iv_qname
        pdl    = iv_pdl
        name   = iv_name
    ) INTO TABLE mt_queue.
  ENDMETHOD.


  METHOD print.

    LOOP AT mt_queue ASSIGNING FIELD-SYMBOL(<ls_queue>).

      cl_print_queue_utils=>create_queue_item_by_data(
        EXPORTING
          iv_qname            = CONV #( <ls_queue>-qname )
          iv_print_data       = <ls_queue>-pdl
          iv_name_of_main_doc = CONV #( <ls_queue>-name )
          iv_itemid           = CONV #( <ls_queue>-itemid )
        IMPORTING
          ev_err_msg          = DATA(lv_err_msg)
      ).

      INSERT CORRESPONDING #( <ls_queue>-key ) INTO TABLE ct_report ASSIGNING FIELD-SYMBOL(<ls_reported>).

      IF lv_err_msg IS NOT INITIAL.
        <ls_reported>-%msg = NEW zcx_ext_general_error( iv_severity = if_abap_behv_message=>severity-error ).

*        new_message_with_text(
*                               severity = if_abap_behv_message=>severity-error
*                               text     = lv_err_msg
*                             ).
      ELSE.
        <ls_reported>-%msg = NEW zcx_ext_general_error( iv_severity = if_abap_behv_message=>severity-success ).
*        <ls_reported>-%msg = new_message_with_text(
*                               severity = if_abap_behv_message=>severity-success
*                               text     = |Printed { lv_itemid }|
*                             ).
      ENDIF.

      CLEAR: lv_err_msg.

    ENDLOOP.
  ENDMETHOD.

ENDCLASS.

CLASS lhc_root DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR root RESULT result.

    METHODS read FOR READ
      IMPORTING keys FOR READ root RESULT result.

    METHODS lock FOR LOCK
      IMPORTING keys FOR LOCK root.
    METHODS preview FOR MODIFY
      IMPORTING keys FOR ACTION root~preview RESULT result.

    METHODS print FOR MODIFY
      IMPORTING keys FOR ACTION root~print.
    METHODS getdefaultcompany FOR READ
      IMPORTING keys FOR FUNCTION root~getdefaultcompany RESULT result.

ENDCLASS.

CLASS lhc_root IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD read.
  ENDMETHOD.

  METHOD lock.
  ENDMETHOD.

  METHOD preview.
    LOOP AT keys ASSIGNING FIELD-SYMBOL(<ls_key>).
*      <ls_report>-%msg = new_message_with_text( text = 'Preview is not supported yet.' ).
*      <ls_report>-%state_area = if_abap_behv=>state_area_all.
      INSERT new_message_with_text( text = 'Preview is not supported yet.' severity = if_abap_behv_message=>severity-information ) INTO TABLE reported-%other.
*      INSERT CORRESPONDING #( <ls_key> ) INTO TABLE reported-root ASSIGNING FIELD-SYMBOL(<ls_report>).
*      <ls_report>-%state_area = if_abap_behv=>state_area_all.

*      INSERT CORRESPONDING #( <ls_key> ) INTO TABLE failed- ASSIGNING FIELD-SYMBOL(<ls_failed>).
*      <ls_failed>-%fail-cause = if_abap_behv=>cause-unspecific.

      INSERT new_message_with_text( text = 'Another Error 2' ) INTO TABLE reported-%other.
      INSERT new_message_with_text( text = 'Another Error 3' ) INTO TABLE reported-%other.
**      INSERT CORRESPONDING #( <ls_key> ) INTO TABLE reported-root.
*      <ls_report>-%msg = new_message_with_text( text = 'Preview is not supported yet.' severity = if_abap_behv_message=>severity-information ).
*      <ls_report>-%state_area = 'PREVIEW'.
*      <ls_report>-%action-preview = if_abap_behv=>mk-on.
*
*      INSERT CORRESPONDING #( <ls_key> ) INTO TABLE reported-root ASSIGNING <ls_report>.
*      <ls_report>-%msg = new_message_with_text( text = 'Another Error 2' ).
*      <ls_report>-%state_area = 'PREVIEW'.
*      <ls_report>-%action-preview = if_abap_behv=>mk-on.
*      <ls_report>-%msg = new_message_with_text( text = 'Another Error 3' ).
*      <ls_report>-%state_area = 'PREVIEW'.
*      <ls_report>-%action-preview = if_abap_behv=>mk-on.

    ENDLOOP.
  ENDMETHOD.

  METHOD print.

    TRY.
        FINAL(lo_fdp_api) = cl_fp_fdp_services=>get_instance(
                             iv_service_definition = 'YUI_DEMO_FORM01_O4'
                             iv_root_node          = 'YC_DEMO_FORM01'
                           ).
        DATA(lt_keys) = lo_fdp_api->get_keys( ).
      CATCH cx_fp_fdp_error INTO DATA(lx_sd).
        APPEND NEW zcx_ext_general_error( io_previous = lx_sd ) TO reported-%other.
        INSERT VALUE #( ) INTO TABLE failed-root.
        "handle exception
    ENDTRY.

    TRY.
        DATA(lv_xdp) = zcl_t2_somu_form_services=>get_xdp( 'YY_TEST_PDF_FORM02' ).
      CATCH zcx_ext_general_error INTO DATA(lx_somu).
        APPEND NEW zcx_ext_general_error( io_previous = lx_somu ) TO reported-%other.
        INSERT VALUE #( ) INTO TABLE failed-root.
    ENDTRY.

*    zcl_fp_tmpl_store_client

    LOOP AT keys ASSIGNING FIELD-SYMBOL(<ls_key>).

      lt_keys[ name = 'COMPANYCODE' ]-value = <ls_key>-companycode.
      lt_keys[ name = 'ACCOUNTINGDOCUMENT' ]-value = <ls_key>-accountingdocument.
      lt_keys[ name = 'FISCALYEAR' ]-value = <ls_key>-fiscalyear.

      TRY.
          DATA(lv_xml) = lo_fdp_api->read_to_xml_v2( lt_keys ).
        CATCH cx_fp_fdp_error.
          "handle exception
      ENDTRY.

      TRY.
*          cl_fp_ads_util=>render_4_pq(
*            EXPORTING
*              iv_xml_data     = lv_xml
*              iv_xdp_layout   = lv_xdp
*              iv_locale       = 'en_US'
*              iv_pq_name      = CONV #( <ls_key>-%param-printqueue )
**          is_options      =
*            IMPORTING
*              ev_pdl          = DATA(lv_pdl)
*              ev_pages        = DATA(lv_pages)
*          ).
          cl_fp_ads_util=>render_pdf(
            EXPORTING
              iv_xml_data     = lv_xml
              iv_xdp_layout   = lv_xdp
              iv_locale       = 'en_US'
*              iv_pq_name      = CONV #( <ls_key>-%param-printqueue )
*          is_options      =
            IMPORTING
              ev_pdf          = DATA(lv_pdl)
              ev_pages        = DATA(lv_pages)
          ).

          DATA(lv_itemid) = cl_print_queue_utils=>create_queue_itemid( ).

          lcl_buffer=>add(
            is_key    = <ls_key>-%key
            iv_itemid = lv_itemid
            iv_qname  = <ls_key>-%param-printqueue
            iv_pdl    = lv_pdl
            iv_name   = |{ <ls_key>-accountingdocument }/{ <ls_key>-companycode }/{ <ls_key>-fiscalyear }|
          ).

*          cl_print_queue_utils=>create_queue_item_by_data(
*            EXPORTING
*              iv_qname            = CONV #( <ls_key>-%param-printqueue )
*              iv_print_data       = lv_pdl
*              iv_name_of_main_doc = |{ <ls_key>-accountingdocument }/{ <ls_key>-companycode }/{ <ls_key>-fiscalyear }|
*              iv_itemid           = cl_print_queue_utils=>create_queue_itemid( )
**              iv_pages            =
**              iv_number_of_copies =
**              it_attachment_data  =
*            IMPORTING
*              ev_err_msg          = DATA(lv_err_msg)
*          ).
*
*          INSERT CORRESPONDING #( <ls_key> ) INTO TABLE reported-root ASSIGNING FIELD-SYMBOL(<ls_reported>).
*
*          IF lv_err_msg IS NOT INITIAL.
*            <ls_reported>-%msg = new_message_with_text(
*                                   severity = if_abap_behv_message=>severity-error
*                                   text     = lv_err_msg
*                                 ).
*          ELSE.
*            <ls_reported>-%msg = new_message_with_text(
*                                   severity = if_abap_behv_message=>severity-success
*                                   text     = |Printed { lv_itemid }|
*                                 ).
*          ENDIF.
*
*          CLEAR: lv_err_msg.

        CATCH cx_fp_ads_util.
      ENDTRY.

    ENDLOOP.

  ENDMETHOD.

  METHOD getdefaultcompany.

*    INSERT CORRESPONDING #( keys[ 1 ] ) INTO TABLE result.


    SELECT FROM i_companycode
      FIELDS
        companycode
      WHERE companycode BETWEEN '10' AND '40'
      INTO TABLE @FINAL(lt_comp).

    LOOP AT lt_comp ASSIGNING FIELD-SYMBOL(<ls_comp>).
      INSERT CORRESPONDING #( keys[ 1 ] ) INTO TABLE result ASSIGNING FIELD-SYMBOL(<ls_result>).
      <ls_result>-%param-companycode = <ls_comp>-companycode.
    ENDLOOP.

  ENDMETHOD.

ENDCLASS.

CLASS lsc_yr_demo_form01 DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS finalize REDEFINITION.

    METHODS check_before_save REDEFINITION.

    METHODS save REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_yr_demo_form01 IMPLEMENTATION.

  METHOD finalize.
    lcl_buffer=>print(
      CHANGING
        ct_report = reported-root
        ct_failed = failed-root
    ).
  ENDMETHOD.

  METHOD check_before_save.
  ENDMETHOD.

  METHOD save.
  ENDMETHOD.

  METHOD cleanup.
  ENDMETHOD.

  METHOD cleanup_finalize.
  ENDMETHOD.

ENDCLASS.
