@EndUserText.label: 'Print'
define abstract entity YD_Demo_Form01_Print
{
  //  @Consumption.defaultValue: 'YQ_DEMO_FORM_01'
  @UI.defaultValue: 'YQ_DEMO_FORM_01'
  @Consumption.valueHelpDefinition: [{
    entity   : {
      name   : 'ZI_EXT_PrintQueueVH',
      element: 'PrintQueue'
    }
  }]
  PrintQueue : abap.sstring(32);

  @Semantics.fiscal.yearPeriod: true
  TestPeriod : abap.numc( 7 );

  TestChar   : abap.char(10);

//  @Semantics.largeObject: {
//    mimeType : 'Mimetype',
//    fileName : 'Filename',
//  //    contentDispositionPreference: #INLINE
//  acceptableMimeTypes: [ 'application/vnd.ms excel',
//     'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
//      contentDispositionPreference: #ATTACHMENT
//  }
//  Attachment : abap.rawstring;
//
//  @UI.hidden : true
//  Filename   : abap.string;
//
//  @Semantics.mimeType: true
//  @UI.hidden : true
//  Mimetype   : abap.string;

}
