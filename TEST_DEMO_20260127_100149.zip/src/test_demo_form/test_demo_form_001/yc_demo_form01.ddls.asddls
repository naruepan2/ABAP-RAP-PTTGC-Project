@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Form'
//@Metadata.ignorePropagatedAnnotations: true
define root view entity YC_Demo_Form01
  provider contract transactional_query
//  with parameters
//    P_KeyDate : abap.dats
  as projection on YR_Demo_Form01
  //  association [1..1] to I_CompanyCodeStdVH as _CompanyCode on _CompanyCode.CompanyCode = $projection.CompanyCode
  //  association [1..1] to I_Supplier_VH      as _Supplier    on _Supplier.Supplier = $projection.Supplier
{
          @Consumption.filter.mandatory: true
          @Consumption.filter.defaultValue: '10'
  key     CompanyCode,
  key     AccountingDocument,
  key     FiscalYear,

          ClearingDate,
          ClearingJournalEntryFiscalYear,
          ClearingJournalEntry,
          AssignmentReference,
          Supplier,
          PaymentMethod,
          PaymentBlockingReason,
          BPBankAccountInternalID,
          NetDueDate,
          TransactionCurrency,
//          @Aggregation.default: #SUM
          AmountInTransactionCurrency,
          WHTAmountInTransacCrcy,
          NetAmountDocCurr,
          Status,

          @ObjectModel.filter.enabled: false
          ReportingDate,


          _BPTaxID.BPTaxNumber,

          _SupplierCompany.AccountingClerk,

//          @Consumption.filter: {
////            selectionType: #INTERVAL,
//            businessDate.at: true,
//            multipleSelections: false
//          }
//          @Semantics.dateTime: true
//          @Semantics.businessDate.at: true
          _JournalEntry.DocumentDate,
          _JournalEntry.AccountingDocumentType,
          _JournalEntry.DocumentReferenceID,
          @Consumption.filter.defaultValue: ''
          _JournalEntry.IsReversed,

          _OutgoingCheck.OutgoingCheque,

          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
          @EndUserText.label: 'Run Cheque Date'
  virtual RunChequeDate : abap.dats,

          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
          @EndUserText.label: 'Cheque Date'
  virtual ChequeDate    : abap.dats,

          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
          @EndUserText.label: 'Bank Number'
  virtual BankNumber    : abap.char(4),

          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
          @EndUserText.label: 'Updated By'
  virtual UpdatedBy     : syuname,

          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
  virtual UpdatedOn     : timestamp,

          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
          @EndUserText.label: 'Created By'
  virtual CreatedBy     : syuname,

          @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_DEMO_VE_FORM_01'
          @ObjectModel.filter.enabled: false
          @ObjectModel.sort.enabled: false
  virtual CreatedOn     : timestamp,

          /* Associations */
          _BPTaxID,
          _JournalEntry,
          _OutgoingCheck,
          _Supplier,
          _CompanyCode,
          _SupplierCompany
}
