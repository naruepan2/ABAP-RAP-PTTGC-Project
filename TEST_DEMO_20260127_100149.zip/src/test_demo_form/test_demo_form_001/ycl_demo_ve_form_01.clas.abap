CLASS ycl_demo_ve_form_01 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

**********************************************************************
* Public Section
**********************************************************************
  PUBLIC SECTION.
*---------------------------------------------------------------------
* Public Section - Interfaces
*---------------------------------------------------------------------
    INTERFACES:
      if_sadl_exit_calc_element_read.
*---------------------------------------------------------------------
* Public Section - Types
*---------------------------------------------------------------------
    TYPES:
      tt_entities TYPE STANDARD TABLE OF yc_demo_form01 WITH DEFAULT KEY.

**********************************************************************
* Private Section
**********************************************************************
  PRIVATE SECTION.
*---------------------------------------------------------------------
* Private Section - Types
*---------------------------------------------------------------------
    TYPES:
      BEGIN OF ty_bp_bank,
        businesspartner    TYPE i_businesspartnerbank-businesspartner,
        bankidentification TYPE i_businesspartnerbank-bankidentification,
        banknumber         TYPE i_businesspartnerbank-banknumber,
      END OF ty_bp_bank,
      tt_bp_bank TYPE SORTED TABLE OF ty_bp_bank WITH UNIQUE KEY businesspartner bankidentification.

*---------------------------------------------------------------------
* Private Section - Data
*---------------------------------------------------------------------
    DATA:
      BEGIN OF ms_buffer,
        bp_bank TYPE tt_bp_bank,
      END OF ms_buffer.

*---------------------------------------------------------------------
* Private Section - Methods
*---------------------------------------------------------------------
    METHODS:
      _prefetch_db
        IMPORTING
          it_original TYPE tt_entities,

      _get_bank_number
        IMPORTING
          iv_business_partner    TYPE md_supplier
          iv_bank_identification TYPE farp_bvtyp
        RETURNING
          VALUE(rv_bank)         TYPE yc_demo_form01-banknumber,
      _poc.

ENDCLASS.


CLASS ycl_demo_ve_form_01 IMPLEMENTATION.

  METHOD if_sadl_exit_calc_element_read~calculate.

    DATA:
      lt_original TYPE tt_entities,
      lt_result   TYPE tt_entities.

    _poc( ).

    FINAL(lo_chq_cal) = zcl_rtr_cheque_calculation=>get_instance( ).

    lt_result = CORRESPONDING #( it_original_data ).

    _prefetch_db( lt_result ).

    LOOP AT lt_result ASSIGNING FIELD-SYMBOL(<ls_original>).

      <ls_original>-createdby = 'SYSTEM'.
      <ls_original>-updatedby = 'RFC USER'.

      GET TIME STAMP FIELD <ls_original>-createdon.
      <ls_original>-updatedon = <ls_original>-createdon.

      TRY.
          lo_chq_cal->get_cheque_date(
              EXPORTING
                iv_reporting_date          = <ls_original>-reportingdate
                iv_company_code            = <ls_original>-companycode
                iv_payment_method          = <ls_original>-paymentmethod
                iv_payment_blocking_reason = <ls_original>-paymentblockingreason
                iv_clearing_date           = <ls_original>-clearingdate
                iv_net_due_date            = <ls_original>-netduedate
              IMPORTING
                ev_run_cheque_date         = <ls_original>-runchequedate
                ev_cheque_date             = <ls_original>-chequedate
            ).
        CATCH zcx_ext_virtual_element_error.
      ENDTRY.

      <ls_original>-banknumber = _get_bank_number(
        iv_business_partner     = <ls_original>-supplier
        iv_bank_identification  = <ls_original>-bpbankaccountinternalid
      ).

    ENDLOOP.

    ct_calculated_data = CORRESPONDING #( lt_result ).

  ENDMETHOD.


  METHOD if_sadl_exit_calc_element_read~get_calculation_info.
    CHECK iv_entity = 'YC_DEMO_FORM01'.

    LOOP AT it_requested_calc_elements ASSIGNING FIELD-SYMBOL(<lv_req_field>).
      CASE <lv_req_field>.
        WHEN 'BANKNUMBER'.
          INSERT |SUPPLIER| INTO TABLE et_requested_orig_elements.
          INSERT |BPBANKACCOUNTINTERNALID| INTO TABLE et_requested_orig_elements.

        WHEN 'RUNCHEQUEDATE'
          OR 'CHEQUEDATE'.
          INSERT |REPORTINGDATE| INTO TABLE et_requested_orig_elements.
          INSERT |COMPANYCODE| INTO TABLE et_requested_orig_elements.
          INSERT |PAYMENTMETHOD| INTO TABLE et_requested_orig_elements.
          INSERT |PAYMENTBLOCKINGREASON| INTO TABLE et_requested_orig_elements.
          INSERT |CLEARINGDATE| INTO TABLE et_requested_orig_elements.
          INSERT |NETDUEDATE| INTO TABLE et_requested_orig_elements.
      ENDCASE.
    ENDLOOP.

  ENDMETHOD.

  METHOD _prefetch_db.

    DATA(lt_bp_bank_keys) =
      CORRESPONDING tt_bp_bank( it_original DISCARDING DUPLICATES
        MAPPING businesspartner = supplier ).

    IF lt_bp_bank_keys IS NOT INITIAL.
      SELECT FROM i_businesspartnerbank AS a
        FIELDS
          a~businesspartner,
          a~bankidentification,
          a~banknumber
        FOR ALL ENTRIES IN @lt_bp_bank_keys
        WHERE a~businesspartner = @lt_bp_bank_keys-businesspartner
        INTO TABLE @ms_buffer-bp_bank.
    ENDIF.

  ENDMETHOD.


  METHOD _get_bank_number.
    TRY.
        IF iv_bank_identification IS INITIAL.
          DATA(ls_bp_bank) = ms_buffer-bp_bank[ businesspartner = iv_business_partner ].
        ELSE.
          ls_bp_bank = ms_buffer-bp_bank[ businesspartner     = iv_business_partner
                                          bankidentification  = iv_bank_identification ].
        ENDIF.

        RETURN ls_bp_bank-banknumber.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.
  ENDMETHOD.


  METHOD _poc.
    CHECK 1 = 2.

    CASE cl_abap_context_info=>get_user_technical_name( ).
      WHEN 'Z0012280'.
      WHEN OTHERS. RETURN.
    ENDCASE.

    WAIT UP TO 30 SECONDS.
  ENDMETHOD.

ENDCLASS.
