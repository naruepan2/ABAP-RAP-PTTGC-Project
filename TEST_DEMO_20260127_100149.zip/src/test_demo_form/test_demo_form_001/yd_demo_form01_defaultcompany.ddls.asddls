@EndUserText.label: 'Default Company'
define abstract entity YD_Demo_Form01_DefaultCompany
{
  CompanyCode : bukrs;

}
