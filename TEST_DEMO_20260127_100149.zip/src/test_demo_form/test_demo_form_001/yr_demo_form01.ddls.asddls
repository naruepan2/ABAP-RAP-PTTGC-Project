@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Form'
@Metadata.ignorePropagatedAnnotations: true
@Analytics.dataCategory: #CUBE
define root view entity YR_Demo_Form01
  as select from ZP_RTR_SupplierInvoice_3( P_ReportingDate: $session.system_date )

{
      //      @Consumption.filter.mandatory: true
      //      @Consumption.filter.selectionType: #SINGLE
  key CompanyCode,
  key AccountingDocument,
  key FiscalYear,

      ClearingDate,
      @Consumption.hidden: true
      ClearingJournalEntryFiscalYear,
      @Consumption.hidden: true
      ClearingJournalEntry,
      AssignmentReference,
      Supplier,
      PaymentMethod,
      PaymentBlockingReason,
      @Consumption.hidden: true
      BPBankAccountInternalID,
      NetDueDate,

      TransactionCurrency,
//      @DefaultAggregation: #SUM
      @Semantics.amount.currencyCode: 'TransactionCurrency'
      AmountInTransactionCurrency,
//      @DefaultAggregation: #SUM
      @Semantics.amount.currencyCode: 'TransactionCurrency'
      WHTAmountInTransacCrcy,
//      @DefaultAggregation: #SUM
      @Semantics.amount.currencyCode: 'TransactionCurrency'
      NetAmountDocCurr,
//      @Aggregation.default: #SUM
//      @Semantics.amount.currencyCode: 'TransactionCurrency'
//      AmountInTransactionCurrency,
//      @Aggregation.default: #SUM
//      @Semantics.amount.currencyCode: 'TransactionCurrency'
//      WHTAmountInTransacCrcy,
//      @Aggregation.default: #SUM
//      @Semantics.amount.currencyCode: 'TransactionCurrency'
//      NetAmountDocCurr,

      //      _BPTaxID.BPTaxNumber,
      //
      //      _SupplierCompany.AccountingClerk,
      //
      //      _JournalEntry.DocumentDate,
      //      _JournalEntry.AccountingDocumentType,
      //      _JournalEntry.DocumentReferenceID,
      //      _JournalEntry.IsReversed,

      //      @ObjectModel.virtualElementCalculatedBy: 'ABAP:ZCL_RTR_VE_SUPPLIERINVOICE'
      //      @ObjectModel.filter.enabled: false
      //      @ObjectModel.sort.enabled: false
      //      cast( '00000000' as abap.dats )                                    as RunChequeDate,
      //
      //      @ObjectModel.virtualElementCalculatedBy: 'ABAP:ZCL_RTR_VE_SUPPLIERINVOICE'
      //      @ObjectModel.filter.enabled: false
      //      @ObjectModel.sort.enabled: false
      //      cast( '00000000' as abap.dats )                                    as ChequeDate,
      //
      //      _OutgoingCheck.OutgoingCheque,
      //
      //      @ObjectModel.virtualElementCalculatedBy: 'ABAP:ZCL_RTR_VE_SUPPLIERINVOICE'
      //      @ObjectModel.filter.enabled: false
      //      @ObjectModel.sort.enabled: false
      //      @EndUserText.label: 'Bank Number'
      //      cast( '' as abap.char(4) )                                         as BankNumber,

      @ObjectModel.sort.enabled: false
      Status,

      @ObjectModel.filter.enabled: false
      @ObjectModel.sort.enabled: false
      ReportingDate,

      _BPTaxID,
      _SupplierCompany,
      _Supplier,
      _CompanyCode,
      _JournalEntry,
      _OutgoingCheck

}
