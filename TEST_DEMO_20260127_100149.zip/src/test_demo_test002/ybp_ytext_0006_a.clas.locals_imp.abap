CLASS lhc_yr_ytext_0006_a DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    CONSTANTS:
      BEGIN OF travel_status,
        open     TYPE c LENGTH 1 VALUE 'O', "Open
        accepted TYPE c LENGTH 1 VALUE 'A', "Accepted
        rejected TYPE c LENGTH 1 VALUE 'X', "Rejected
      END OF travel_status.


    METHODS:
      get_global_authorizations FOR GLOBAL AUTHORIZATION
        IMPORTING
        REQUEST requested_authorizations FOR yr_ytext_0006_a
        RESULT result,
      earlynumbering_create FOR NUMBERING
        IMPORTING entities FOR CREATE yr_ytext_0006_a,
      setstatustoopen FOR DETERMINE ON MODIFY
        IMPORTING keys FOR yr_ytext_0006_a~setstatustoopen,
      validatecustomer FOR VALIDATE ON SAVE
        IMPORTING keys FOR yr_ytext_0006_a~validatecustomer.

    METHODS validatedates FOR VALIDATE ON SAVE
      IMPORTING keys FOR yr_ytext_0006_a~validatedates.
    METHODS deductdiscount FOR MODIFY
      IMPORTING keys FOR ACTION yr_ytext_0006_a~deductdiscount RESULT result.
ENDCLASS.

CLASS lhc_yr_ytext_0006_a IMPLEMENTATION.
  METHOD get_global_authorizations.
  ENDMETHOD.
  METHOD earlynumbering_create.
    DATA:
      entity           TYPE STRUCTURE FOR CREATE yr_ytext_0006_a,
      travel_id_max    TYPE /dmo/travel_id,
      " change to abap_false if you get the ABAP Runtime error 'BEHAVIOR_ILLEGAL_STATEMENT'
      use_number_range TYPE abap_bool VALUE abap_false.

    "Ensure Travel ID is not set yet (idempotent)- must be checked when BO is draft-enabled
    LOOP AT entities INTO entity WHERE travelid IS NOT INITIAL.
      APPEND CORRESPONDING #( entity ) TO mapped-yr_ytext_0006_a.
    ENDLOOP.

    DATA(entities_wo_travelid) = entities.
    "Remove the entries with an existing Travel ID
    DELETE entities_wo_travelid WHERE travelid IS NOT INITIAL.

    IF use_number_range = abap_true.
      "Get numbers
      TRY.
          cl_numberrange_runtime=>number_get(
            EXPORTING
              nr_range_nr       = '01'
              object            = '/DMO/TRV_M'
              quantity          = CONV #( lines( entities_wo_travelid ) )
            IMPORTING
              number            = DATA(number_range_key)
              returncode        = DATA(number_range_return_code)
              returned_quantity = DATA(number_range_returned_quantity)
          ).
        CATCH cx_number_ranges INTO DATA(lx_number_ranges).
          LOOP AT entities_wo_travelid INTO entity.
            APPEND VALUE #(  %cid      = entity-%cid
                             %key      = entity-%key
                             %is_draft = entity-%is_draft
                             %msg      = lx_number_ranges
                          ) TO reported-yr_ytext_0006_a.
            APPEND VALUE #(  %cid      = entity-%cid
                             %key      = entity-%key
                             %is_draft = entity-%is_draft
                          ) TO failed-yr_ytext_0006_a.
          ENDLOOP.
          EXIT.
      ENDTRY.

      "determine the first free travel ID from the number range
      travel_id_max = number_range_key - number_range_returned_quantity.
    ELSE.
      "determine the first free travel ID without number range
      "Get max travel ID from active table
      SELECT SINGLE FROM ytext_0006_a FIELDS MAX( travel_id ) AS travelid INTO @travel_id_max.
      "Get max travel ID from draft table
      SELECT SINGLE FROM yytext_0006_a_d FIELDS MAX( travelid ) INTO @DATA(max_travelid_draft).
      IF max_travelid_draft > travel_id_max.
        travel_id_max = max_travelid_draft.
      ENDIF.
    ENDIF.


    "Set Travel ID for new instances w/o ID
    LOOP AT entities_wo_travelid INTO entity.
      travel_id_max += 1.
      entity-travelid = travel_id_max.

      APPEND VALUE #( %cid      = entity-%cid
                      %key      = entity-%key
                      %is_draft = entity-%is_draft
                    ) TO mapped-yr_ytext_0006_a.
    ENDLOOP.

  ENDMETHOD.

  METHOD setstatustoopen.
    "Read travel instances of the transferred keys
    READ ENTITIES OF yr_ytext_0006_a IN LOCAL MODE
     ENTITY yr_ytext_0006_a
       FIELDS ( overallstatus )
       WITH CORRESPONDING #( keys )
     RESULT DATA(travels)
     FAILED DATA(read_failed).

    "If overall travel status is already set, do nothing, i.e. remove such instances
    DELETE travels WHERE overallstatus IS NOT INITIAL.
    CHECK travels IS NOT INITIAL.

    "else set overall travel status to open ('O')
    MODIFY ENTITIES OF yr_ytext_0006_a IN LOCAL MODE
      ENTITY yr_ytext_0006_a
        UPDATE SET FIELDS
        WITH VALUE #( FOR travel IN travels ( %tky    = travel-%tky
                                              overallstatus = travel_status-open ) )
    REPORTED DATA(update_reported).

    "Set the changing parameter
    reported = CORRESPONDING #( DEEP update_reported ).
  ENDMETHOD.


**********************************************************************
* Validation: Check the validity of the entered customer data
**********************************************************************
  METHOD validatecustomer.
    "read relevant travel instance data
    READ ENTITIES OF yr_ytext_0006_a IN LOCAL MODE
    ENTITY yr_ytext_0006_a
     FIELDS ( customerid )
     WITH CORRESPONDING #( keys )
    RESULT DATA(travels).

    DATA customers TYPE SORTED TABLE OF /dmo/customer WITH UNIQUE KEY customer_id.

    "optimization of DB select: extract distinct non-initial customer IDs
    customers = CORRESPONDING #( travels DISCARDING DUPLICATES MAPPING customer_id = customerid EXCEPT * ).
    DELETE customers WHERE customer_id IS INITIAL.
    IF customers IS NOT INITIAL.

      "check if customer ID exists
      SELECT FROM /dmo/customer FIELDS customer_id
                                FOR ALL ENTRIES IN @customers
                                WHERE customer_id = @customers-customer_id
        INTO TABLE @DATA(valid_customers).
    ENDIF.

    "raise msg for non existing and initial customer id
    LOOP AT travels INTO DATA(travel).

      APPEND VALUE #(  %tky                 = travel-%tky
                       %state_area          = 'VALIDATE_CUSTOMER'
                     ) TO reported-yr_ytext_0006_a.

      IF travel-customerid IS  INITIAL.
        APPEND VALUE #( %tky = travel-%tky ) TO failed-yr_ytext_0006_a.

        APPEND VALUE #( %tky                = travel-%tky
                        %state_area         = 'VALIDATE_CUSTOMER'
                        %msg                = NEW /dmo/cm_flight_messages(
                                                                textid   = /dmo/cm_flight_messages=>enter_customer_id
                                                                severity = if_abap_behv_message=>severity-error )
                        %element-customerid = if_abap_behv=>mk-on
                      ) TO reported-yr_ytext_0006_a.

      ELSEIF travel-customerid IS NOT INITIAL AND NOT line_exists( valid_customers[ customer_id = travel-customerid ] ).
        APPEND VALUE #(  %tky = travel-%tky ) TO failed-yr_ytext_0006_a.

        APPEND VALUE #(  %tky                = travel-%tky
                         %state_area         = 'VALIDATE_CUSTOMER'
                         %msg                = NEW /dmo/cm_flight_messages(
                                                                customer_id = travel-customerid
                                                                textid      = /dmo/cm_flight_messages=>customer_unkown
                                                                severity    = if_abap_behv_message=>severity-error )
                         %element-customerid = if_abap_behv=>mk-on
                      ) TO reported-yr_ytext_0006_a.
      ENDIF.

    ENDLOOP.
  ENDMETHOD.


**********************************************************************
* Validation: Check the validity of begin and end dates
**********************************************************************
  METHOD validatedates.

    READ ENTITIES OF yr_ytext_0006_a IN LOCAL MODE
      ENTITY yr_ytext_0006_a
        FIELDS (  begindate enddate travelid )
        WITH CORRESPONDING #( keys )
      RESULT DATA(travels).

    LOOP AT travels INTO DATA(travel).

      APPEND VALUE #(  %tky               = travel-%tky
                       %state_area        = 'VALIDATE_DATES' ) TO reported-yr_ytext_0006_a.

      IF travel-begindate IS INITIAL.
        APPEND VALUE #( %tky = travel-%tky ) TO failed-yr_ytext_0006_a.

        APPEND VALUE #( %tky               = travel-%tky
                        %state_area        = 'VALIDATE_DATES'
                         %msg              = NEW /dmo/cm_flight_messages(
                                                                textid   = /dmo/cm_flight_messages=>enter_begin_date
                                                                severity = if_abap_behv_message=>severity-error )
                      %element-begindate = if_abap_behv=>mk-on ) TO reported-yr_ytext_0006_a.
      ENDIF.
      IF travel-begindate < cl_abap_context_info=>get_system_date( ) AND travel-begindate IS NOT INITIAL.
        APPEND VALUE #( %tky               = travel-%tky ) TO failed-yr_ytext_0006_a.

        APPEND VALUE #( %tky               = travel-%tky
                        %state_area        = 'VALIDATE_DATES'
                         %msg              = NEW /dmo/cm_flight_messages(
                                                                begin_date = travel-begindate
                                                                textid     = /dmo/cm_flight_messages=>begin_date_on_or_bef_sysdate
                                                                severity   = if_abap_behv_message=>severity-error )
                        %element-begindate = if_abap_behv=>mk-on ) TO reported-yr_ytext_0006_a.
      ENDIF.
      IF travel-enddate IS INITIAL.
        APPEND VALUE #( %tky = travel-%tky ) TO failed-yr_ytext_0006_a.

        APPEND VALUE #( %tky               = travel-%tky
                        %state_area        = 'VALIDATE_DATES'
                         %msg                = NEW /dmo/cm_flight_messages(
                                                                textid   = /dmo/cm_flight_messages=>enter_end_date
                                                               severity = if_abap_behv_message=>severity-error )
                        %element-enddate   = if_abap_behv=>mk-on ) TO reported-yr_ytext_0006_a.
      ENDIF.
      IF travel-enddate < travel-begindate AND travel-begindate IS NOT INITIAL
                                           AND travel-enddate IS NOT INITIAL.
        APPEND VALUE #( %tky = travel-%tky ) TO failed-yr_ytext_0006_a.

        APPEND VALUE #( %tky               = travel-%tky
                        %state_area        = 'VALIDATE_DATES'
                        %msg               = NEW /dmo/cm_flight_messages(
                                                                textid     = /dmo/cm_flight_messages=>begin_date_bef_end_date
                                                                begin_date = travel-begindate
                                                                end_date   = travel-enddate
                                                                severity   = if_abap_behv_message=>severity-error )
                        %element-begindate = if_abap_behv=>mk-on
                        %element-enddate   = if_abap_behv=>mk-on ) TO reported-yr_ytext_0006_a.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.



**************************************************************************
* Instance-bound non-factory action:
* Deduct the specified discount from the booking fee (BookingFee)
**************************************************************************
 METHOD deductdiscount.
    DATA travels_for_update TYPE TABLE FOR UPDATE yr_ytext_0006_a.
    DATA(keys_with_valid_discount) = keys.

    " read relevant travel instance data (only booking fee)
    READ ENTITIES OF yr_ytext_0006_a IN LOCAL MODE
        ENTITY yr_ytext_0006_a
        FIELDS ( bookingfee )
        WITH CORRESPONDING #( keys_with_valid_discount )
        RESULT DATA(travels).

    LOOP AT travels ASSIGNING FIELD-SYMBOL(<travel>).
      DATA(reduced_fee) = <travel>-bookingfee * ( 1 - 3 / 10 ) .

      APPEND VALUE #( %tky       = <travel>-%tky
                    bookingfee = reduced_fee
                  ) TO travels_for_update.
    ENDLOOP.

    " update data with reduced fee
    MODIFY ENTITIES OF yr_ytext_0006_a IN LOCAL MODE
        ENTITY yr_ytext_0006_a
        UPDATE FIELDS ( bookingfee )
        WITH travels_for_update.

    " read changed data for action result
    READ ENTITIES OF yr_ytext_0006_a IN LOCAL MODE
        ENTITY yr_ytext_0006_a
        ALL FIELDS WITH
        CORRESPONDING #( travels )
        RESULT DATA(travels_with_discount).

    " set action result
    result = VALUE #( FOR travel IN travels_with_discount ( %tky   = travel-%tky
                                                            %param = travel ) ).


 ENDMETHOD.


ENDCLASS.
