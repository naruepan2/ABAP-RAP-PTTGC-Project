@AccessControl.authorizationCheck: #CHECK
@Metadata.allowExtensions: true
//@EndUserText.label: 'Projection View for YR_YTEXT_0006_A'
@EndUserText.label: '##GENERATED Travel App (002)'
@Search.searchable: true
@ObjectModel.semanticKey: [ 'TravelID' ]
define root view entity YC_YTEXT_0006_A
  provider contract transactional_query
  as projection on YR_YTEXT_0006_A
{
@Search.defaultSearchElement: true
@Search.fuzzinessThreshold: 0.90    
  key TravelID,
@Search.defaultSearchElement: true
@ObjectModel.text.element: ['AgencyName']
@Consumption.valueHelpDefinition: [{ entity : {name: '/DMO/I_Agency', element: 'AgencyID' }, useForValidation: true }]
  AgencyID,
  _Agency.Name              as AgencyName,
@Search.defaultSearchElement: true
@ObjectModel.text.element: ['CustomerName']
@Consumption.valueHelpDefinition: [{ entity : {name: '/DMO/I_Customer', element: 'CustomerID'  }, useForValidation: true }]
  CustomerID,
  _Customer.LastName        as CustomerName,
  BeginDate,
  EndDate,
  BookingFee,
  TotalPrice,
@Consumption.valueHelpDefinition: [{ entity: {name: 'I_Currency', element: 'Currency' }, useForValidation: true }]
  CurrencyCode,
  Description,
@ObjectModel.text.element: ['OverallStatusText']
@Consumption.valueHelpDefinition: [{ entity : {name: '/DMO/I_Overall_Status_VH', element: 'OverallStatus' }, useForValidation: true }]
  OverallStatus,
  _OverallStatus._Text.Text as OverallStatusText : localized,   
  Attachment,
  MimeType,
  FileName,
  LocalLastChangedAt
  
}
