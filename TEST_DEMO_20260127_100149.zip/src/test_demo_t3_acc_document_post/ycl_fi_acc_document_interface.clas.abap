CLASS ycl_fi_acc_document_interface DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    TYPES:
      BEGIN OF ty_header,
        legacy_ref      TYPE bkpf-xref1_hd,
        legacy_ref_item TYPE bseg-buzei,
        comp_code       TYPE bapiache09-comp_code,
        pstng_date      TYPE bapiache09-pstng_date,
        doc_date        TYPE bapiache09-doc_date,
        currency        TYPE bapiaccr09-currency,
        doc_type        TYPE bapiache09-doc_type,
        ref_doc_no      TYPE bapiache09-ref_doc_no,
        header_txt      TYPE bapiache09-header_txt,
        businessplace   TYPE bapiacgl09-businessplace,
        exchange_rate   TYPE bapiaccr09-exch_rate,
      END OF ty_header.
    TYPES:
      BEGIN OF ty_item_apar,
        acc_type    TYPE bseg-koart,
        account_no  TYPE but000-partner,
        pmnt_block  TYPE bapiacap09-pmnt_block,
        newum       TYPE flag,
        amt_doccur  TYPE bapiaccr09-amt_doccur,
        tax_code    TYPE bapiacap09-tax_code,
        pmnttrms    TYPE bapiacap09-pmnttrms,
        bline_date  TYPE bapiacap09-bline_date,
        alloc_nmbr  TYPE bapiacap09-alloc_nmbr,
        item_text   TYPE bapiacap09-item_text,
        witht       TYPE bapiacwt09-wt_type,
        bas_amt_tc  TYPE bapiacwt09-bas_amt_tc,
        wt_code     TYPE bapiacwt09-wt_code,
        wt_qbshb    TYPE bapiacwt09-man_amt_tc,
        witht2      TYPE bapiacwt09-wt_type,
        bas_amt_tc2 TYPE bapiacwt09-bas_amt_tc,
        wt_code2    TYPE bapiacwt09-wt_code,
        wt_qbshb2   TYPE bapiacwt09-man_amt_tc,
        ref_key_1   TYPE bapiacar09-ref_key_1,
        ref_key_2   TYPE bapiacar09-ref_key_2,
        ref_key_3   TYPE bapiacar09-ref_key_3,
        sp_gl_ind   TYPE bapiacar09-sp_gl_ind,
        name        TYPE adrc-name1,
        name_2      TYPE adrc-name2,
        name_3      TYPE adrc-name3,
        name_4      TYPE adrc-name4,
        city        TYPE adrc-city1,
        country     TYPE adrc-country,
        country_iso TYPE bapiacpa09-country_iso,
        street      TYPE adrc-street,
        post_code   TYPE adrc-post_code1,
        bank_ctry   TYPE bapiacpa09-bank_ctry,
        bank_no     TYPE bapiacpa09-bank_no,
        bank_acct   TYPE bapiacpa09-bank_acct,
        tax_no_1    TYPE bapiacpa09-tax_no_1,
        tax_no_2    TYPE bapiacpa09-tax_no_2,
        tax_no_3    TYPE bapiacpa09-tax_no_3,
        part_bupla  TYPE bapiacap09-part_businessplace,
        pymt_meth   TYPE bapiacar09-pymt_meth,
        note_item   TYPE bapiacar09-res_item,
        bvtyp       TYPE bapiacar09-partner_bk,
      END OF ty_item_apar.
    TYPES tt_item_apar TYPE TABLE OF ty_item_apar WITH EMPTY KEY.
    TYPES:
      BEGIN OF ty_item_gl,
        gl_account TYPE bapiacgl09-gl_account,
        amt_doccur TYPE bapiacwt09-bas_amt_tc,
        tax_code   TYPE bapiacgl09-tax_code,
        amt_base   TYPE bapiacwt09-man_amt_tc,
        alloc_nmbr TYPE bapiacgl09-alloc_nmbr,
        item_text  TYPE bapiacgl09-item_text,
        costcenter TYPE bapiacgl09-costcenter,
        profit_ctr TYPE bapiacgl09-profit_ctr,
        orderid    TYPE bapiacgl09-orderid,
        ref_key_1  TYPE bapiacgl09-ref_key_1,
        ref_key_2  TYPE bapiacgl09-ref_key_2,
        ref_key_3  TYPE bapiacgl09-ref_key_3,
        trade_id   TYPE bapiacgl09-trade_id,
      END OF ty_item_gl.
    TYPES tt_item_gl TYPE TABLE OF ty_item_gl WITH EMPTY KEY.
    TYPES:
      BEGIN OF ty_req_document.
        INCLUDE TYPE ty_header.
    TYPES:
        t_item_apar TYPE tt_item_apar,
        t_item_gl   TYPE tt_item_gl,
      END OF ty_req_document.
    TYPES tt_req_document TYPE TABLE OF ty_req_document WITH EMPTY KEY.
    TYPES:
      BEGIN OF ty_request,
        t_doc TYPE tt_req_document,
      END OF ty_request.
    TYPES tt_request TYPE TABLE OF ty_request WITH EMPTY KEY.
    TYPES:
      BEGIN OF ty_respond_message,
        sap_fi_document      TYPE bkpf-belnr,
        sap_fi_document_year TYPE bkpf-gjahr,
        return_message       TYPE bapiret2-message,
        id                   TYPE bapiret2-id,
        number               TYPE bapiret2-number,
        row                  TYPE bapiret2-row,
      END OF ty_respond_message.
    TYPES tt_respond_message TYPE TABLE OF ty_respond_message WITH EMPTY KEY.
    TYPES:
      BEGIN OF ty_res_document,
        legacy_ref      TYPE bkpf-xref1_hd,
        legacy_ref_item TYPE bseg-buzei,
        return_code     TYPE bapiret2-type,
* sap_fi_document TYPE bkpf-belnr,
* sap_fi_document_year TYPE bkpf-gjahr,
        t_message       TYPE tt_respond_message,
      END OF ty_res_document.
    TYPES tt_res_document TYPE TABLE OF ty_res_document WITH EMPTY KEY.
    TYPES:
      BEGIN OF ty_respond,
        t_result TYPE tt_res_document,
      END OF ty_respond.
    TYPES tt_respond TYPE TABLE OF ty_respond WITH EMPTY KEY.

    CONSTANTS gc_error    TYPE char1          VALUE 'E' ##NO_TEXT.
    CONSTANTS gc_success  TYPE char1          VALUE 'S' ##NO_TEXT.
    CONSTANTS gc_customer TYPE bseg-koart     VALUE 'D' ##NO_TEXT.
    CONSTANTS gc_thb      TYPE waers          VALUE 'THB' ##NO_TEXT.
    CONSTANTS gc_vendor   TYPE bseg-koart     VALUE 'K' ##NO_TEXT.
    CONSTANTS gc_alpha    TYPE dfies-convexit VALUE 'ALPHA' ##NO_TEXT.

    CLASS-METHODS class_constructor.

    METHODS create_instance
      RETURNING VALUE(ro_instance) TYPE REF TO ycl_fi_acc_document_interface.

    METHODS post_invoice_interface
      IMPORTING io_request         TYPE REF TO if_http_request
      RETURNING VALUE(rv_out_json) TYPE string.

    METHODS acc_document_check
      IMPORTING iw_documentheader    TYPE bapiache09
                iw_customercpd       TYPE bapiacpa09     OPTIONAL
                iw_contractheader    TYPE bapiaccahd     OPTIONAL
      EXPORTING et_return            TYPE bapiret2_tab
      CHANGING  ct_accountgl         TYPE bapiacgl09_tab OPTIONAL
                ct_accountreceivable TYPE bapiacar09_tab OPTIONAL
                ct_accountpayable    TYPE bapiacap09_tab OPTIONAL
                ct_accounttax        TYPE bapiactx09_tab OPTIONAL
                ct_currencyamount    TYPE bapiaccr09_tab OPTIONAL
                ct_criteria          TYPE bapiackec9_tab OPTIONAL
                ct_valuefield        TYPE bapiackev9_tab OPTIONAL
                ct_extension1        TYPE bapiacextc_tab OPTIONAL
                ct_paymentcard       TYPE bapiacpc09_tab OPTIONAL
                ct_contractitem      TYPE bapiaccait_tab OPTIONAL
                ct_extension2        TYPE bapiparex_tab  OPTIONAL
                ct_realestate        TYPE bapiacre09_tab OPTIONAL
                ct_accountwt         TYPE bapiacwt09_tab OPTIONAL.

    METHODS acc_document_post
      IMPORTING iw_documentheader    TYPE bapiache09
                iw_customercpd       TYPE bapiacpa09     OPTIONAL
                iw_contractheader    TYPE bapiaccahd     OPTIONAL
                iv_testrun           TYPE xfeld          DEFAULT abap_true
                iv_postdocument      TYPE xfeld          DEFAULT abap_true
                iv_commit_work       TYPE xfeld          DEFAULT abap_true
      EXPORTING ev_obj_type          TYPE bapiache09-obj_type
                ev_obj_key           TYPE bapiache09-obj_key
                ev_obj_sys           TYPE bapiache09-obj_sys
                ev_bukrs             TYPE bkpf-bukrs
                ev_belnr             TYPE bkpf-belnr
                ev_gjahr             TYPE bkpf-gjahr
                et_return            TYPE bapiret2_tab
                ev_error             TYPE xfeld
      CHANGING  ct_accountgl         TYPE bapiacgl09_tab OPTIONAL
                ct_accountreceivable TYPE bapiacar09_tab OPTIONAL
                ct_accountpayable    TYPE bapiacap09_tab OPTIONAL
                ct_accounttax        TYPE bapiactx09_tab OPTIONAL
                ct_currencyamount    TYPE bapiaccr09_tab OPTIONAL
                ct_criteria          TYPE bapiackec9_tab OPTIONAL
                ct_valuefield        TYPE bapiackev9_tab OPTIONAL
                ct_extension1        TYPE bapiacextc_tab OPTIONAL
                ct_paymentcard       TYPE bapiacpc09_tab OPTIONAL
                ct_contractitem      TYPE bapiaccait_tab OPTIONAL
                ct_extension2        TYPE bapiparex_tab  OPTIONAL
                ct_realestate        TYPE bapiacre09_tab OPTIONAL
                ct_accountwt         TYPE bapiacwt09_tab OPTIONAL.

    METHODS prepare_document_from_json
      IMPORTING iw_document          TYPE ty_req_document
      EXPORTING ew_documentheader    TYPE bapiache09
                ew_customercpd       TYPE bapiacpa09
                ew_contractheader    TYPE bapiaccahd
                et_accountgl         TYPE bapiacgl09_tab
                et_accountreceivable TYPE bapiacar09_tab
                et_accountpayable    TYPE bapiacap09_tab
                et_accounttax        TYPE bapiactx09_tab
                et_currencyamount    TYPE bapiaccr09_tab
                et_criteria          TYPE bapiackec9_tab
                et_valuefield        TYPE bapiackev9_tab
                et_extension1        TYPE bapiacextc_tab
                et_paymentcard       TYPE bapiacpc09_tab
                et_contractitem      TYPE bapiaccait_tab
                et_extension2        TYPE bapiparex_tab
                et_realestate        TYPE bapiacre09_tab
                et_accountwt         TYPE bapiacwt09_tab.

    METHODS post_document_from_json
      IMPORTING iw_documentheader    TYPE bapiache09
                iw_customercpd       TYPE bapiacpa09     OPTIONAL
                iw_contractheader    TYPE bapiaccahd     OPTIONAL
                iv_testrun           TYPE xfeld          DEFAULT abap_true
                iv_postdocument      TYPE xfeld          DEFAULT abap_true
                iv_commit_work       TYPE xfeld          DEFAULT abap_true
      EXPORTING ev_obj_type          TYPE bapiache09-obj_type
                ev_obj_key           TYPE bapiache09-obj_key
                ev_obj_sys           TYPE bapiache09-obj_sys
                ev_bukrs             TYPE bkpf-bukrs
                ev_belnr             TYPE bkpf-belnr
                ev_gjahr             TYPE bkpf-gjahr
                et_return            TYPE bapiret2_tab
                ev_error             TYPE xfeld
      CHANGING  ct_accountgl         TYPE bapiacgl09_tab OPTIONAL
                ct_accountreceivable TYPE bapiacar09_tab OPTIONAL
                ct_accountpayable    TYPE bapiacap09_tab OPTIONAL
                ct_accounttax        TYPE bapiactx09_tab OPTIONAL
                ct_currencyamount    TYPE bapiaccr09_tab OPTIONAL
                ct_criteria          TYPE bapiackec9_tab OPTIONAL
                ct_valuefield        TYPE bapiackev9_tab OPTIONAL
                ct_extension1        TYPE bapiacextc_tab OPTIONAL
                ct_paymentcard       TYPE bapiacpc09_tab OPTIONAL
                ct_contractitem      TYPE bapiaccait_tab OPTIONAL
                ct_extension2        TYPE bapiparex_tab  OPTIONAL
                ct_realestate        TYPE bapiacre09_tab OPTIONAL
                ct_accountwt         TYPE bapiacwt09_tab OPTIONAL.

    METHODS update_legacy_ref_from_json
      IMPORTING iv_bukrs    TYPE bkpf-bukrs
                iv_belnr    TYPE bkpf-belnr
                iv_gjahr    TYPE bkpf-gjahr
                iv_xref1_hd TYPE bkpf-xref1_hd
      EXPORTING et_return   TYPE bapiret2_tab
                ev_error    TYPE xfeld.

    METHODS post_document
      IMPORTING iw_document TYPE ty_req_document OPTIONAL
                iv_check    TYPE boolean         OPTIONAL
      EXPORTING ev_eflag    TYPE boolean
      CHANGING  cw_result   TYPE ty_respond.

    " -------------------------------------------------------------------------
    " Protected section of class. -
    " -------------------------------------------------------------------------

  PROTECTED SECTION.
    " -------------------------------------------------------------------------
    " Private section of class. -
    " -------------------------------------------------------------------------

  PRIVATE SECTION.
    CLASS-DATA mo_instance TYPE REF TO ycl_fi_acc_document_interface.

    DATA mv_itemno_acc TYPE posnr_acc.
    DATA mt_t030k      TYPE fac_acc_det_t_t030k.

    METHODS _fill_documentheader
      IMPORTING iw_document       TYPE ty_req_document OPTIONAL
                iw_documentheader TYPE bapiache09      OPTIONAL
      CHANGING  cw_documentheader TYPE bapiache09
                ct_extension2     TYPE bapiparex_tab   OPTIONAL.

    METHODS _fill_accountpayable
      IMPORTING iw_document       TYPE ty_req_document OPTIONAL
                iw_item_apar      TYPE ty_item_apar    OPTIONAL
                iw_accountpayable TYPE bapiacap09      OPTIONAL
                iw_currencyamount TYPE bapiaccr09      OPTIONAL
      CHANGING  cw_customercpd    TYPE bapiacpa09      OPTIONAL
                ct_accountpayable TYPE bapiacap09_tab
                ct_accounttax     TYPE bapiactx09_tab  OPTIONAL
                ct_currencyamount TYPE bapiaccr09_tab
                ct_criteria       TYPE bapiackec9_tab  OPTIONAL
                ct_valuefield     TYPE bapiackev9_tab  OPTIONAL
                ct_extension1     TYPE bapiacextc_tab  OPTIONAL
                ct_paymentcard    TYPE bapiacpc09_tab  OPTIONAL
                ct_contractitem   TYPE bapiaccait_tab  OPTIONAL
                ct_extension2     TYPE bapiparex_tab   OPTIONAL
                ct_realestate     TYPE bapiacre09_tab  OPTIONAL
                ct_accountwt      TYPE bapiacwt09_tab  OPTIONAL.

    METHODS _fill_accountreceivable
      IMPORTING iw_document          TYPE ty_req_document OPTIONAL
                iw_item_apar         TYPE ty_item_apar    OPTIONAL
                iw_accountreceivable TYPE bapiacar09      OPTIONAL
                iw_currencyamount    TYPE bapiaccr09      OPTIONAL
      CHANGING  cw_customercpd       TYPE bapiacpa09      OPTIONAL
                ct_accountreceivable TYPE bapiacar09_tab
                ct_accounttax        TYPE bapiactx09_tab  OPTIONAL
                ct_currencyamount    TYPE bapiaccr09_tab
                ct_criteria          TYPE bapiackec9_tab  OPTIONAL
                ct_valuefield        TYPE bapiackev9_tab  OPTIONAL
                ct_extension1        TYPE bapiacextc_tab  OPTIONAL
                ct_paymentcard       TYPE bapiacpc09_tab  OPTIONAL
                ct_contractitem      TYPE bapiaccait_tab  OPTIONAL
                ct_extension2        TYPE bapiparex_tab   OPTIONAL
                ct_realestate        TYPE bapiacre09_tab  OPTIONAL
                ct_accountwt         TYPE bapiacwt09_tab  OPTIONAL.

    METHODS _fill_accountgl
      IMPORTING iw_document       TYPE ty_req_document OPTIONAL
                iw_item_gl        TYPE ty_item_gl      OPTIONAL
                iw_accountgl      TYPE bapiacgl09      OPTIONAL
                iw_currencyamount TYPE bapiaccr09      OPTIONAL
      CHANGING  ct_accountgl      TYPE bapiacgl09_tab
                ct_accounttax     TYPE bapiactx09_tab  OPTIONAL
                ct_currencyamount TYPE bapiaccr09_tab
                ct_criteria       TYPE bapiackec9_tab  OPTIONAL
                ct_valuefield     TYPE bapiackev9_tab  OPTIONAL
                ct_extension1     TYPE bapiacextc_tab  OPTIONAL
                ct_paymentcard    TYPE bapiacpc09_tab  OPTIONAL
                ct_contractitem   TYPE bapiaccait_tab  OPTIONAL
                ct_extension2     TYPE bapiparex_tab   OPTIONAL
                ct_realestate     TYPE bapiacre09_tab  OPTIONAL.

    METHODS _fill_vendor_customer_onetime
      IMPORTING iw_document    TYPE ty_req_document OPTIONAL
                iw_item_apar   TYPE ty_item_apar    OPTIONAL
      CHANGING  cw_customercpd TYPE bapiacpa09.

    METHODS _fill_accountwt
      IMPORTING iw_accountwt TYPE bapiacwt09 OPTIONAL
      CHANGING  ct_accountwt TYPE bapiacwt09_tab.

    METHODS _fill_accounttax
      IMPORTING iw_document       TYPE ty_req_document OPTIONAL
                iw_item_apar      TYPE ty_item_apar    OPTIONAL
                iw_item_gl        TYPE ty_item_gl      OPTIONAL
      CHANGING  ct_accounttax     TYPE bapiactx09_tab
                ct_currencyamount TYPE bapiaccr09_tab.

    METHODS _fill_currencyamount
      IMPORTING iw_document       TYPE ty_req_document OPTIONAL
                iw_item_apar      TYPE ty_item_apar    OPTIONAL
                iw_item_gl        TYPE ty_item_gl      OPTIONAL
                iw_currencyamount TYPE bapiaccr09      OPTIONAL
      CHANGING  ct_currencyamount TYPE bapiaccr09_tab.

    METHODS _replace_unwanted_characters
      CHANGING cv_cdata TYPE any.

    METHODS _convert_structure_conversion
      CHANGING cw_data TYPE any.

    METHODS _convert_dynamic_conv_value
      IMPORTING iv_input  TYPE any
      EXPORTING ev_output TYPE any.

    METHODS _check_tax_determination
      IMPORTING iw_document            TYPE ty_req_document       OPTIONAL
                iw_item_gl             TYPE ty_item_gl            OPTIONAL
                iv_comp_code           TYPE bapiacgl09-comp_code  OPTIONAL
                iv_gl_account          TYPE bapiacgl09-gl_account OPTIONAL
                iv_tax_code            TYPE bapiacgl09-tax_code   OPTIONAL
      RETURNING VALUE(rv_is_tax_deter) TYPE flag.

    METHODS _convert_to_local_amount
      IMPORTING iv_company_code     TYPE t001-bukrs
                iv_foreign_currency TYPE t001-waers
                iv_foreign_amount   TYPE any
      CHANGING  cv_local_amount     TYPE any.

ENDCLASS.



CLASS ycl_fi_acc_document_interface IMPLEMENTATION.


  METHOD acc_document_check.
    CLEAR et_return.

    CALL FUNCTION 'BAPI_ACC_DOCUMENT_CHECK'
      EXPORTING
        documentheader    = iw_documentheader
        customercpd       = iw_customercpd
        contractheader    = iw_contractheader
      TABLES
        accountgl         = ct_accountgl
        accountreceivable = ct_accountreceivable
        accountpayable    = ct_accountpayable
        accounttax        = ct_accounttax
        currencyamount    = ct_currencyamount
        criteria          = ct_criteria
        valuefield        = ct_valuefield
        extension1        = ct_extension1
        return            = et_return
        paymentcard       = ct_paymentcard
        contractitem      = ct_contractitem
        extension2        = ct_extension2
        realestate        = ct_realestate
        accountwt         = ct_accountwt.
  ENDMETHOD.


  METHOD acc_document_post.
    DATA lt_return TYPE bapiret2_tab.

    CLEAR: et_return,
           ev_error.
    CLEAR: ev_obj_type,
           ev_obj_key,
           ev_obj_sys,
           ev_bukrs,
           ev_belnr,
           ev_gjahr.

    IF iv_testrun IS NOT INITIAL.
      acc_document_check( EXPORTING iw_documentheader    = iw_documentheader
                                    iw_customercpd       = iw_customercpd
                                    iw_contractheader    = iw_contractheader
                          IMPORTING et_return            = lt_return
                          CHANGING  ct_accountgl         = ct_accountgl
                                    ct_accountreceivable = ct_accountreceivable
                                    ct_accountpayable    = ct_accountpayable
                                    ct_accounttax        = ct_accounttax
                                    ct_currencyamount    = ct_currencyamount
                                    ct_criteria          = ct_criteria
                                    ct_valuefield        = ct_valuefield
                                    ct_extension1        = ct_extension1
                                    ct_paymentcard       = ct_paymentcard
                                    ct_contractitem      = ct_contractitem
                                    ct_extension2        = ct_extension2
                                    ct_realestate        = ct_realestate
                                    ct_accountwt         = ct_accountwt ).

      LOOP AT lt_return TRANSPORTING NO FIELDS WHERE type CA 'EAX'.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0.
        ev_error = abap_true.
      ENDIF.

      et_return = lt_return.
    ENDIF.

    IF ev_error IS NOT INITIAL.
      RETURN.
    ENDIF.

    CLEAR lt_return.

    IF iv_postdocument IS INITIAL.
      RETURN.
    ENDIF.

    CALL FUNCTION 'BAPI_ACC_DOCUMENT_POST'
      EXPORTING
        documentheader    = iw_documentheader
        customercpd       = iw_customercpd
        contractheader    = iw_contractheader
      IMPORTING
        obj_type          = ev_obj_type
        obj_key           = ev_obj_key
        obj_sys           = ev_obj_sys
      TABLES
        accountgl         = ct_accountgl
        accountreceivable = ct_accountreceivable
        accountpayable    = ct_accountpayable
        accounttax        = ct_accounttax
        currencyamount    = ct_currencyamount
        criteria          = ct_criteria
        valuefield        = ct_valuefield
        extension1        = ct_extension1
        return            = lt_return
        paymentcard       = ct_paymentcard
        contractitem      = ct_contractitem
        extension2        = ct_extension2
        realestate        = ct_realestate
        accountwt         = ct_accountwt.

    LOOP AT lt_return TRANSPORTING NO FIELDS WHERE type CA 'EAX'.
      EXIT.
    ENDLOOP.
    IF sy-subrc = 0.
      ev_error = abap_true.
    ENDIF.

    IF iv_commit_work IS NOT INITIAL.
      IF ev_error IS INITIAL.
        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
          EXPORTING
            wait = abap_true.
      ELSE.
        CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.
      ENDIF.
    ENDIF.

    et_return = lt_return.
    ev_belnr  = ev_obj_key+0(10).
    ev_bukrs  = ev_obj_key+10(4).
    ev_gjahr  = ev_obj_key+14(4).
  ENDMETHOD.


  METHOD _check_tax_determination.
    DATA lw_t001       TYPE t001.
    DATA lv_konts      TYPE t030k-konts.
    DATA lv_comp_code  TYPE bapiacgl09-comp_code.
    DATA lv_gl_account TYPE bapiacgl09-gl_account.
    DATA lv_tax_code   TYPE bapiacgl09-tax_code.

    IF iw_item_gl IS SUPPLIED.
      lv_gl_account = iw_item_gl-gl_account.
      lv_tax_code   = iw_item_gl-tax_code.
      lv_comp_code  = iw_document-comp_code.
    ELSE.
      lv_gl_account = iv_gl_account.
      lv_tax_code   = iv_tax_code.
      lv_comp_code  = iv_comp_code.
    ENDIF.

    _convert_dynamic_conv_value( EXPORTING iv_input  = lv_gl_account
                                 IMPORTING ev_output = lv_konts ).

    " Determine the country of the company code
    CALL FUNCTION 'FI_COMPANY_CODE_DATA'
      EXPORTING
        i_bukrs      = lv_comp_code
      IMPORTING
        e_t001       = lw_t001
      EXCEPTIONS
        system_error = 1.
    IF sy-subrc <> 0.
      lw_t001-waers = gc_thb.
    ENDIF.

    LOOP AT mt_t030k TRANSPORTING NO FIELDS WHERE     ktopl = lw_t001-ktopl
                                                  AND mwskz = lv_tax_code
                                                  AND (    konts = lv_konts
                                                        OR konth = lv_konts ).
      EXIT.
    ENDLOOP.
    IF sy-subrc = 0.
      rv_is_tax_deter = abap_true.
    ELSE.
      SELECT SINGLE FROM t030k
        FIELDS *
        WHERE ktopl = @lw_t001-ktopl
          AND mwskz = @lv_tax_code
          AND (    konts = @lv_konts
                OR konth = @lv_konts )
        INTO @DATA(lw_t030k).
      IF sy-subrc = 0.
        rv_is_tax_deter = abap_true.

        APPEND lw_t030k TO mt_t030k.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD class_constructor.
    mo_instance = NEW #( ).
  ENDMETHOD.


  METHOD _convert_dynamic_conv_value.
    DATA lo_elem      TYPE REF TO cl_abap_elemdescr.
    DATA lw_fieldinfo TYPE rsanu_s_fieldinfo.

    " Set initial output value to input value. This allows to exit in failure conditions.
    ev_output = iv_input.

    lo_elem ?= cl_abap_elemdescr=>describe_by_data( iv_input ).

    " If the data has no DDIC structure, exit
    IF lo_elem->is_ddic_type( ) <> abap_true.
      RETURN.
    ENDIF.

    DATA(lw_dfies) = lo_elem->get_ddic_field( sy-langu ).

    " If DDIC structure has no conversion exit, exit.
    IF lw_dfies-convexit IS INITIAL.
      RETURN.
    ENDIF.

    " If alpha just convert right away and return
    IF lw_dfies-convexit = gc_alpha.
      ev_output = |{ iv_input ALPHA = IN }|.
      RETURN.
    ENDIF.

    MOVE-CORRESPONDING lw_dfies TO lw_fieldinfo.

    TRY.
        cl_rsan_ut_conversion_exit=>try_conv_int_ext_int( EXPORTING i_fieldinfo              = lw_fieldinfo
                                                                    i_value                  = iv_input
                                                                    i_conversion_errors_type = '*'
                                                          IMPORTING e_value                  = ev_output ).
      CATCH cx_root INTO DATA(lv_exc). " TODO: variable is assigned but never used (ABAP cleaner)
        CLEAR ev_output.
        RETURN.
    ENDTRY.
  ENDMETHOD.


  METHOD _convert_structure_conversion.
    IF cw_data IS INITIAL.
      RETURN.
    ENDIF.

    DO.
      ASSIGN COMPONENT sy-index OF STRUCTURE cw_data TO FIELD-SYMBOL(<lf_val>).
      IF sy-subrc = 0.
        IF <lf_val> IS NOT INITIAL.
          _convert_dynamic_conv_value( EXPORTING iv_input  = <lf_val>
                                       IMPORTING ev_output = <lf_val> ).
        ENDIF.
      ELSE.
        EXIT.
      ENDIF.
    ENDDO.
  ENDMETHOD.


  METHOD _convert_to_local_amount.
    DATA lw_t001 TYPE t001.

    " Determine the country of the company code
    CALL FUNCTION 'FI_COMPANY_CODE_DATA'
      EXPORTING
        i_bukrs      = iv_company_code
      IMPORTING
        e_t001       = lw_t001
      EXCEPTIONS
        system_error = 1.
    IF sy-subrc <> 0.
      lw_t001-waers = gc_thb.
    ENDIF.

    IF iv_foreign_currency = lw_t001-waers.
      cv_local_amount = iv_foreign_amount.
    ELSE.
      CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
        EXPORTING
*         CLIENT           = SY-MANDT
          date             = sy-datum
          foreign_amount   = iv_foreign_amount
          foreign_currency = iv_foreign_currency
          local_currency   = lw_t001-waers
        IMPORTING
          local_amount     = cv_local_amount
        EXCEPTIONS
          no_rate_found    = 1
          overflow         = 2
          no_factors_found = 3
          no_spread_found  = 4
          derived_2_times  = 5
          OTHERS           = 6.
      IF sy-subrc <> 0.
        cv_local_amount = iv_foreign_amount.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD create_instance.
    ro_instance = COND #( WHEN mo_instance IS NOT BOUND THEN NEW #( ) ELSE mo_instance ).
  ENDMETHOD.


  METHOD _fill_accountgl.
    " TODO: parameter CT_ACCOUNTTAX is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_CRITERIA is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_VALUEFIELD is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_EXTENSION1 is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_PAYMENTCARD is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_CONTRACTITEM is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_EXTENSION2 is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_REALESTATE is never used or assigned (ABAP cleaner)

    DATA lw_accountgl TYPE bapiacgl09.

    IF iw_item_gl IS SUPPLIED.
      mv_itemno_acc = mv_itemno_acc + 1.

      lw_accountgl-itemno_acc    = mv_itemno_acc.                           " Accounting Document Line Item Number
      lw_accountgl-gl_account    = iw_item_gl-gl_account.                      " General Ledger Account
      lw_accountgl-item_text     = iw_item_gl-item_text.                       " Item Text
      " LW_ACCOUNTGL-STAT_CON         =                                             " Indicator for statistical line items
      " LW_ACCOUNTGL-LOG_PROC         =                                             " Logical Transaction
      " LW_ACCOUNTGL-AC_DOC_NO        =                                             " Accounting Document Number
      lw_accountgl-ref_key_1     = iw_item_gl-ref_key_1.                       " Business Partner Reference Key
      lw_accountgl-ref_key_2     = iw_item_gl-ref_key_2.                       " Business Partner Reference Key
      lw_accountgl-ref_key_3     = iw_item_gl-ref_key_3.                       " Reference Key for Line Item
      " LW_ACCOUNTGL-ACCT_KEY         =                                             " Transaction Key
      " LW_ACCOUNTGL-ACCT_TYPE        =                                             " Account Type
      lw_accountgl-doc_type      = iw_document-doc_type.                       " Document Type
      lw_accountgl-comp_code     = iw_document-comp_code.                      " Company Code
      " LW_ACCOUNTGL-BUS_AREA         =                                             " Business Area
      " LW_ACCOUNTGL-FUNC_AREA        =                                             " Functional Area
      " LW_ACCOUNTGL-PLANT            =                                             " Plant
      " LW_ACCOUNTGL-FIS_PERIOD       =                                             " Fiscal Period
      " LW_ACCOUNTGL-FISC_YEAR        =                                             " Fiscal Year
      lw_accountgl-pstng_date    = iw_document-pstng_date.                     " Posting Date in the Document
      " LW_ACCOUNTGL-value_date       =                                             " Value Date
      " LW_ACCOUNTGL-FM_AREA          =                                             " Financial Management Area
      " LW_ACCOUNTGL-CUSTOMER         =                                             " Customer Number
      " LW_ACCOUNTGL-CSHDIS_IND       =                                             " Indicator: Line Item Not Liable to Cash Discount?
      " LW_ACCOUNTGL-VENDOR_NO        =                                             " Account Number of Vendor or Creditor
      lw_accountgl-alloc_nmbr    = iw_item_gl-alloc_nmbr.                      " Assignment Number
      lw_accountgl-tax_code      = iw_item_gl-tax_code.                        " Tax on sales/purchases code
      " LW_ACCOUNTGL-TAXJURCODE       =                                             " Tax Jurisdiction
      " LW_ACCOUNTGL-EXT_OBJECT_ID    =                                             " Technical Key of External Object
      " LW_ACCOUNTGL-BUS_SCENARIO     =                                             " Business Scenario in Controlling for Logistical Objects
      " LW_ACCOUNTGL-COSTOBJECT       =                                             " Cost Object
      lw_accountgl-costcenter    = iw_item_gl-costcenter.                      " Cost Center
      " LW_ACCOUNTGL-ACTTYPE          =                                             " Activity Type
      lw_accountgl-profit_ctr    = iw_item_gl-profit_ctr.                      " Profit Center
      " LW_ACCOUNTGL-PART_PRCTR       =                                             " Partner Profit Center
      " LW_ACCOUNTGL-NETWORK          =                                             " Network Number for Account Assignment
      " LW_ACCOUNTGL-wbs_element      =                                             " Work Breakdown Structure Element (WBS Element)
      lw_accountgl-orderid       = iw_item_gl-orderid.                         " Order Number
      " LW_ACCOUNTGL-ORDER_ITNO       =                                             " Order Item Number
      " LW_ACCOUNTGL-ROUTING_NO       =                                             " Routing number of operations in the order
      " LW_ACCOUNTGL-ACTIVITY         =                                             " Operation/Activity Number
      " LW_ACCOUNTGL-COND_TYPE        =                                             " Condition type
      " LW_ACCOUNTGL-COND_COUNT       =                                             " Condition Counter
      " LW_ACCOUNTGL-COND_ST_NO       =                                             " Level Number
      " LW_ACCOUNTGL-FUND             =                                             " Fund
      " LW_ACCOUNTGL-FUNDS_CTR        =                                             " Funds Center
      " LW_ACCOUNTGL-CMMT_ITEM        =                                             " Commitment Item
      " LW_ACCOUNTGL-CO_BUSPROC       =                                             " Business Process
      " LW_ACCOUNTGL-ASSET_NO         =                                             " Main Asset Number
      " LW_ACCOUNTGL-SUB_NUMBER       =                                             " Asset Subnumber
      " LW_ACCOUNTGL-BILL_TYPE        =                                             " Billing Type
      " LW_ACCOUNTGL-SALES_ORD        =                                             " Sales Order Number
      " LW_ACCOUNTGL-S_ORD_ITEM       =                                             " Item Number in Sales Order
      " LW_ACCOUNTGL-DISTR_CHAN       =                                             " Distribution Channel
      " LW_ACCOUNTGL-DIVISION         =                                             " Division
      " LW_ACCOUNTGL-SALESORG         =                                             " Sales Organization
      " LW_ACCOUNTGL-SALES_GRP        =                                             " Sales Group
      " LW_ACCOUNTGL-SALES_OFF        =                                             " Sales Office
      " LW_ACCOUNTGL-SOLD_TO          =                                             " Sold-to party
      " LW_ACCOUNTGL-DE_CRE_IND       =                                             " Indicator: subsequent debit/credit
      " LW_ACCOUNTGL-P_EL_PRCTR       =                                             " Partner profit center for elimination of internal business
      " LW_ACCOUNTGL-XMFRW            =                                             " Indicator: Update quantity in RW
      " LW_ACCOUNTGL-QUANTITY         =                                             " Quantity
      " LW_ACCOUNTGL-BASE_UOM         =                                             " Base Unit of Measure
      " LW_ACCOUNTGL-BASE_UOM_ISO     =                                             " Base unit of measure in ISO code
      " LW_ACCOUNTGL-INV_QTY          =                                             " Actual Invoiced Quantity
      " LW_ACCOUNTGL-INV_QTY_SU       =                                             " Billing quantity in stockkeeping unit
      " LW_ACCOUNTGL-SALES_UNIT       =                                             " Sales unit
      " LW_ACCOUNTGL-SALES_UNIT_ISO   =                                             " Sales unit in ISO code
      " LW_ACCOUNTGL-PO_PR_QNT        =                                             " Quantity in order price quantity unit
      " LW_ACCOUNTGL-PO_PR_UOM        =                                             " Order price unit (purchasing)
      " LW_ACCOUNTGL-PO_PR_UOM_ISO    =                                             " Purchase order price unit in ISO code
      " LW_ACCOUNTGL-ENTRY_QNT        =                                             " Quantity in Unit of Entry
      " LW_ACCOUNTGL-ENTRY_UOM        =                                             " Unit of Entry
      " LW_ACCOUNTGL-ENTRY_UOM_ISO    =                                             " Unit of entry in ISO code
      " LW_ACCOUNTGL-VOLUME           =                                             " Volume
      " LW_ACCOUNTGL-VOLUMEUNIT       =                                             " Volume unit
      " LW_ACCOUNTGL-VOLUMEUNIT_ISO   =                                             " Volume unit in ISO code
      " LW_ACCOUNTGL-GROSS_WT         =                                             " Gross Weight
      " LW_ACCOUNTGL-NET_WEIGHT       =                                             " Net weight
      " LW_ACCOUNTGL-UNIT_OF_WT       =                                             " Weight unit
      " LW_ACCOUNTGL-UNIT_OF_WT_ISO   =                                             " Unit of weight in ISO code
      " LW_ACCOUNTGL-ITEM_CAT         =                                             " Item category in purchasing document
      " LW_ACCOUNTGL-MATERIAL         =                                             " Material Number
      " LW_ACCOUNTGL-MATL_TYPE        =                                             " Material Type
      " LW_ACCOUNTGL-MVT_IND          =                                             " Movement Indicator
      " LW_ACCOUNTGL-REVAL_IND        =                                             " Revaluation
      " LW_ACCOUNTGL-ORIG_GROUP       =                                             " Origin Group as Subdivision of Cost Element
      " LW_ACCOUNTGL-ORIG_MAT         =                                             " Material-related origin
      " LW_ACCOUNTGL-SERIAL_NO        =                                             " Sequential number of account assignment
      " LW_ACCOUNTGL-PART_ACCT        =                                             " Partner Account Number
      " LW_ACCOUNTGL-TR_PART_BA       =                                             " Trading Partner's Business Area
      lw_accountgl-trade_id      = iw_item_gl-trade_id.                        " Company ID of Trading Partner
      " LW_ACCOUNTGL-VAL_AREA         =                                             " Valuation Area
      " LW_ACCOUNTGL-VAL_TYPE         =                                             " Valuation Type
      " LW_ACCOUNTGL-ASVAL_DATE       =                                             " Reference Date
      " LW_ACCOUNTGL-PO_NUMBER        =                                             " Purchasing Document Number
      " LW_ACCOUNTGL-PO_ITEM          =                                             " Item Number of Purchasing Document
      " LW_ACCOUNTGL-ITM_NUMBER       =                                             " Item number of the SD document
      " LW_ACCOUNTGL-COND_CATEGORY    =                                             " Condition Category (Examples: Tax, Freight, Price, Cost)
      " LW_ACCOUNTGL-FUNC_AREA_LONG   =                                             " Functional Area
      " LW_ACCOUNTGL-CMMT_ITEM_LONG   =                                             " Commitment Item
      " LW_ACCOUNTGL-GRANT_NBR        =                                             " Grant
      " LW_ACCOUNTGL-CS_TRANS_T       =                                             " Transaction Type
      " LW_ACCOUNTGL-MEASURE          =                                             " Funded Program
      " LW_ACCOUNTGL-SEGMENT          =                                             " Segment for Segmental Reporting
      " LW_ACCOUNTGL-PARTNER_SEGMENT  =                                             " Partner Segment for Segmental Reporting
      " LW_ACCOUNTGL-RES_DOC          =                                             " Document Number for Earmarked Funds
      " LW_ACCOUNTGL-RES_ITEM         =                                             " Earmarked Funds: Document Item
      " LW_ACCOUNTGL-BILLING_PERIOD_START_DATE =                                    " Billing Period of Performance Start Date
      " LW_ACCOUNTGL-BILLING_PERIOD_END_DATE   =                                    " Billing Period of Performance End Date
      " LW_ACCOUNTGL-PPA_EX_IND                =                                    " PPA Exclude Indicator
      " LW_ACCOUNTGL-FASTPAY                   =                                    " PPA Fast Pay Indicator
      " LW_ACCOUNTGL-PARTNER_GRANT_NBR         =                                    " Partner Grant
      " LW_ACCOUNTGL-BUDGET_PERIOD             =                                    " FM: Budget Period
      " LW_ACCOUNTGL-PARTNER_BUDGET_PERIOD     =                                    " FM: Partner Budget Period
      " LW_ACCOUNTGL-PARTNER_FUND              =                                    " Partner Fund
      " LW_ACCOUNTGL-ITEMNO_TAX                =                                    " Document item number referring to tax document.
      " LW_ACCOUNTGL-PAYMENT_TYPE              =                                    " Payment Type for Grantor
      " LW_ACCOUNTGL-EXPENSE_TYPE              =                                    " Expense Type for Grantor
      " LW_ACCOUNTGL-PROGRAM_PROFILE           =                                    " Grantor Program Profile
      lw_accountgl-businessplace = iw_document-businessplace.           " Business place

      _convert_structure_conversion( CHANGING cw_data = lw_accountgl ).

      APPEND lw_accountgl TO ct_accountgl.

      _fill_currencyamount( EXPORTING iw_document       = iw_document
                                      iw_item_gl        = iw_item_gl
                            CHANGING  ct_currencyamount = ct_currencyamount ).

***      "------------------------------------------------------------------------------------"
***      "COPA : Example
***      "------------------------------------------------------------------------------------"
***      IF lw_document-paobjnr IS NOT INITIAL.
***        lw_accountgl-salesorg   = lw_document-vkorg.
***        lw_accountgl-distr_chan = lw_document-vtweg.
***        lw_accountgl-division   = lw_document-spart.
***
***        IF lw_accountgl-salesorg   IS INITIAL
***       AND lw_accountgl-distr_chan IS INITIAL
***       AND lw_accountgl-division   IS INITIAL
***       AND lw_document-vkbur       IS INITIAL
***       AND lw_document-vkgrp       IS INITIAL.
***          SELECT FROM knvv
***          FIELDS kunnr,
***                 vkorg,
***                 vtweg,
***                 spart,
***                 vkbur,
***                 vkgrp
***          WHERE kunnr = @lw_document-kunre
***            AND vkorg = @lv_bukrs
***          ORDER BY vkorg, vtweg, spart ASCENDING
***           INTO @DATA(ls_knvv)
***             UP TO 1 ROWS.
***            IF sy-subrc = 0.
***              lw_accountgl-salesorg   = ls_knvv-vkorg.
***              lw_accountgl-distr_chan = ls_knvv-vtweg.
***              lw_accountgl-division   = ls_knvv-spart.
***              lw_document-vkbur       = ls_knvv-vkbur.
***              lw_document-vkgrp       = ls_knvv-vkgrp.
***            ENDIF.
***          ENDSELECT.
***        ENDIF.
***
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'VKBUR'
***                        character  = lw_document-vkbur ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'VKGRP'
***                        character  = lw_document-vkgrp ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'MTART'
***                        character  = lw_document-mtart ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'KDGRP'
***                        character  = lw_document-kdgrp ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'LAND1'
***                        character  = lw_document-land1 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'BZIRK'
***                        character  = lw_document-bzirk ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'WW102'
***                        character  = lw_document-ww102 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'WW103'
***                        character  = lw_document-ww103 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'PROVG'
***                        character  = lw_document-provg ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'MATKL'
***                        character  = lw_document-matkl ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'WW106'
***                        character  = lw_document-ww106 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'ARTNR'
***                        character  = lw_document-artnr ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'MVGR1'
***                        character  = lw_document-mvgr1 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'MVGR2'
***                        character  = lw_document-mvgr2 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'MVGR3'
***                        character  = lw_document-mvgr3 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'MVGR4'
***                        character  = lw_document-mvgr4 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'MVGR5'
***                        character  = lw_document-mvgr5 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'PRODH'
***                        character  = lw_document-prodh ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'WW105'
***                        character  = lw_document-ww105 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'WW107'
***                        character  = lw_document-ww107 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'MAABC'
***                        character  = lw_document-maabc ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'KUNRE'
***                        character  = lw_document-kunre ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'KUNWE'
***                        character  = lw_document-kunwe ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'KVGR1'
***                        character  = lw_document-kvgr1 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'KVGR2'
***                        character  = lw_document-kvgr2 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'KVGR3'
***                        character  = lw_document-kvgr3 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'KVGR4'
***                        character  = lw_document-kvgr4 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'KVGR5'
***                        character  = lw_document-kvgr5 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'WW104'
***                        character  = lw_document-ww104 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'WW108'
***                        character  = lw_document-ww108 ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'ZTERM'
***                        character  = lw_document-zterm ) TO ct_criteria.
***        APPEND VALUE #( itemno_acc = me->mv_itemno_acc
***                        fieldname  = 'INCO1'
***                        character  = lw_document-inco1 ) TO ct_criteria.
***      ENDIF.
***      "------------------------------------------------------------------------------------"

    ELSEIF iw_accountgl IS SUPPLIED.
      mv_itemno_acc = mv_itemno_acc + 1.

      lw_accountgl = CORRESPONDING #( iw_accountgl ).
      lw_accountgl-itemno_acc = mv_itemno_acc.

      _convert_structure_conversion( CHANGING cw_data = lw_accountgl ).

      APPEND lw_accountgl TO ct_accountgl.

      _fill_currencyamount( EXPORTING iw_currencyamount = iw_currencyamount
                            CHANGING  ct_currencyamount = ct_currencyamount ).
    ENDIF.
  ENDMETHOD.


  METHOD _fill_accountpayable.
    " TODO: parameter CT_ACCOUNTTAX is only used or assigned in commented-out code (ABAP cleaner)
    " TODO: parameter CT_CRITERIA is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_VALUEFIELD is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_EXTENSION1 is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_PAYMENTCARD is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_CONTRACTITEM is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_EXTENSION2 is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_REALESTATE is never used or assigned (ABAP cleaner)

    DATA lw_accountpayable TYPE bapiacap09.
    DATA lw_lfa1           TYPE lfa1.
    DATA lv_lifnr          TYPE lfa1-lifnr.

    IF iw_item_apar IS SUPPLIED.
      _convert_dynamic_conv_value( EXPORTING iv_input  = iw_item_apar-account_no
                                   IMPORTING ev_output = lv_lifnr ).

      CALL FUNCTION 'LFA1_SINGLE_READ'
        EXPORTING
          lfa1_lifnr    = lv_lifnr
        IMPORTING
          wlfa1         = lw_lfa1
        EXCEPTIONS
          not_found     = 1
          lifnr_blocked = 2
          OTHERS        = 3.
      IF sy-subrc = 1.
*        RETURN.
      ENDIF.

      mv_itemno_acc = mv_itemno_acc + 1.

      lw_accountpayable-itemno_acc         = mv_itemno_acc.            " Accounting Document Line Item Number
      lw_accountpayable-vendor_no          = lv_lifnr.                     " Account Number of Vendor or Creditor
      " LW_ACCOUNTPAYABLE-GL_ACCOUNT      =                               " General Ledger Account
      lw_accountpayable-ref_key_1          = iw_item_apar-ref_key_1.       " Business Partner Reference Key
      lw_accountpayable-ref_key_2          = iw_item_apar-ref_key_2.       " Business Partner Reference Key
      lw_accountpayable-ref_key_3          = iw_item_apar-ref_key_3.       " Reference Key for Line Item
      lw_accountpayable-comp_code          = iw_document-comp_code.        " Company Code
      " LW_ACCOUNTPAYABLE-BUS_AREA        =                               " Business Area
      lw_accountpayable-pmnttrms           = iw_item_apar-pmnttrms.        " Terms of Payment Key
      lw_accountpayable-bline_date         = iw_item_apar-bline_date.      " Baseline Date For Due Date Calculation
      " LW_ACCOUNTPAYABLE-dsct_days1      =                               " Days for first cash discount
      " LW_ACCOUNTPAYABLE-DSCT_DAYS2      =                               " Days for second cash discount
      " LW_ACCOUNTPAYABLE-NETTERMS        =                               " Deadline for net conditions
      " LW_ACCOUNTPAYABLE-DSCT_PCT1       =                               " Percentage for First Cash Discount
      " LW_ACCOUNTPAYABLE-DSCT_PCT2       =                               " Percentage for Second Cash Discount
      lw_accountpayable-pymt_meth          = iw_item_apar-pymt_meth.       " Payment method
      " LW_ACCOUNTPAYABLE-PMTMTHSUPL      =                               " Payment Method Supplement
      lw_accountpayable-pmnt_block         = iw_item_apar-pmnt_block.      " Payment block key
      " LW_ACCOUNTPAYABLE-SCBANK_IND      =                               " State Central Bank Indicator
      " LW_ACCOUNTPAYABLE-SUPCOUNTRY      =                               " Supplying Country
      " LW_ACCOUNTPAYABLE-SUPCOUNTRY_ISO  =                               " Supplier country ISO code
      " LW_ACCOUNTPAYABLE-BLLSRV_IND      =                               " Service Indicator (Foreign Payment)
      lw_accountpayable-alloc_nmbr         = iw_item_apar-alloc_nmbr.      " Assignment Number
      lw_accountpayable-item_text          = iw_item_apar-item_text.       " Item Text
      " LW_ACCOUNTPAYABLE-PO_SUB_NO       =                               " ISR Subscriber Number
      " LW_ACCOUNTPAYABLE-PO_CHECKDG      =                               " ISR Check Digit
      " LW_ACCOUNTPAYABLE-PO_REF_NO       =                               " ISR Reference Number
      " LW_ACCOUNTPAYABLE-W_TAX_CODE      =                               " Withholding tax code
      lw_accountpayable-businessplace      = iw_document-businessplace.    " Business Place
      " LW_ACCOUNTPAYABLE-SECTIONCODE     =                               " Section Code
      " LW_ACCOUNTPAYABLE-INSTR1          =                               " Instruction Key 1
      " LW_ACCOUNTPAYABLE-INSTR2          =                               " Instruction Key 2
      " LW_ACCOUNTPAYABLE-INSTR3          =                               " Instruction Key 3
      " LW_ACCOUNTPAYABLE-INSTR4          =                               " Instruction Key 4
      " LW_ACCOUNTPAYABLE-BRANCH          =                               " Account number of the branch
      " LW_ACCOUNTPAYABLE-PYMT_CUR        =                               " Currency for automatic payment
      " LW_ACCOUNTPAYABLE-PYMT_AMT        =                               " Amount in Payment Currency
      " LW_ACCOUNTPAYABLE-PYMT_CUR_ISO    =                               " ISO code currency
      lw_accountpayable-sp_gl_ind          = COND #( WHEN iw_item_apar-newum IS NOT INITIAL THEN
                                                       iw_item_apar-newum
                                                     WHEN iw_item_apar-note_item IS NOT INITIAL THEN
                                                       iw_item_apar-note_item ).  " Special G/L Indicator
      lw_accountpayable-tax_code           = iw_item_apar-tax_code.        " Tax on sales/purchases code
      " LW_ACCOUNTPAYABLE-TAX_DATE        =                               " Date Relevant for Determining the Tax Rate
      " LW_ACCOUNTPAYABLE-TAXJURCODE      =                               " Tax Jurisdiction
      " LW_ACCOUNTPAYABLE-ALT_PAYEE       =                               " Alternative payee
      " LW_ACCOUNTPAYABLE-ALT_PAYEE_BANK  =                               " Bank type of alternative payer
      lw_accountpayable-partner_bk         = iw_item_apar-bvtyp.            " Partner Bank Type
      " LW_ACCOUNTPAYABLE-bank_id         =                               " Short Key for a House Bank
      " LW_ACCOUNTPAYABLE-PARTNER_GUID    =                               " Com. Interface: Business Partner GUID
      " LW_ACCOUNTPAYABLE-PROFIT_CTR      =                               " Profit Center
      " LW_ACCOUNTPAYABLE-FUND            =                               " Fund
      " LW_ACCOUNTPAYABLE-GRANT_NBR       =                               " Grant
      " LW_ACCOUNTPAYABLE-MEASURE         =                               " Funded Program
      " LW_ACCOUNTPAYABLE-HOUSEBANKACCTID =                               " ID for Account Details
      " LW_ACCOUNTPAYABLE-BUDGET_PERIOD   =                               " FM: Budget Period
      " LW_ACCOUNTPAYABLE-PPA_EX_IND      =                               " PPA Exclude Indicator
      lw_accountpayable-part_businessplace = iw_item_apar-part_bupla.   " Branch Code

      _convert_structure_conversion( CHANGING cw_data = lw_accountpayable ).

      APPEND lw_accountpayable TO ct_accountpayable.

      IF     lw_lfa1-xcpdk     IS NOT INITIAL
         AND iw_item_apar-name IS NOT INITIAL.
        _fill_vendor_customer_onetime( EXPORTING iw_document    = iw_document
                                                 iw_item_apar   = iw_item_apar
                                       CHANGING  cw_customercpd = cw_customercpd ).
      ENDIF.

      IF iw_item_apar-witht IS NOT INITIAL.
        _fill_accountwt( EXPORTING iw_accountwt = VALUE #( wt_type         = iw_item_apar-witht
                                                           wt_code         = iw_item_apar-wt_code
                                                           bas_amt_tc_long = iw_item_apar-bas_amt_tc
                                                           man_amt_tc_long = iw_item_apar-wt_qbshb )
                         CHANGING  ct_accountwt = ct_accountwt ).
      ENDIF.

      IF iw_item_apar-witht2 IS NOT INITIAL.
        _fill_accountwt( EXPORTING iw_accountwt = VALUE #( wt_type         = iw_item_apar-witht2
                                                           wt_code         = iw_item_apar-wt_code2
                                                           bas_amt_tc_long = iw_item_apar-bas_amt_tc2
                                                           man_amt_tc_long = iw_item_apar-wt_qbshb2 )
                         CHANGING  ct_accountwt = ct_accountwt ).
      ENDIF.

      IF iw_item_apar-tax_code IS NOT INITIAL.
        _fill_currencyamount( EXPORTING iw_document       = iw_document
                                        iw_item_apar      = iw_item_apar
                              CHANGING  ct_currencyamount = ct_currencyamount ).

*      me->_fill_accounttax(
*        EXPORTING
*          iw_document       = iw_document
*          iw_item_apar      = iw_item_apar
*        CHANGING
*          ct_accounttax     = ct_accounttax
*          ct_currencyamount = ct_currencyamount ).
      ELSE.
        _fill_currencyamount( EXPORTING iw_document       = iw_document
                                        iw_item_apar      = iw_item_apar
                              CHANGING  ct_currencyamount = ct_currencyamount ).
      ENDIF.
    ELSEIF iw_accountpayable IS SUPPLIED.
      _convert_dynamic_conv_value( EXPORTING iv_input  = iw_accountpayable-vendor_no
                                   IMPORTING ev_output = lv_lifnr ).

      CALL FUNCTION 'LFA1_SINGLE_READ'
        EXPORTING
          lfa1_lifnr    = lv_lifnr
        IMPORTING
          wlfa1         = lw_lfa1
        EXCEPTIONS
          not_found     = 1
          lifnr_blocked = 2
          OTHERS        = 3.
      IF sy-subrc = 1.
*        RETURN.
      ENDIF.

      mv_itemno_acc = mv_itemno_acc + 1.

      lw_accountpayable            = CORRESPONDING #( iw_accountpayable ).
      lw_accountpayable-itemno_acc = mv_itemno_acc.             " Accounting Document Line Item Number

      _convert_structure_conversion( CHANGING cw_data = lw_accountpayable ).

      APPEND lw_accountpayable TO ct_accountpayable.

      IF lw_accountpayable-tax_code IS NOT INITIAL.
        _fill_currencyamount( EXPORTING iw_currencyamount = iw_currencyamount
                              CHANGING  ct_currencyamount = ct_currencyamount ).
      ELSE.
        _fill_currencyamount( EXPORTING iw_currencyamount = iw_currencyamount
                              CHANGING  ct_currencyamount = ct_currencyamount ).
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD _fill_accountreceivable.
    " TODO: parameter CT_ACCOUNTTAX is only used or assigned in commented-out code (ABAP cleaner)
    " TODO: parameter CT_CRITERIA is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_VALUEFIELD is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_EXTENSION1 is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_PAYMENTCARD is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_CONTRACTITEM is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_EXTENSION2 is never used or assigned (ABAP cleaner)
    " TODO: parameter CT_REALESTATE is never used or assigned (ABAP cleaner)

    DATA lw_accountreceivable TYPE bapiacar09.
    DATA lw_kna1              TYPE kna1.
    DATA lv_kunnr             TYPE kna1-kunnr.

    IF iw_item_apar IS SUPPLIED.
      _convert_dynamic_conv_value( EXPORTING iv_input  = iw_item_apar-account_no
                                   IMPORTING ev_output = lv_kunnr ).

      CALL FUNCTION 'KNA1_SINGLE_READ'
        EXPORTING
          kna1_kunnr    = lv_kunnr
        IMPORTING
          wkna1         = lw_kna1
        EXCEPTIONS
          not_found     = 1
          kunnr_blocked = 2
          OTHERS        = 3.
      IF sy-subrc = 1.
*        RETURN.
      ENDIF.

      mv_itemno_acc = mv_itemno_acc + 1.

      lw_accountreceivable-itemno_acc         = mv_itemno_acc.             " Accounting Document Line Item Number
      lw_accountreceivable-customer           = lv_kunnr.                      " Customer Number
      " LW_ACCOUNTRECEIVABLE-GL_ACCOUNT      =                                " General Ledger Account
      lw_accountreceivable-ref_key_1          = iw_item_apar-ref_key_1.        " Business Partner Reference Key
      lw_accountreceivable-ref_key_2          = iw_item_apar-ref_key_2.        " Business Partner Reference Key
      lw_accountreceivable-ref_key_3          = iw_item_apar-ref_key_3.        " Reference Key for Line Item
      lw_accountreceivable-comp_code          = iw_document-comp_code.        " Company Code
      " LW_ACCOUNTRECEIVABLE-BUS_AREA        =                                " Business Area
      lw_accountreceivable-pmnttrms           = iw_item_apar-pmnttrms.         " Terms of Payment Key
      lw_accountreceivable-bline_date         = iw_item_apar-bline_date.       " Baseline Date For Due Date Calculation
      " LW_ACCOUNTRECEIVABLE-dsct_days1      =                                " Days for first cash discount
      " LW_ACCOUNTRECEIVABLE-DSCT_DAYS2      =                                " Days for second cash discount
      " LW_ACCOUNTRECEIVABLE-NETTERMS        =                                " Deadline for net conditions
      " LW_ACCOUNTRECEIVABLE-DSCT_PCT1       =                                " Percentage for First Cash Discount
      " LW_ACCOUNTRECEIVABLE-DSCT_PCT2       =                                " Percentage for Second Cash Discount
      lw_accountreceivable-pymt_meth          = iw_item_apar-pymt_meth.        " Payment method
      " LW_ACCOUNTRECEIVABLE-PMTMTHSUPL      =                                " Payment Method Supplement
      " LW_ACCOUNTRECEIVABLE-PAYMT_REF       =                                " Payment Reference
      " LW_ACCOUNTRECEIVABLE-DUNN_KEY        =                                " Dunning keys
      " LW_ACCOUNTRECEIVABLE-DUNN_BLOCK      =                                " Dunning block
      lw_accountreceivable-pmnt_block         = iw_item_apar-pmnt_block.       " Payment block key
      " LW_ACCOUNTRECEIVABLE-VAT_REG_NO      =                                " VAT Registration Number
      lw_accountreceivable-alloc_nmbr         = iw_item_apar-alloc_nmbr.       " Assignment Number
      lw_accountreceivable-item_text          = iw_item_apar-item_text.        " Item Text
      lw_accountreceivable-partner_bk         = iw_item_apar-bvtyp.            " Partner Bank Type
      " LW_ACCOUNTRECEIVABLE-SCBANK_IND      =                                " State Central Bank Indicator
      lw_accountreceivable-businessplace      = iw_document-businessplace.     " Business Place
      " LW_ACCOUNTRECEIVABLE-SECTIONCODE     =                                " Section Code
      " LW_ACCOUNTRECEIVABLE-BRANCH          =                                " Account number of the branch
      " LW_ACCOUNTRECEIVABLE-PYMT_CUR        =                                " Currency for automatic payment
      " LW_ACCOUNTRECEIVABLE-PYMT_CUR_ISO    =                                " ISO code currency
      " LW_ACCOUNTRECEIVABLE-PYMT_AMT        =                                " Amount in Payment Currency
      " LW_ACCOUNTRECEIVABLE-C_CTR_AREA      =                                " Credit control area
      " LW_ACCOUNTRECEIVABLE-bank_id         =                                " Short Key for a House Bank
      " LW_ACCOUNTRECEIVABLE-SUPCOUNTRY      =                                " Supplying Country
      " LW_ACCOUNTRECEIVABLE-SUPCOUNTRY_ISO  =                                " Supplier country ISO code
      lw_accountreceivable-tax_code           = iw_item_apar-tax_code.         " Tax on sales/purchases code
      " LW_ACCOUNTRECEIVABLE-TAXJURCODE      =                                " Tax Jurisdiction
      " LW_ACCOUNTRECEIVABLE-TAX_DATE        =                                " Date Relevant for Determining the Tax Rate
      lw_accountreceivable-sp_gl_ind          = COND #( WHEN iw_item_apar-newum IS NOT INITIAL THEN
                                                          iw_item_apar-newum
                                                        WHEN iw_item_apar-note_item IS NOT INITIAL THEN
                                                          iw_item_apar-note_item ).  " Special G/L Indicator
      " LW_ACCOUNTRECEIVABLE-PARTNER_GUID    =                                " Com. Interface: Business Partner GUID
      " LW_ACCOUNTRECEIVABLE-ALT_PAYEE       =                                " Alternative payee
      " LW_ACCOUNTRECEIVABLE-ALT_PAYEE_BANK  =                                " Bank type of alternative payer
      " LW_ACCOUNTRECEIVABLE-DUNN_AREA       =                                " Dunning Area
      " LW_ACCOUNTRECEIVABLE-CASE_GUID       =                                " Technical Case Key (Case GUID)
      " LW_ACCOUNTRECEIVABLE-PROFIT_CTR      =                                " Profit Center
      " LW_ACCOUNTRECEIVABLE-FUND            =                                " Fund
      " LW_ACCOUNTRECEIVABLE-GRANT_NBR       =                                " Grant
      " LW_ACCOUNTRECEIVABLE-MEASURE         =                                " Funded Program
      " LW_ACCOUNTRECEIVABLE-housebankacctid =                                " ID for Account Details
      " LW_ACCOUNTRECEIVABLE-RES_DOC         =                                " Document Number for Earmarked Funds
      " LW_ACCOUNTRECEIVABLE-RES_ITEM        =                                " Earmarked Funds: Document Item
      " LW_ACCOUNTRECEIVABLE-FUND_LONG       =                                " Long Fund (Obsolete)
      " LW_ACCOUNTRECEIVABLE-DISPUTE_IF_TYPE =                                " Dispute Management: Dispute Interface Category
      " LW_ACCOUNTRECEIVABLE-BUDGET_PERIOD   =                                " FM: Budget Period
      " LW_ACCOUNTRECEIVABLE-PAYS_PROV       =                                " Payment Service Provider
      " LW_ACCOUNTRECEIVABLE-PAYS_TRAN       =                                " Payment Reference of Payment Service Provider
      " LW_ACCOUNTRECEIVABLE-SEPA_MANDATE_ID =                                " Unique Reference to Mandate for each Payee
      lw_accountreceivable-part_businessplace = iw_item_apar-part_bupla.    " Branch Code

      _convert_structure_conversion( CHANGING cw_data = lw_accountreceivable ).

      APPEND lw_accountreceivable TO ct_accountreceivable.

      IF     lw_kna1-xcpdk     IS NOT INITIAL
         AND iw_item_apar-name IS NOT INITIAL.
        _fill_vendor_customer_onetime( EXPORTING iw_document    = iw_document
                                                 iw_item_apar   = iw_item_apar
                                       CHANGING  cw_customercpd = cw_customercpd ).
      ENDIF.

      IF iw_item_apar-witht IS NOT INITIAL.
        _fill_accountwt( EXPORTING iw_accountwt = VALUE #( wt_type    = iw_item_apar-witht
                                                           wt_code    = iw_item_apar-wt_code
                                                           bas_amt_tc = iw_item_apar-bas_amt_tc
                                                           man_amt_tc = iw_item_apar-wt_qbshb )
                         CHANGING  ct_accountwt = ct_accountwt ).
      ENDIF.

      IF iw_item_apar-witht2 IS NOT INITIAL.
        _fill_accountwt( EXPORTING iw_accountwt = VALUE #( wt_type    = iw_item_apar-witht2
                                                           wt_code    = iw_item_apar-wt_code2
                                                           bas_amt_tc = iw_item_apar-bas_amt_tc2
                                                           man_amt_tc = iw_item_apar-wt_qbshb2 )
                         CHANGING  ct_accountwt = ct_accountwt ).
      ENDIF.

      IF iw_item_apar-tax_code IS NOT INITIAL.
        _fill_currencyamount( EXPORTING iw_document       = iw_document
                                        iw_item_apar      = iw_item_apar
                              CHANGING  ct_currencyamount = ct_currencyamount ).

*      me->_fill_accounttax(
*        EXPORTING
*          iw_document       = iw_document
*          iw_item_apar      = iw_item_apar
*        CHANGING
*          ct_accounttax     = ct_accounttax
*          ct_currencyamount = ct_currencyamount ).
      ELSE.
        _fill_currencyamount( EXPORTING iw_document       = iw_document
                                        iw_item_apar      = iw_item_apar
                              CHANGING  ct_currencyamount = ct_currencyamount ).
      ENDIF.
    ELSEIF iw_accountreceivable IS SUPPLIED.
      _convert_dynamic_conv_value( EXPORTING iv_input  = iw_accountreceivable-customer
                                   IMPORTING ev_output = lv_kunnr ).

      CALL FUNCTION 'KNA1_SINGLE_READ'
        EXPORTING
          kna1_kunnr    = lv_kunnr
        IMPORTING
          wkna1         = lw_kna1
        EXCEPTIONS
          not_found     = 1
          kunnr_blocked = 2
          OTHERS        = 3.
      IF sy-subrc = 1.
*        RETURN.
      ENDIF.

      mv_itemno_acc = mv_itemno_acc + 1.

      lw_accountreceivable            = CORRESPONDING #( iw_accountreceivable ).
      lw_accountreceivable-itemno_acc = mv_itemno_acc.             " Accounting Document Line Item Number

      _convert_structure_conversion( CHANGING cw_data = lw_accountreceivable ).

      APPEND lw_accountreceivable TO ct_accountreceivable.

      IF lw_accountreceivable-tax_code IS NOT INITIAL.
        _fill_currencyamount( EXPORTING iw_currencyamount = iw_currencyamount
                              CHANGING  ct_currencyamount = ct_currencyamount ).
      ELSE.
        _fill_currencyamount( EXPORTING iw_currencyamount = iw_currencyamount
                              CHANGING  ct_currencyamount = ct_currencyamount ).
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD _fill_accounttax.
    DATA lw_accounttax TYPE bapiactx09.
    DATA lw_t001       TYPE t001.

    IF    iw_item_apar IS SUPPLIED
       OR iw_item_gl   IS SUPPLIED.
      " New position with calculated tax
      mv_itemno_acc = mv_itemno_acc + 1.

      lw_accounttax-itemno_acc = mv_itemno_acc.           " Accounting Document Line Item Number
      lw_accounttax-gl_account = COND #( WHEN iw_item_apar IS SUPPLIED THEN iw_item_apar-account_no
                                         WHEN iw_item_gl IS SUPPLIED   THEN iw_item_gl-gl_account ).  " General Ledger Account
      " LW_ACCOUNTTAX-COND_KEY          = LW_MWDAT-KSCHL.             " CONDITION TYPE
      " LW_ACCOUNTTAX-ACCT_KEY          = LW_MWDAT-ktosl.             " Transaction Key
      lw_accounttax-tax_code   = COND #( WHEN iw_item_apar IS SUPPLIED THEN iw_item_apar-tax_code
                                         WHEN iw_item_gl IS SUPPLIED   THEN iw_item_gl-tax_code ).     " Tax on sales/purchases code
      " LW_ACCOUNTTAX-TAX_RATE         =                             " Tax rate
      " LW_ACCOUNTTAX-TAX_DATE         =                             " Date Relevant for Determining the Tax Rate
      " LW_ACCOUNTTAX-TAXJURCODE       =                             " Tax Jurisdiction
      " LW_ACCOUNTTAX-TAXJURCODE_DEEP  =                             " Tax jurisdiction code - jurisdiction for lowest level tax
      " LW_ACCOUNTTAX-TAXJURCODE_LEVEL =                             " Tax Jurisdiction Code Level
      " LW_ACCOUNTTAX-ITEMNO_TAX       =                             " Document item number referring to tax document.
      " LW_ACCOUNTTAX-DIRECT_TAX       =                             " Indicator: Direct Tax Posting
      " LW_ACCOUNTTAX-TAX_CALC_DT_FROM =                             " Valid-From Date of the Tax Rate
      " LW_ACCOUNTTAX-TAX_COUNTRY      =                             " Tax Reporting Country/Region

      " Determine the country of the company code
      CALL FUNCTION 'FI_COMPANY_CODE_DATA'
        EXPORTING
          i_bukrs      = iw_document-comp_code
        IMPORTING
          e_t001       = lw_t001
        EXCEPTIONS
          system_error = 1.
      IF sy-subrc = 0.
        lw_accounttax-tax_country = lw_t001-land1.
      ENDIF.

      _convert_structure_conversion( CHANGING cw_data = lw_accounttax ).

      APPEND lw_accounttax TO ct_accounttax.

      " Tax Amount in Document Currency
      _fill_currencyamount( EXPORTING iw_document       = iw_document
                                      iw_item_gl        = iw_item_gl
                            CHANGING  ct_currencyamount = ct_currencyamount ).
    ELSE.

    ENDIF.
  ENDMETHOD.


  METHOD _fill_accountwt.
    DATA lw_accountwt TYPE bapiacwt09.

    lw_accountwt            = CORRESPONDING #( iw_accountwt ).
    lw_accountwt-itemno_acc = mv_itemno_acc.              " Accounting Document Line Item Number

    IF lw_accountwt-wt_type IS INITIAL.
      RETURN.
    ENDIF.

    APPEND lw_accountwt TO ct_accountwt.

    " LW_ACCOUNTWT-itemno_acc  = .                                " Accounting Document Line Item Number
    " LW_ACCOUNTWT-wt_type     = .                                " Indicator for withholding tax type
    " LW_ACCOUNTWT-wt_code     = .                                " Withholding tax code
    " LW_ACCOUNTWT-BAS_AMT_LC  = .                                " Withholding Tax Base Amount (Local Currency)
    " LW_ACCOUNTWT-bas_amt_tc  = .                                " Withholding tax base amount in document currency
    " LW_ACCOUNTWT-BAS_AMT_L2  = .                                " Withholding tax base amount in 2nd local currency
    " LW_ACCOUNTWT-BAS_AMT_L3  = .                                " Withholding tax base amount in 3rd local currency
    " LW_ACCOUNTWT-MAN_AMT_LC  = .                                " Enter withholding tax amount in local currency manually
    " LW_ACCOUNTWT-man_amt_tc  = .                                " Enter withholding tax amount in document currency manually
    " LW_ACCOUNTWT-MAN_AMT_L2  = .                                " Manually entered with/tax amount in 2nd local currency
    " LW_ACCOUNTWT-MAN_AMT_L3  = .                                " With/tax amount in 3rd local currency entered manually
    " LW_ACCOUNTWT-AWH_AMT_LC  = .                                " Withholding tax amount (in local currency) already withheld
    " LW_ACCOUNTWT-AWH_AMT_TC  = .                                " Withholding tax amount already withheld in document currency
    " LW_ACCOUNTWT-AWH_AMT_L2  = .                                " Withholding tax amount already withheld in 2nd local curr.
    " LW_ACCOUNTWT-AWH_AMT_L3  = .                                " With/tax amount already withheld in 3rd local currency
    " LW_ACCOUNTWT-BAS_AMT_IND = .                                " Indicator: Withholding tax base amount entered manually
    " LW_ACCOUNTWT-MAN_AMT_IND = .                                " Indicator: Withholding tax amount entered manually
    " APPEND LW_ACCOUNTWT TO ct_accountwt.
  ENDMETHOD.


  METHOD _fill_currencyamount.
    DATA lw_currencyamount TYPE bapiaccr09.

    " (BAPIACCR09) Currency Items

    IF    iw_item_apar IS SUPPLIED
       OR iw_item_gl   IS SUPPLIED.
      lw_currencyamount-itemno_acc      = mv_itemno_acc.             " Accounting Document Line Item Number
      lw_currencyamount-curr_type       = '00'.                          " Currency Type and Valuation View
      lw_currencyamount-currency        = iw_document-currency.          " Currency Key
      lw_currencyamount-exch_rate       = iw_document-exchange_rate.     " Exchange rate
      " LW_CURRENCYAMOUNT-amt_doccur  =                                 " Amount in Document Currency
      " LW_CURRENCYAMOUNT-EXCH_RATE_V  =                                " Indirect quoted exchange rate
      " LW_CURRENCYAMOUNT-AMT_BASE     =                                " Tax Base Amount in Document Currency
      " LW_CURRENCYAMOUNT-DISC_BASE    =                                " Amount eligible for cash discount in document currency
      " LW_CURRENCYAMOUNT-DISC_AMT     =                                " Cash discount amount in the currency of the currency types
      " LW_CURRENCYAMOUNT-TAX_AMT      =                                " Amount in Document Currency
      lw_currencyamount-amt_doccur_long = COND #( WHEN iw_item_apar IS SUPPLIED THEN iw_item_apar-amt_doccur
                                                  WHEN iw_item_gl IS SUPPLIED   THEN iw_item_gl-amt_doccur ). " Amount in Document Currency (31 digits)
      lw_currencyamount-amt_base_long   = COND #( WHEN iw_item_apar IS SUPPLIED THEN iw_item_apar-amt_doccur
                                                  WHEN iw_item_gl IS SUPPLIED   THEN iw_item_gl-amt_base ). " Amount in Document Currency (31 digits)
      " LW_CURRENCYAMOUNT-DISC_BASE_LONG   =                            " Amount eligible for cash discount in document currency (31d)
      " LW_CURRENCYAMOUNT-DISC_AMT_LONG    =                            " Cash discount amount in the crcy of the currency types (31d)
      " LW_CURRENCYAMOUNT-TAX_AMT_LONG     =                            " Amount in Document Currency (31 digits)

*    me->_convert_to_local_amount(
*      EXPORTING
*        iv_company_code     = iw_document-comp_code
*        iv_foreign_currency = LW_CURRENCYAMOUNT-currency
*        iv_foreign_amount   = LW_CURRENCYAMOUNT-amt_doccur_long
*      CHANGING
*        cv_local_amount     = LW_CURRENCYAMOUNT-amt_base_long ).

      IF lw_currencyamount-currency IS NOT INITIAL.
        CALL FUNCTION 'CURRENCY_CODE_SAP_TO_ISO'
          EXPORTING
            sap_code  = lw_currencyamount-currency
          IMPORTING
            iso_code  = lw_currencyamount-currency_iso                " ISO code currency
          EXCEPTIONS
            not_found = 1
            OTHERS    = 2.
      ENDIF.

      APPEND lw_currencyamount TO ct_currencyamount.
    ELSEIF iw_currencyamount IS SUPPLIED.
      lw_currencyamount = CORRESPONDING #( iw_currencyamount ).

      IF lw_currencyamount-currency IS NOT INITIAL.
        CALL FUNCTION 'CURRENCY_CODE_SAP_TO_ISO'
          EXPORTING
            sap_code  = lw_currencyamount-currency
          IMPORTING
            iso_code  = lw_currencyamount-currency_iso                " ISO code currency
          EXCEPTIONS
            not_found = 1
            OTHERS    = 2.
      ENDIF.

      APPEND lw_currencyamount TO ct_currencyamount.
    ENDIF.
  ENDMETHOD.


  METHOD _fill_documentheader.
    " TODO: parameter CT_EXTENSION2 is never used or assigned (ABAP cleaner)

    IF iw_document IS SUPPLIED.
*     CW_DOCUMENTHEADER-obj_type         =                            " Reference Transaction
*     CW_DOCUMENTHEADER-obj_key          =                            " Reference Key
*     CW_DOCUMENTHEADER-obj_sys          =                            " Logical system of source document
      cw_documentheader-bus_act    = 'RFBU'.                    " Business Transaction
      cw_documentheader-username   = sy-uname.                  " User name
      cw_documentheader-header_txt = iw_document-header_txt.    " Document Header Text
      cw_documentheader-comp_code  = iw_document-comp_code.     " Company Code
      cw_documentheader-doc_date   = iw_document-doc_date.      " Document Date in Document
      cw_documentheader-pstng_date = iw_document-pstng_date.    " Posting Date in the Document
*     CW_DOCUMENTHEADER-trans_date       =                            " Translation Date
*     CW_DOCUMENTHEADER-fisc_year        =                            " Fiscal Year
*     CW_DOCUMENTHEADER-fis_period       =                            " Fiscal Period
      cw_documentheader-doc_type   = iw_document-doc_type.      " Document Type
      cw_documentheader-ref_doc_no = iw_document-ref_doc_no.    " Reference Document Number
*     CW_DOCUMENTHEADER-ac_doc_no        =                            " Accounting Document Number
*     CW_DOCUMENTHEADER-obj_key_r        =                            " Cancel: object key (AWREF_REV and AWORG_REV)
*     CW_DOCUMENTHEADER-reason_rev       =                            " Reason for reversal
*     CW_DOCUMENTHEADER-compo_acc        =                            " Component in ACC Interface
*     CW_DOCUMENTHEADER-ref_doc_no_long  =                            " Reference Document Number (for Dependencies see Long Text)
*     CW_DOCUMENTHEADER-acc_principle    =                            " Accounting Principle
*     CW_DOCUMENTHEADER-neg_postng       =                            " Indicator: Negative posting
*     CW_DOCUMENTHEADER-obj_key_inv      =                            " Invoice Ref.: Object Key (AWREF_REB and AWORG_REB)
*     CW_DOCUMENTHEADER-bill_category    =                            " Billing category
*     CW_DOCUMENTHEADER-vatdate          =                            " Tax Reporting Date
*     CW_DOCUMENTHEADER-invoice_rec_date =                            " Invoice Receipt Date
*     CW_DOCUMENTHEADER-ecs_env          =                            " ECS Environment
*     CW_DOCUMENTHEADER-partial_rev      =                            " Indicator: Partial Reversal
    ELSEIF iw_documentheader IS SUPPLIED.
      cw_documentheader         = CORRESPONDING #( iw_documentheader ).
      cw_documentheader-bus_act  = COND #( WHEN cw_documentheader-bus_act IS INITIAL
                                           THEN 'RFBU'           " Business Transaction
                                           ELSE cw_documentheader-bus_act ).
      cw_documentheader-username = COND #( WHEN cw_documentheader-username IS INITIAL
                                           THEN sy-uname       " User name
                                           ELSE cw_documentheader-username ).
    ENDIF.
  ENDMETHOD.


  METHOD _fill_vendor_customer_onetime.
    " TODO: parameter IW_DOCUMENT is never used (ABAP cleaner)

    IF iw_item_apar IS SUPPLIED.
      cw_customercpd-name       = iw_item_apar-name.
      cw_customercpd-name_2     = iw_item_apar-name_2.
      cw_customercpd-name_3     = iw_item_apar-name_3.
      cw_customercpd-name_4     = iw_item_apar-name_4.
      cw_customercpd-city       = iw_item_apar-city.
      cw_customercpd-country    = iw_item_apar-country.
      cw_customercpd-street     = iw_item_apar-street.
      cw_customercpd-postl_code = iw_item_apar-post_code.
      cw_customercpd-tax_no_1   = iw_item_apar-tax_no_1.
      cw_customercpd-tax_no_2   = iw_item_apar-tax_no_2.
      cw_customercpd-tax_no_3   = iw_item_apar-tax_no_3.
      cw_customercpd-bank_acct  = iw_item_apar-bank_acct.
      cw_customercpd-bank_no    = iw_item_apar-bank_no.
      cw_customercpd-bank_ctry  = iw_item_apar-bank_ctry.

      IF cw_customercpd-country IS NOT INITIAL.
        CALL FUNCTION 'COUNTRY_CODE_SAP_TO_ISO'
          EXPORTING
            sap_code  = cw_customercpd-country
          IMPORTING
            iso_code  = cw_customercpd-country_iso
          EXCEPTIONS
            not_found = 1
            OTHERS    = 2.
      ENDIF.
    ELSE.

    ENDIF.

    _convert_structure_conversion( CHANGING cw_data = cw_customercpd ).
  ENDMETHOD.


  METHOD post_document.
    IF iv_check IS NOT INITIAL.
      DATA(lv_check)  = abap_true.
    ELSE.
      DATA(lv_post)   = abap_true.
      DATA(lv_commit) = abap_true.
    ENDIF.

    prepare_document_from_json( EXPORTING iw_document          = iw_document
                                IMPORTING ew_documentheader    = DATA(lw_documentheader)
                                          ew_customercpd       = DATA(lw_customercpd)
                                          ew_contractheader    = DATA(lw_contractheader)
                                          et_accountgl         = DATA(lt_accountgl)
                                          et_accountreceivable = DATA(lt_accountreceivable)
                                          et_accountpayable    = DATA(lt_accountpayable)
                                          et_accounttax        = DATA(lt_accounttax)
                                          et_currencyamount    = DATA(lt_currencyamount)
                                          et_criteria          = DATA(lt_criteria)
                                          et_valuefield        = DATA(lt_valuefield)
                                          et_extension1        = DATA(lt_extension1)
                                          et_paymentcard       = DATA(lt_paymentcard)
                                          et_contractitem      = DATA(lt_contractitem)
                                          et_extension2        = DATA(lt_extension2)
                                          et_realestate        = DATA(lt_realestate)
                                          et_accountwt         = DATA(lt_accountwt) ).

    post_document_from_json( EXPORTING iw_documentheader    = lw_documentheader
                                       iw_customercpd       = lw_customercpd
                                       iw_contractheader    = lw_contractheader
                                       iv_testrun           = lv_check
                                       iv_postdocument      = lv_post
                                       iv_commit_work       = lv_commit
                             IMPORTING ev_bukrs             = DATA(lv_bukrs)
                                       ev_belnr             = DATA(lv_belnr)
                                       ev_gjahr             = DATA(lv_gjahr)
                                       et_return            = DATA(lt_return)
                                       ev_error             = DATA(lv_error)
                             CHANGING  ct_accountgl         = lt_accountgl
                                       ct_accountreceivable = lt_accountreceivable
                                       ct_accountpayable    = lt_accountpayable
                                       ct_accounttax        = lt_accounttax
                                       ct_currencyamount    = lt_currencyamount
                                       ct_criteria          = lt_criteria
                                       ct_valuefield        = lt_valuefield
                                       ct_extension1        = lt_extension1
                                       ct_paymentcard       = lt_paymentcard
                                       ct_contractitem      = lt_contractitem
                                       ct_extension2        = lt_extension2
                                       ct_realestate        = lt_realestate
                                       ct_accountwt         = lt_accountwt ).

    IF lv_error IS INITIAL.
      IF     lv_bukrs IS NOT INITIAL
         AND lv_belnr IS NOT INITIAL
         AND lv_gjahr IS NOT INITIAL.
        update_legacy_ref_from_json( iv_bukrs    = lv_bukrs
                                     iv_belnr    = lv_belnr
                                     iv_gjahr    = lv_gjahr
                                     iv_xref1_hd = iw_document-legacy_ref ).
      ENDIF.

      DELETE lt_return WHERE type <> gc_success.
      DATA(lv_lines) = lines( lt_return ).
      READ TABLE lt_return INTO DATA(ls_return) INDEX lv_lines.

      READ TABLE cw_result-t_result ASSIGNING FIELD-SYMBOL(<fs_result>)
           WITH KEY legacy_ref      = iw_document-legacy_ref
                    legacy_ref_item = iw_document-legacy_ref_item.
      IF sy-subrc IS INITIAL.
        APPEND VALUE #( sap_fi_document      = lv_belnr
                        sap_fi_document_year = lv_gjahr
                        return_message       = ls_return-message
                        id                   = ls_return-id
                        number               = ls_return-number
                        row                  = ls_return-row )
               TO <fs_result>-t_message.
      ELSE.
        cw_result-t_result = VALUE #( BASE cw_result-t_result
                                      ( legacy_ref      = iw_document-legacy_ref
                                        legacy_ref_item = iw_document-legacy_ref_item
                                        return_code     = gc_success
*                                        sap_fi_document = lv_belnr
*                                        sap_fi_document_year = lv_gjahr
                                        t_message       = VALUE #( ( sap_fi_document      = lv_belnr
                                                                     sap_fi_document_year = lv_gjahr
                                                                     return_message       = ls_return-message
                                                                     id                   = ls_return-id
                                                                     number               = ls_return-number
                                                                     row                  = ls_return-row ) ) ) ).
      ENDIF.
    ELSE.
      ev_eflag = 'X'.

      DELETE lt_return WHERE NOT type CA 'EAX'.
      lv_lines = lines( lt_return ).
      READ TABLE lt_return INTO ls_return INDEX lv_lines.

      READ TABLE cw_result-t_result ASSIGNING <fs_result>
           WITH KEY legacy_ref      = iw_document-legacy_ref
                    legacy_ref_item = iw_document-legacy_ref_item.
      IF sy-subrc IS INITIAL.
        <fs_result>-return_code = gc_error.
        APPEND VALUE #( return_message = ls_return-message
                        id             = ls_return-id
                        number         = ls_return-number
                        row            = ls_return-row )
               TO <fs_result>-t_message.
      ELSE.
        cw_result-t_result = VALUE #( BASE cw_result-t_result
                                      ( legacy_ref      = iw_document-legacy_ref
                                        legacy_ref_item = iw_document-legacy_ref_item
                                        return_code     = gc_error
                                        t_message       = VALUE #( ( return_message = ls_return-message
                                                                     id             = ls_return-id
                                                                     number         = ls_return-number
                                                                     row            = ls_return-row ) ) ) ).
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD post_document_from_json.
    acc_document_post( EXPORTING iw_documentheader    = iw_documentheader
                                 iw_customercpd       = iw_customercpd
                                 iw_contractheader    = iw_contractheader
                                 iv_testrun           = iv_testrun
                                 iv_postdocument      = iv_postdocument
                                 iv_commit_work       = iv_commit_work
                       IMPORTING ev_obj_type          = ev_obj_type
                                 ev_obj_key           = ev_obj_key
                                 ev_obj_sys           = ev_obj_sys
                                 ev_bukrs             = ev_bukrs
                                 ev_belnr             = ev_belnr
                                 ev_gjahr             = ev_gjahr
                                 et_return            = et_return
                                 ev_error             = ev_error
                       CHANGING  ct_accountgl         = ct_accountgl
                                 ct_accountreceivable = ct_accountreceivable
                                 ct_accountpayable    = ct_accountpayable
                                 ct_accounttax        = ct_accounttax
                                 ct_currencyamount    = ct_currencyamount
                                 ct_criteria          = ct_criteria
                                 ct_valuefield        = ct_valuefield
                                 ct_extension1        = ct_extension1
                                 ct_paymentcard       = ct_paymentcard
                                 ct_contractitem      = ct_contractitem
                                 ct_extension2        = ct_extension2
                                 ct_realestate        = ct_realestate
                                 ct_accountwt         = ct_accountwt ).
  ENDMETHOD.


  METHOD post_invoice_interface.
    DATA lo_data   TYPE REF TO ty_request.
    DATA lo_ex_ref TYPE REF TO cx_root.
    DATA lw_result TYPE ty_respond.
    DATA lv_eflag  TYPE c LENGTH 1.

    TRY.
        " Getting content data from Http
        DATA(lv_cdata) = io_request->get_cdata( ).

        _replace_unwanted_characters( CHANGING cv_cdata = lv_cdata ).

        " Transform data to JSON
        /ui2/cl_json=>deserialize( EXPORTING json        = lv_cdata
                                             pretty_name = /ui2/cl_json=>pretty_mode-none
                                   CHANGING  data        = lo_data ).
      CATCH cx_root INTO lo_ex_ref.
        " Setting error message
        lv_cdata = lo_ex_ref->get_text( ).
    ENDTRY.

    " Checking data exist
    IF lo_data IS NOT BOUND.
      " Error message for parameters does not exist
      lw_result-t_result = VALUE #( ( legacy_ref  = space
                                      return_code = gc_error
*                                      sap_fi_document = space
*                                      sap_fi_document_year = space
                                      t_message   = VALUE #( ( return_message = 'Parameters not found, Please check'
                                                               id             = '38'
                                                               number         = '000'
                                                               row            = 1 ) ) ) ).
    ELSE.

      LOOP AT lo_data->t_doc INTO DATA(grp)
           GROUP BY grp-legacy_ref.

        CLEAR lv_eflag.

        " Check document
        LOOP AT GROUP grp REFERENCE INTO DATA(lref_data).
          post_document( EXPORTING iw_document = lref_data->*
                                   iv_check    = abap_true
                         IMPORTING ev_eflag    = lv_eflag
                         CHANGING  cw_result   = lw_result ).
        ENDLOOP.

        " Post Document
        IF lv_eflag IS INITIAL.
          LOOP AT lw_result-t_result ASSIGNING FIELD-SYMBOL(<fs_result>)
               WHERE legacy_ref = lref_data->legacy_ref.
            CLEAR <fs_result>-t_message[].
          ENDLOOP.

          LOOP AT GROUP grp REFERENCE INTO lref_data.
            post_document( EXPORTING iw_document = lref_data->*
                                     iv_check    = abap_false
                           IMPORTING ev_eflag    = lv_eflag
                           CHANGING  cw_result   = lw_result ).
          ENDLOOP.
        ENDIF.

      ENDLOOP.
    ENDIF.

    " Transform data to JSON with result message
    rv_out_json = /ui2/cl_json=>serialize( data        = lw_result
                                           compress    = abap_false
                                           pretty_name = /ui2/cl_json=>pretty_mode-low_case ).

    " -------------------------------------------------------------------------------------
    " JSON input example
    " {
    " T_DOC": [
    " {
    " LEGACY_REF": "test", //àÅ¢·ÕèàÍ¡ÊÒÃ Legacy Referance
    " COMP_CODE": "TH10", //ÃÐºØÃËÑÊºÃÔÉÑ·
    " PSTNG_DATE": "20240807", //ÃÐºØÇÑ¹·ÕèºÑ¹·Ö¡ÃÒÂÒ¡Ã
    " DOC_DATE": "20240807", //ÃÐºØÇÑ¹·ÕèàÍ¡ÊÒÃ
    " CURRENCY": "THB",
    " DOC_TYPE": "KR",
    " REF_DOC_NO": "INV.001",
    " HEADER_TXT": "HEADER TEXT",
    " BUSINESSPLACE": "0000",
    " T_ITEM_APAR": [
    " {
    " ACC_TYPE": "K",
    " ACCOUNT_NO": "1000010",
    " NEWUM": "",
    " AMT_DOCCUR": "-1070.00",
    " TAX_CODE": "V7",
    " PMNTTRMS": "YF30",
    " BLINE_DATE": "20220113",
    " ALLOC_NMBR": "",
    " ITEM_TEXT": "Long Text",
    " WITHT": "",
    " BAS_AMT_TC": "",
    " WT_CODE": "",
    " WT_QBSHB": "",
    " WITHT2": "",
    " BAS_AMT_TC2": "",
    " WT_CODE2": "",
    " WT_QBSHB2": "",
    " REF_KEY_1": "",
    " REF_KEY_2": "",
    " REF_KEY_3": "",
    " SP_GL_IND": "",
    " NAME": "",
    " NAME_2": "",
    " CITY": "",
    " COUNTRY": "",
    " COUNTRY_ISO": "",
    " STREET": "",
    " TAX_NO_1": "",
    " TAX_NO_2": "",
    " PYMT_METH": "",
    " NOTE_ITEM": "",
    " BVTYP": ""
    " }
    " ],
    " T_ITEM_GL": [
    " {
    " GL_ACCOUNT": "61001000",
    " AMT_DOCCUR": "1000.00",
    " TAX_CODE": "V7",
    " AMT_BASE": "",
    " ALLOC_NMBR": "",
    " ITEM_TEXT": "Long Text",
    " COSTCENTER": "BS01020100",
    " PROFIT_CTR": "",
    " ORDERID": "",
    " REF_KEY_1": "REF_KEY_1",
    " REF_KEY_2": "REF_KEY_2",
    " REF_KEY_3": "REF_KEY_3",
    " TRADE_ID": ""
    " },
    " {
    " GL_ACCOUNT": "14102000",
    " AMT_DOCCUR": "70.00",
    " TAX_CODE": "V7",
    " AMT_BASE": "1000.00",
    " ALLOC_NMBR": "",
    " ITEM_TEXT": "Long Text",
    " COSTCENTER": "",
    " PROFIT_CTR": "",
    " ORDERID": "",
    " REF_KEY_1": "REF_KEY_1",
    " REF_KEY_2": "REF_KEY_2",
    " REF_KEY_3": "REF_KEY_3",
    " TRADE_ID": ""
    " }
    " ]
    " }
    " ]
    " }
    " -------------------------------------------------------------------------------------
  ENDMETHOD.


  METHOD prepare_document_from_json.
    DATA lw_documentheader    TYPE bapiache09.
    DATA lw_customercpd       TYPE bapiacpa09.
    DATA lw_contractheader    TYPE bapiaccahd.
    DATA lt_accountgl         TYPE bapiacgl09_tab.
    DATA lt_accountreceivable TYPE bapiacar09_tab.
    DATA lt_accountpayable    TYPE bapiacap09_tab.
    DATA lt_accounttax        TYPE bapiactx09_tab.
    DATA lt_currencyamount    TYPE bapiaccr09_tab.
    DATA lt_criteria          TYPE bapiackec9_tab.
    DATA lt_valuefield        TYPE bapiackev9_tab.
    DATA lt_extension1        TYPE bapiacextc_tab.
    DATA lt_paymentcard       TYPE bapiacpc09_tab.
    DATA lt_contractitem      TYPE bapiaccait_tab.
    DATA lt_extension2        TYPE bapiparex_tab.
    DATA lt_realestate        TYPE bapiacre09_tab.
    DATA lt_accountwt         TYPE bapiacwt09_tab.

    CLEAR me->mv_itemno_acc.

    " -------------------------------------------------------------------------------------
    " Fill Document Header
    _fill_documentheader( EXPORTING iw_document       = iw_document
                          CHANGING  cw_documentheader = lw_documentheader
                                    ct_extension2     = lt_extension2 ).

    " Customer/Vendor
    LOOP AT iw_document-t_item_apar INTO DATA(lw_item_apar).
      CASE lw_item_apar-acc_type.
        WHEN gc_vendor. " Vendor
          _fill_accountpayable( EXPORTING iw_document       = iw_document
                                          iw_item_apar      = lw_item_apar
                                CHANGING  cw_customercpd    = lw_customercpd
                                          ct_accountpayable = lt_accountpayable
                                          ct_accounttax     = lt_accounttax
                                          ct_currencyamount = lt_currencyamount
                                          ct_criteria       = lt_criteria
                                          ct_valuefield     = lt_valuefield
                                          ct_extension1     = lt_extension1
                                          ct_paymentcard    = lt_paymentcard
                                          ct_contractitem   = lt_contractitem
                                          ct_extension2     = lt_extension2
                                          ct_realestate     = lt_realestate
                                          ct_accountwt      = lt_accountwt ).
        WHEN gc_customer. " Customer
          _fill_accountreceivable( EXPORTING iw_document          = iw_document
                                             iw_item_apar         = lw_item_apar
                                   CHANGING  cw_customercpd       = lw_customercpd
                                             ct_accountreceivable = lt_accountreceivable
                                             ct_accounttax        = lt_accounttax
                                             ct_currencyamount    = lt_currencyamount
                                             ct_criteria          = lt_criteria
                                             ct_valuefield        = lt_valuefield
                                             ct_extension1        = lt_extension1
                                             ct_paymentcard       = lt_paymentcard
                                             ct_contractitem      = lt_contractitem
                                             ct_extension2        = lt_extension2
                                             ct_realestate        = lt_realestate
                                             ct_accountwt         = lt_accountwt ).
      ENDCASE.
    ENDLOOP.

    " G/L accounts
    LOOP AT iw_document-t_item_gl INTO DATA(lw_item_gl).
      IF me->_check_tax_determination( iw_document = iw_document
                                       iw_item_gl  = lw_item_gl ) IS INITIAL.
        _fill_accountgl( EXPORTING iw_document       = iw_document
                                   iw_item_gl        = lw_item_gl
                         CHANGING  ct_accountgl      = lt_accountgl
                                   ct_accounttax     = lt_accounttax
                                   ct_currencyamount = lt_currencyamount
                                   ct_criteria       = lt_criteria
                                   ct_valuefield     = lt_valuefield
                                   ct_extension1     = lt_extension1
                                   ct_paymentcard    = lt_paymentcard
                                   ct_contractitem   = lt_contractitem
                                   ct_extension2     = lt_extension2
                                   ct_realestate     = lt_realestate ).
      ELSE.
        _fill_accounttax( EXPORTING iw_document       = iw_document
                                    iw_item_gl        = lw_item_gl
                          CHANGING  ct_accounttax     = lt_accounttax
                                    ct_currencyamount = lt_currencyamount ).
      ENDIF.
    ENDLOOP.

    " -------------------------------------------------------------------------------------
    ew_documentheader    = lw_documentheader.
    ew_customercpd       = lw_customercpd.
    ew_contractheader    = lw_contractheader.
    et_accountgl         = lt_accountgl.
    et_accountreceivable = lt_accountreceivable.
    et_accountpayable    = lt_accountpayable.
    et_accounttax        = lt_accounttax.
    et_currencyamount    = lt_currencyamount.
    et_criteria          = lt_criteria.
    et_valuefield        = lt_valuefield.
    et_extension1        = lt_extension1.
    et_paymentcard       = lt_paymentcard.
    et_contractitem      = lt_contractitem.
    et_extension2        = lt_extension2.
    et_realestate        = lt_realestate.
    et_accountwt         = lt_accountwt.
  ENDMETHOD.


  METHOD _replace_unwanted_characters.
    REPLACE ALL OCCURRENCES OF
          cl_abap_char_utilities=>horizontal_tab IN cv_cdata WITH ''.
    REPLACE ALL OCCURRENCES OF
          cl_abap_char_utilities=>vertical_tab   IN cv_cdata WITH ''.
    REPLACE ALL OCCURRENCES OF
          cl_abap_char_utilities=>cr_lf          IN cv_cdata WITH ''.
    REPLACE ALL OCCURRENCES OF
          cl_abap_char_utilities=>newline        IN cv_cdata WITH ''.
  ENDMETHOD.


  METHOD update_legacy_ref_from_json.
    CONSTANTS lc_xref1_hd TYPE accchg-fdname VALUE 'XREF1_HD'.
    DATA lt_accchg TYPE TABLE OF accchg.
    DATA lw_return TYPE bapiret2.

    lt_accchg = VALUE #( ( fdname = lc_xref1_hd
                           oldval = space
                           newval = iv_xref1_hd ) ).

    CALL FUNCTION 'FI_DOCUMENT_CHANGE'
      EXPORTING
        i_bukrs              = iv_bukrs
        i_belnr              = iv_belnr
        i_gjahr              = iv_gjahr
      TABLES
        t_accchg             = lt_accchg
      EXCEPTIONS
        no_reference         = 1
        no_document          = 2
        many_documents       = 3
        wrong_input          = 4
        overwrite_creditcard = 5
        OTHERS               = 6.
    IF sy-subrc <> 0.
      ROLLBACK WORK.

      ev_error = abap_true.

      CALL FUNCTION 'BALW_BAPIRETURN_GET2'
        EXPORTING
          type      = 'E'
          cl        = sy-msgid
          number    = sy-msgno
          par1      = sy-msgv1
          par2      = sy-msgv2
          par3      = sy-msgv3
          par4      = sy-msgv4
          parameter = 'BKPF'
          field     = lc_xref1_hd
        IMPORTING
          return    = lw_return.

      APPEND lw_return TO et_return.
    ELSE.
      COMMIT WORK.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
