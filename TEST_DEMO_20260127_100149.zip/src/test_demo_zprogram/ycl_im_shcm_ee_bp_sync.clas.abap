class YCL_IM_SHCM_EE_BP_SYNC definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces /SHCM/IF_B_EE_BP_SYNC .
protected section.
private section.
ENDCLASS.



CLASS YCL_IM_SHCM_EE_BP_SYNC IMPLEMENTATION.


  method /SHCM/IF_B_EE_BP_SYNC~MODIFY_ADDRESS_DATA.
  endmethod.


  METHOD /shcm/if_b_ee_bp_sync~modify_all.
    CASE cl_abap_context_info=>get_user_technical_name( ).
      WHEN 'Z0012353'
        OR 'Z0012235'.
        IF cs_bp_data-partner-central_data-common-data-bp_control-grouping = 'Z4'.
          cs_bp_data-partner-central_data-common-data-bp_control-grouping = 'ZEMP'.
        ENDIF.

        cs_bp_data-partner-central_data-common-data-bp_centraldata-partnertype  = 'Z1'.
        cs_bp_data-partner-central_data-common-datax-bp_centraldata-partnertype = abap_true.

        cs_bp_data-partner-central_data-taxnumber-common-data-nat_person = abap_true.
        cs_bp_data-partner-central_data-taxnumber-common-datax-nat_person = abap_true.

        cs_bp_data-partner-central_data-taxnumber-taxnumbers = VALUE #( ( task = 'I'
                                                                          data_key = VALUE #( taxtype   = 'TH3'
                                                                                              taxnumber = ''
                                                                                              taxnumxl  = '1888888888665' ) ) ).

**        IF cs_bp_data-vendor-company_data-company IS NOT INITIAL.
**          LOOP AT cs_bp_data-vendor-company_data-company ASSIGNING FIELD-SYMBOL(<ls_vend_company>).
**            <ls_vend_company>-data-zuawa = '014'.
**            <ls_vend_company>-data-akont = '21523010'.
**            <ls_vend_company>-data-zterm = 'P000'.
**            <ls_vend_company>-data-reprf = abap_true.
**
**            <ls_vend_company>-datax-zuawa = abap_true.
**            <ls_vend_company>-datax-akont = abap_true.
**            <ls_vend_company>-datax-zterm = abap_true.
**            <ls_vend_company>-datax-reprf = abap_true.
**          ENDLOOP.
**        ELSE.
**          cs_bp_data-ensure_create-create_vendor = abap_true.
**
**          APPEND INITIAL LINE TO cs_bp_data-partner-central_data-role-roles ASSIGNING FIELD-SYMBOL(<ls_role>).
**          <ls_role>-task = 'I'.
**          <ls_role>-data_key          = 'FLVN00'.
**          <ls_role>-data-rolecategory = 'FLVN00'.
**
**          cs_bp_data-vendor-header-object_task = 'M'.
**
**          APPEND INITIAL LINE TO cs_bp_data-vendor-company_data-company ASSIGNING <ls_vend_company>.
**          <ls_vend_company>-data-zuawa = '014'.
**          <ls_vend_company>-data-akont = '21523010'.
**          <ls_vend_company>-data-zterm = 'P000'.
**          <ls_vend_company>-data-reprf = abap_true.
**
**          <ls_vend_company>-datax-zuawa = abap_true.
**          <ls_vend_company>-datax-akont = abap_true.
**          <ls_vend_company>-datax-zterm = abap_true.
**          <ls_vend_company>-datax-reprf = abap_true.
**
**          DATA lt_fitha_pbupl_k TYPE cl_finloc_cvi_persist_data=>tt_fitha_pbupl_k.
**
**          lt_fitha_pbupl_k = VALUE #( ( j_1tpbupl      = 'NVAT'
**                                        default_branch = abap_true ) ).
**
**          cl_finloc_cvi_persist_data=>set_fitha_pbupl_k( it_fitha_pbupl_k = lt_fitha_pbupl_k ).
**
***          NEW cl_finloc_vendor_update( )->cs_update_fitha_pbupl_k( ).
***          NEW cl_finloc_vendor_update( )->cs_update_fitha_pbupl_k_t( ).
**        ENDIF.
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.


  method /SHCM/IF_B_EE_BP_SYNC~MODIFY_BANK_DATA.
  endmethod.


  method /SHCM/IF_B_EE_BP_SYNC~MODIFY_COMMUNICATION_DATA.
  endmethod.


  method /SHCM/IF_B_EE_BP_SYNC~MODIFY_GROUPING_NUMBER.
  endmethod.


  method /SHCM/IF_B_EE_BP_SYNC~MODIFY_IDENTIFICATION_NUMBER.
  endmethod.


  method /SHCM/IF_B_EE_BP_SYNC~MODIFY_LIST_OF_PERNRS_TO_SYNC.
  endmethod.


  METHOD /shcm/if_b_ee_bp_sync~modify_person_central_data.
  ENDMETHOD.
ENDCLASS.
