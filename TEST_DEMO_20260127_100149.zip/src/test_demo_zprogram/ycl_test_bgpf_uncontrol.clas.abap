CLASS ycl_test_bgpf_uncontrol DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_serializable_object .
    INTERFACES if_bgmc_operation .
    INTERFACES if_bgmc_op_single_tx_uncontr .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_test_bgpf_uncontrol IMPLEMENTATION.


  METHOD if_bgmc_op_single_tx_uncontr~execute.
  ENDMETHOD.
ENDCLASS.
