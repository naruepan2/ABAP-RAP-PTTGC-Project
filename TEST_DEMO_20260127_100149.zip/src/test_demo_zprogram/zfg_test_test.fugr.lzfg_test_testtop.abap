FUNCTION-POOL ZFG_TEST_TEST.                "MESSAGE-ID ..

* INCLUDE LZFG_TEST_TESTD...                 " Local class definition
