*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TEST_TESTTOP.                 " Global Declarations
  INCLUDE LZFG_TEST_TESTUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TEST_TESTF...                 " Subroutines
* INCLUDE LZFG_TEST_TESTO...                 " PBO-Modules
* INCLUDE LZFG_TEST_TESTI...                 " PAI-Modules
* INCLUDE LZFG_TEST_TESTE...                 " Events
* INCLUDE LZFG_TEST_TESTP...                 " Local class implement.
* INCLUDE LZFG_TEST_TESTT99.                 " ABAP Unit tests
