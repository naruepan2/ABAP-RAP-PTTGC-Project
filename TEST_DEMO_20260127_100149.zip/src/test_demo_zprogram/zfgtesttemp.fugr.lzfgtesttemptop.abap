FUNCTION-POOL ZFGTESTTEMP.                  "MESSAGE-ID ..

* INCLUDE LZFGTESTTEMPD...                   " Local class definition
