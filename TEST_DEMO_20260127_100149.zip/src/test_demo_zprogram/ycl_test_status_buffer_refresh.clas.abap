CLASS ycl_test_status_buffer_refresh DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    CLASS-METHODS status_delete_from_buffer.
    CLASS-METHODS bapi_insplot_setusagedecision.
ENDCLASS.


CLASS ycl_test_status_buffer_refresh IMPLEMENTATION.
  METHOD status_delete_from_buffer.
    CALL FUNCTION 'STATUS_DELETE_FROM_BUFFER'
      EXPORTING
*       client = SY-MANDT
        objnr = 'QL040000000121'.
*       objnr_generic =
*      TABLES
*       objnr_tab     =
  ENDMETHOD.

  METHOD bapi_insplot_setusagedecision.
    DATA ud_data TYPE bapi2045ud.
    DATA ud_return_data  TYPE bapi2045ud_return.
    DATA stock_data      TYPE bapi2045d_il2.
    DATA return          TYPE bapireturn1.
    DATA /cwm/stock_data TYPE /cwm/bapi2045d_il2.
    DATA lv_skip TYPE abap_bool.

    CHECK lv_skip is INITIAL.

    ud_data-insplot = '40000000127'.
    ud_data-ud_selected_set = 'UD-FINAL'.
    ud_data-ud_plant = '1052'.
    ud_data-ud_code_group = 'UD-FINAL'.
    ud_data-ud_code = 'ACC'.

    CALL FUNCTION 'BAPI_INSPLOT_SETUSAGEDECISION' DESTINATION space
      EXPORTING
        number          = ud_data-insplot
        ud_data         = ud_data
*       language        =
*       ud_multspec     =
*       ud_mode         = 'D'
      IMPORTING
        ud_return_data  = ud_return_data
        stock_data      = stock_data
        return          = return
        /cwm/stock_data = /cwm/stock_data.
*      TABLES
*       system_status   =
*       user_status     =
  ENDMETHOD.
ENDCLASS.
