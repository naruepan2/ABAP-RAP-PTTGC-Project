CLASS ycl_test_update_ud DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_oo_adt_classrun .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_test_update_ud IMPLEMENTATION.


  METHOD if_oo_adt_classrun~main.

    MODIFY ENTITY I_InspectionLotTP_2
     EXECUTE RecordUsageDecision
     FROM VALUE #(
              ( %key-inspectionlot = '40000000326'
                %param-selectedcodesetplant = '1041'
                %param-%control-selectedcodesetplant = if_abap_behv=>mk-on
                %param-insplotusgedcsnselectedset = 'UD-FINAL'
                %param-%control-insplotusgedcsnselectedset = if_abap_behv=>mk-on
                %param-insplotusagedecisioncodegroup = 'UD-FINAL'
                %param-%control-insplotusagedecisioncodegroup = if_abap_behv=>mk-on
                %param-inspectionlotusagedecisioncode = 'ACO'
                %param-%control-inspectionlotusagedecisioncode = if_abap_behv=>mk-on  )
              )
*             (  %key-inspectionlot = '40000000121'
*                %data-selectedcodesetplant = '1052'
*                %control-selectedcodesetplant = if_abap_behv=>mk-on
*                %data-insplotusgedcsnselectedset = 'UD-FINAL'
*                %control-insplotusgedcsnselectedset = if_abap_behv=>mk-on
*                %data-insplotusagedecisioncodegroup = 'UD-FINAL'
*                %control-insplotusagedecisioncodegroup = if_abap_behv=>mk-on
*                %data-inspectionlotusagedecisioncode = 'ACC'
*                %control-inspectionlotusagedecisioncode = if_abap_behv=>mk-on )
*                )
     FAILED   DATA(failed)
     REPORTED DATA(reported).

    "Responses are retrieved per root entity.
    COMMIT ENTITIES
      RESPONSE OF I_InspectionLotTP_2
        FAILED   FINAL(failed1a)
        REPORTED FINAL(reported1a).

  ENDMETHOD.
ENDCLASS.
