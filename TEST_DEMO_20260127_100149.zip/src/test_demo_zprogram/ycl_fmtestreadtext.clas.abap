CLASS ycl_fmtestreadtext DEFINITION
  PUBLIC
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_aco_proxy .

    TYPES:
      syst_tabix                     TYPE int4 ##TYPSHADOW .
    TYPES:
      syst_mandt                     TYPE c LENGTH 000003 ##TYPSHADOW .
    TYPES:
      tdid                           TYPE c LENGTH 000004 ##TYPSHADOW .
    TYPES:
      spras                          TYPE c LENGTH 000001 ##TYPSHADOW .
    TYPES:
      tdformat TYPE c LENGTH 000002 ##TYPSHADOW .
    TYPES:
      tdline TYPE c LENGTH 000132 ##TYPSHADOW .
    TYPES:
      BEGIN OF tline                         ,
        tdformat TYPE tdformat,
        tdline   TYPE tdline,
      END OF tline                          ##TYPSHADOW .
    TYPES:
      tline_t                        TYPE STANDARD TABLE OF tline                          WITH DEFAULT KEY ##TYPSHADOW .
    TYPES:
      tdobname                       TYPE c LENGTH 000070 ##TYPSHADOW .
    TYPES:
      tdobject                       TYPE c LENGTH 000010 ##TYPSHADOW .
    TYPES:
      abap_boolean                   TYPE c LENGTH 000001 ##TYPSHADOW .
    TYPES:
      tdtitle TYPE c LENGTH 000050 ##TYPSHADOW .
    TYPES:
      tdform TYPE c LENGTH 000016 ##TYPSHADOW .
    TYPES:
      tdstyle TYPE c LENGTH 000008 ##TYPSHADOW .
    TYPES:
      tdversion TYPE n LENGTH 000005 ##TYPSHADOW .
    TYPES:
      tdfuser TYPE c LENGTH 000012 ##TYPSHADOW .
    TYPES:
      tdfreles TYPE c LENGTH 000004 ##TYPSHADOW .
    TYPES:
      tdfdate TYPE d ##TYPSHADOW .
    TYPES:
      tdftime TYPE t ##TYPSHADOW .
    TYPES:
      tdluser TYPE c LENGTH 000012 ##TYPSHADOW .
    TYPES:
      tdlreles TYPE c LENGTH 000004 ##TYPSHADOW .
    TYPES:
      tdldate TYPE d ##TYPSHADOW .
    TYPES:
      tdltime TYPE t ##TYPSHADOW .
    TYPES:
      tdlinesize TYPE n LENGTH 000003 ##TYPSHADOW .
    TYPES:
      tdtxtlines                     TYPE n LENGTH 000005 ##TYPSHADOW .
    TYPES:
      tdhyphenat TYPE c LENGTH 000001 ##TYPSHADOW .
    TYPES:
      tdospras TYPE c LENGTH 000001 ##TYPSHADOW .
    TYPES:
      tdtranstat TYPE n LENGTH 000001 ##TYPSHADOW .
    TYPES:
      tdmacode1 TYPE c LENGTH 000016 ##TYPSHADOW .
    TYPES:
      tdmacode2 TYPE c LENGTH 000016 ##TYPSHADOW .
    TYPES:
      tdrefobj TYPE c LENGTH 000010 ##TYPSHADOW .
    TYPES:
      tdrefname TYPE c LENGTH 000070 ##TYPSHADOW .
    TYPES:
      tdrefid TYPE c LENGTH 000004 ##TYPSHADOW .
    TYPES:
      tdtexttype TYPE c LENGTH 000006 ##TYPSHADOW .
    TYPES:
      tdcompress TYPE c LENGTH 000001 ##TYPSHADOW .
    TYPES:
      mandt TYPE c LENGTH 000003 ##TYPSHADOW .
    TYPES:
      tdoclass TYPE c LENGTH 000004 ##TYPSHADOW .
    TYPES:
      logsys TYPE c LENGTH 000010 ##TYPSHADOW .
    TYPES:
      BEGIN OF thead                         ,
        tdobject   TYPE tdobject,
        tdname     TYPE tdobname,
        tdid       TYPE tdid,
        tdspras    TYPE spras,
        tdtitle    TYPE tdtitle,
        tdform     TYPE tdform,
        tdstyle    TYPE tdstyle,
        tdversion  TYPE tdversion,
        tdfuser    TYPE tdfuser,
        tdfreles   TYPE tdfreles,
        tdfdate    TYPE tdfdate,
        tdftime    TYPE tdftime,
        tdluser    TYPE tdluser,
        tdlreles   TYPE tdlreles,
        tdldate    TYPE tdldate,
        tdltime    TYPE tdltime,
        tdlinesize TYPE tdlinesize,
        tdtxtlines TYPE tdtxtlines,
        tdhyphenat TYPE tdhyphenat,
        tdospras   TYPE tdospras,
        tdtranstat TYPE tdtranstat,
        tdmacode1  TYPE tdmacode1,
        tdmacode2  TYPE tdmacode2,
        tdrefobj   TYPE tdrefobj,
        tdrefname  TYPE tdrefname,
        tdrefid    TYPE tdrefid,
        tdtexttype TYPE tdtexttype,
        tdcompress TYPE tdcompress,
        mandt      TYPE mandt,
        tdoclass   TYPE tdoclass,
        logsys     TYPE logsys,
      END OF thead                          ##TYPSHADOW .

    METHODS constructor
      IMPORTING
        !destination TYPE rfcdest .
    METHODS zfmtestreadtext
      IMPORTING
        !archive_handle      TYPE syst_tabix DEFAULT '0'
        !client              TYPE syst_mandt DEFAULT sy-mandt
        !id                  TYPE tdid
        !language            TYPE spras
        !lines               TYPE tline_t
        !name                TYPE tdobname
        !object              TYPE tdobject
        !use_old_persistence TYPE abap_boolean DEFAULT abap_false
      EXPORTING
        !header              TYPE thead
        !old_line_counter    TYPE tdtxtlines
        !_rfc_message_       TYPE aco_proxy_msg_type
      EXCEPTIONS
        rfc_communication_failure
        rfc_system_failure
        rfc_others .
  PROTECTED SECTION.

    DATA destination TYPE rfcdest .
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_fmtestreadtext IMPLEMENTATION.


  METHOD constructor.
    me->destination = destination.
  ENDMETHOD.


  METHOD zfmtestreadtext.
    CALL FUNCTION 'ZFMTESTREADTEXT' DESTINATION me->destination
      EXPORTING
        archive_handle        = archive_handle
        client                = client
        id                    = id
        language              = language
        lines                 = lines
        name                  = name
        object                = object
        use_old_persistence   = use_old_persistence
      IMPORTING
        header                = header
        old_line_counter      = old_line_counter
      EXCEPTIONS
        communication_failure = 1 MESSAGE _rfc_message_
        system_failure        = 2 MESSAGE _rfc_message_
        OTHERS                = 3.
    IF sy-subrc NE 0.
      CASE sy-subrc.
        WHEN 1 .
          RAISE rfc_communication_failure.
        WHEN 2 .
          RAISE rfc_system_failure.
        WHEN 3 .
          RAISE rfc_others.
      ENDCASE.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
