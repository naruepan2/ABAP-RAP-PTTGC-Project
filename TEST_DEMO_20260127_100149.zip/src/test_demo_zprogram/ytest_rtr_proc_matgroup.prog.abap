*&---------------------------------------------------------------------*
*& Report ytest_rtr_proc_matgroup
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ytest_rtr_proc_matgroup.

START-OF-SELECTION.

*    MODIFY ENTITIES OF ZZ1_PTP_PROC_MATERIALGRP
*    ENTITY

  DATA lt_test TYPE TABLE OF zz1_722a2d429316.

  lt_test = VALUE #( ( sap_uuid = cl_system_uuid=>create_uuid_x16_static( )
                       grouping = 'ZZ'
                       material = 'RM00.40010.9'
                       validatestart = cl_abap_context_info=>get_system_date( )
                       validateend = cl_abap_context_info=>get_system_date( ) ) ).

  MODIFY zz1_722a2d429316 FROM TABLE @lt_test.
  COMMIT WORK.

  WRITE 'Done'.
