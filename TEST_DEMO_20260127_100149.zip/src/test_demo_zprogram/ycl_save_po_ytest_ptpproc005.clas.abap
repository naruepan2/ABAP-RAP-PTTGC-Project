CLASS ycl_save_po_ytest_ptpproc005 DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    CLASS-METHODS save_po_ytest_ptpproc005
      IMPORTING iv_ebeln   TYPE ytest_ptpproc005-ebeln
                iv_context TYPE string.
ENDCLASS.


CLASS ycl_save_po_ytest_ptpproc005 IMPLEMENTATION.
  METHOD save_po_ytest_ptpproc005.
    DATA lv_context_binary TYPE xstring.

    /ui2/cl_json=>string_to_xstring( EXPORTING in  = iv_context
                                     CHANGING  out = lv_context_binary ).

    MODIFY ytest_ptpproc005 FROM @( VALUE #( ebeln    = iv_ebeln
                                             context  = iv_context
                                             xcontext = lv_context_binary ) ).
  ENDMETHOD.
ENDCLASS.
