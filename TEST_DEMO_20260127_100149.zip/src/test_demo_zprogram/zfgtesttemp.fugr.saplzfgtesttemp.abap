*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFGTESTTEMPTOP.                   " Global Declarations
  INCLUDE LZFGTESTTEMPUXX.                   " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFGTESTTEMPF...                   " Subroutines
* INCLUDE LZFGTESTTEMPO...                   " PBO-Modules
* INCLUDE LZFGTESTTEMPI...                   " PAI-Modules
* INCLUDE LZFGTESTTEMPE...                   " Events
* INCLUDE LZFGTESTTEMPP...                   " Local class implement.
* INCLUDE LZFGTESTTEMPT99.                   " ABAP Unit tests
