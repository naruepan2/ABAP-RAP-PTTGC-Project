CLASS ycl_gui_download DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    CLASS-METHODS gui_frontend_services
      IMPORTING iv_json TYPE string.

  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_gui_download IMPLEMENTATION.
  METHOD gui_frontend_services.
    DATA lt_data_tab TYPE TABLE OF string.

    lt_data_tab = VALUE #( ( iv_json ) ).

    CALL METHOD cl_gui_frontend_services=>gui_download
      EXPORTING
        filename                = 'C:\ZZZZZZ\XXXXXXXXXXXXXXXX.txt'
        filetype                = 'ASC'
        codepage                = '4110'
        show_transfer_status    = space
      CHANGING
        data_tab                = lt_data_tab
      EXCEPTIONS
        file_write_error        = 1
        no_batch                = 2
        gui_refuse_filetransfer = 3
        invalid_type            = 4
        no_authority            = 5
        unknown_error           = 6
        header_not_allowed      = 7
        separator_not_allowed   = 8
        filesize_not_allowed    = 9
        header_too_long         = 10
        dp_error_create         = 11
        dp_error_send           = 12
        dp_error_write          = 13
        unknown_dp_error        = 14
        access_denied           = 15
        dp_out_of_memory        = 16
        disk_full               = 17
        dp_timeout              = 18
        file_not_found          = 19
        dataprovider_exception  = 20
        control_flush_error     = 21
        not_supported_by_gui    = 22
        error_no_gui            = 23
        OTHERS                  = 24.
    IF sy-subrc <> 0.
*     MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*       WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
    ENDIF.
  ENDMETHOD.

ENDCLASS.
