*&---------------------------------------------------------------------*
*& Report y_ptpproc005_json
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT y_ptpproc005_json.

PARAMETERS pa_ebeln TYPE ytest_ptpproc005-ebeln OBLIGATORY.

INITIALIZATION.

  GET PARAMETER ID 'BES' FIELD pa_ebeln.

START-OF-SELECTION.
  SELECT SINGLE FROM ytest_ptpproc005
    FIELDS *
    WHERE ebeln = @pa_ebeln
    INTO @DATA(ls_ytest_ptpproc005).

  /ui2/cl_json=>raw_to_string(
    EXPORTING
      iv_xstring  = ls_ytest_ptpproc005-xcontext
*      iv_encoding =
    RECEIVING
      rv_string   = DATA(lv_json_data)
  ).

  cl_demo_output=>display_json( json = ls_ytest_ptpproc005-context ).
