@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Business Partner - Address'
@ObjectModel.usageType:{
    serviceQuality: #C,
    sizeCategory: #XXL,
    dataClass: #MASTER
}
define view entity YYI_BUSINESSPARTADDRESS_2
  as select from I_BusinessPartner as I_businesspartner
    inner join   I_BusinessPartAddress_2 on I_businesspartner.BusinessPartner = I_BusinessPartAddress_2.BusinessPartner
{
  key I_BusinessPartAddress_2.BusinessPartner,
  key I_BusinessPartAddress_2.AddressNumber,
      concat( concat( I_businesspartner.OrganizationBPName1 , ' ' ) , I_businesspartner.OrganizationBPName2) as BusinessPartnerFullName,
      I_BusinessPartAddress_2.CorrespondenceLanguage,
      I_BusinessPartAddress_2.StreetName,
      I_BusinessPartAddress_2.StreetPrefixName,
      I_BusinessPartAddress_2.AdditionalStreetPrefixName,
      I_BusinessPartAddress_2.District,
      I_BusinessPartAddress_2.CityName,
      I_BusinessPartAddress_2.Country,
      I_BusinessPartAddress_2.PostalCode,
      I_BusinessPartAddress_2.TransportZone

      /* Associations */
      //    _Address,
      //    _BPProtectedAddress,
      //    _BusinessPartner
}
where I_businesspartner.BusinessPartnerGrouping = 'ZFOR'
