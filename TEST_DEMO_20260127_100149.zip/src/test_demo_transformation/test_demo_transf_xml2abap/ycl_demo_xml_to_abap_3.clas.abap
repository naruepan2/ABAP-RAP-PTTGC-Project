CLASS ycl_demo_xml_to_abap_3 DEFINITION
  PUBLIC
  INHERITING FROM cl_xco_cp_adt_simple_classrun FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    DATA mv_xml TYPE string.

    METHODS constructor.

  PROTECTED SECTION.
    METHODS main REDEFINITION.

    METHODS xml_to_internaltable_1
      IMPORTING !out TYPE REF TO if_xco_adt_classrun_out.

    METHODS xml_to_internaltable_2
      IMPORTING !out TYPE REF TO if_xco_adt_classrun_out.

  PRIVATE SECTION.
ENDCLASS.


CLASS ycl_demo_xml_to_abap_3 IMPLEMENTATION.
  METHOD main.
    xml_to_internaltable_1( out = out ).
    xml_to_internaltable_2( out = out ).
  ENDMETHOD.

  METHOD constructor.
    super->constructor( ).

    mv_xml = |<?xml version="1.0" encoding="UTF-8"?>| &&
               |<gesmes:Envelope xmlns:gesmes="http://www.gesmes.org/xml/2002-08-01" | &&
               |xmlns="http://www.ecb.int/vocabulary/2002-08-01/eurofxref">| &&
               |  <gesmes:subject>Reference rates</gesmes:subject>| &&
               |  <gesmes:Sender>| &&
               |    <gesmes:name>European Central Bank</gesmes:name>| &&
               |  </gesmes:Sender>| &&
               |  <Cube>| &&
               |    <Cube time="2025-08-29">| &&
               |      <Cube currency="USD" rate="1.1658"/>| &&
               |      <Cube currency="JPY" rate="171.72"/>| &&
               |      <Cube currency="BGN" rate="1.9558"/>| &&
               |      <Cube currency="CZK" rate="24.458"/>| &&
               |      <Cube currency="DKK" rate="7.4642"/>| &&
               |      <Cube currency="GBP" rate="0.8668"/>| &&
               |      <Cube currency="HUF" rate="396.9"/>| &&
               |      <Cube currency="PLN" rate="4.2665"/>| &&
               |      <Cube currency="RON" rate="5.0728"/>| &&
               |      <Cube currency="SEK" rate="11.055"/>| &&
               |      <Cube currency="CHF" rate="0.9364"/>| &&
               |      <Cube currency="ISK" rate="143"/>| &&
               |      <Cube currency="NOK" rate="11.7465"/>| &&
               |      <Cube currency="TRY" rate="47.9536"/>| &&
               |      <Cube currency="AUD" rate="1.7865"/>| &&
               |      <Cube currency="BRL" rate="6.3253"/>| &&
               |      <Cube currency="CAD" rate="1.6031"/>| &&
               |      <Cube currency="CNY" rate="8.3155"/>| &&
               |      <Cube currency="HKD" rate="9.0877"/>| &&
               |      <Cube currency="IDR" rate="19207.37"/>| &&
               |      <Cube currency="ILS" rate="3.8953"/>| &&
               |      <Cube currency="INR" rate="102.8035"/>| &&
               |      <Cube currency="KRW" rate="1622.26"/>| &&
               |      <Cube currency="MXN" rate="21.7935"/>| &&
               |      <Cube currency="MYR" rate="4.9255"/>| &&
               |      <Cube currency="NZD" rate="1.9811"/>| &&
               |      <Cube currency="PHP" rate="66.687"/>| &&
               |      <Cube currency="SGD" rate="1.4987"/>| &&
               |      <Cube currency="THB" rate="37.76"/>| &&
               |      <Cube currency="ZAR" rate="20.6758"/>| &&
               |    </Cube>| &&
               |    <Cube time="2025-08-28">| &&
               |      <Cube currency="USD" rate="1.1658"/>| &&
               |      <Cube currency="JPY" rate="171.72"/>| &&
               |      <Cube currency="BGN" rate="1.9558"/>| &&
               |      <Cube currency="CZK" rate="24.458"/>| &&
               |      <Cube currency="DKK" rate="7.4642"/>| &&
               |      <Cube currency="GBP" rate="0.8668"/>| &&
               |      <Cube currency="HUF" rate="396.9"/>| &&
               |      <Cube currency="PLN" rate="4.2665"/>| &&
               |      <Cube currency="RON" rate="5.0728"/>| &&
               |      <Cube currency="SEK" rate="11.055"/>| &&
               |      <Cube currency="CHF" rate="0.9364"/>| &&
               |      <Cube currency="ISK" rate="143"/>| &&
               |      <Cube currency="NOK" rate="11.7465"/>| &&
               |      <Cube currency="TRY" rate="47.9536"/>| &&
               |      <Cube currency="AUD" rate="1.7865"/>| &&
               |      <Cube currency="BRL" rate="6.3253"/>| &&
               |      <Cube currency="CAD" rate="1.6031"/>| &&
               |      <Cube currency="CNY" rate="8.3155"/>| &&
               |      <Cube currency="HKD" rate="9.0877"/>| &&
               |      <Cube currency="IDR" rate="19207.37"/>| &&
               |      <Cube currency="ILS" rate="3.8953"/>| &&
               |      <Cube currency="INR" rate="102.8035"/>| &&
               |      <Cube currency="KRW" rate="1622.26"/>| &&
               |      <Cube currency="MXN" rate="21.7935"/>| &&
               |      <Cube currency="MYR" rate="4.9255"/>| &&
               |      <Cube currency="NZD" rate="1.9811"/>| &&
               |      <Cube currency="PHP" rate="66.687"/>| &&
               |      <Cube currency="SGD" rate="1.4987"/>| &&
               |      <Cube currency="THB" rate="37.76"/>| &&
               |      <Cube currency="ZAR" rate="20.6758"/>| &&
               |    </Cube>| &&
               |  </Cube>| &&
               |</gesmes:Envelope>|.
  ENDMETHOD.

  METHOD xml_to_internaltable_1.
    TYPES: BEGIN OF ty_rate,
             time     TYPE d,          " 20250829
             currency TYPE c LENGTH 3, " USD
             rate     TYPE decfloat16, " 1.1658
           END OF ty_rate.
    TYPES tt_rate TYPE STANDARD TABLE OF ty_rate WITH EMPTY KEY.

    DATA lt_rates   TYPE tt_rate.
    DATA lv_xstring TYPE xstring.

    " Prefer canonical string->xstring conversion
    lv_xstring = /ui2/cl_json=>string_to_raw( iv_string = mv_xml ).

    "--- Parse XML into DOM -------------------------------------------------------
    DATA(ixml)           = cl_ixml_core=>create( ).
    DATA(stream_factory) = ixml->create_stream_factory( ).
    DATA(istream)        = stream_factory->create_istream_xstring( lv_xstring ).
    DATA(document)       = ixml->create_document( ).
    DATA(parser)         = ixml->create_parser( istream        = istream
                                                document       = document
                                                stream_factory = stream_factory ).

    DATA rc TYPE i.
    rc = parser->parse( ).
    IF rc <> 0.
      " TODO: variable is assigned but never used (ABAP cleaner)
      DATA(err_cnt) = parser->num_errors( ).
      " TODO: variable is assigned but never used (ABAP cleaner)
      DATA(err)     = parser->get_error( index = 1 ).
      " TODO: Log details if needed:
      " err->get_line( ), err->get_column( ), err->get_reason( ), err->get_text( ).
      " RAISE EXCEPTION TYPE cx_sy_xml_error ... (optional)
    ENDIF.

    "--- Constants for namespaces -------------------------------------------------
    CONSTANTS c_ns_ecb TYPE string VALUE 'http://www.ecb.int/vocabulary/2002-08-01/eurofxref'.

    "--- Find the <Cube> container in ECB namespace -------------------------------
    DATA(root) = document->get_root_element( ). " <gesmes:Envelope>
    DATA cube_container TYPE REF TO if_ixml_element.
    DATA node           TYPE REF TO if_ixml_node.

    node = root->get_first_child( ).
    WHILE node IS BOUND AND cube_container IS INITIAL.
      IF node->get_type( ) = if_ixml_node=>co_node_element.
        DATA(el) = CAST if_ixml_element( node ).
        IF el->get_name( ) = 'Cube' AND el->get_namespace_uri( ) = c_ns_ecb.
          cube_container = el. " <Cube> root for date-level children
        ENDIF.
      ENDIF.
      node = node->get_next( ).
    ENDWHILE.

    IF cube_container IS INITIAL.
      " Optional: RAISE or RETURN since feed shape is unexpected
    ENDIF.

    "--- Iterate <Cube time="YYYY-MM-DD"> ----------------------------------------
    DATA date_node TYPE REF TO if_ixml_node.
    date_node = cube_container->get_first_child( ).

    WHILE date_node IS BOUND.
      IF date_node->get_type( ) = if_ixml_node=>co_node_element.
        DATA(el_date) = CAST if_ixml_element( date_node ).
        IF el_date->get_name( ) = 'Cube' AND el_date->get_namespace_uri( ) = c_ns_ecb.
          DATA(attr_time) = el_date->get_attribute_node( name = 'time' ).
          IF attr_time IS BOUND.
            DATA(time_raw) = attr_time->get_value( ). " '2025-08-29'
            DATA(time_d)   = time_raw.
            REPLACE ALL OCCURRENCES OF '-' IN time_d WITH ''.
            DATA(dats_time) = CONV d( time_d ).

            " Iterate nested <Cube currency="XXX" rate="n.nn"/>
            DATA cur_node TYPE REF TO if_ixml_node.
            cur_node = el_date->get_first_child( ).
            WHILE cur_node IS BOUND.
              IF cur_node->get_type( ) = if_ixml_node=>co_node_element.
                DATA(el_cur) = CAST if_ixml_element( cur_node ).
                IF el_cur->get_name( ) = 'Cube' AND el_cur->get_namespace_uri( ) = c_ns_ecb.
                  DATA(attr_cur)  = el_cur->get_attribute_node( name = 'currency' ).
                  DATA(attr_rate) = el_cur->get_attribute_node( name = 'rate' ).
                  IF attr_cur IS BOUND AND attr_rate IS BOUND.
                    APPEND VALUE ty_rate( time     = dats_time
                                          currency = to_upper( attr_cur->get_value( ) )
                                          rate     = CONV decfloat16( attr_rate->get_value( ) ) )
                           TO lt_rates.
                  ENDIF.
                ENDIF.
              ENDIF.
              cur_node = cur_node->get_next( ).
            ENDWHILE.
          ENDIF.
        ENDIF.
      ENDIF.
      date_node = date_node->get_next( ).
    ENDWHILE.

    " Output / return
    out->write( lt_rates ).
  ENDMETHOD.

  METHOD xml_to_internaltable_2.
    TYPES: BEGIN OF ty_rate,
             time     TYPE d,
             currency TYPE c LENGTH 5,
             rate     TYPE decfloat16,
           END OF ty_rate.
    TYPES tt_rate TYPE STANDARD TABLE OF ty_rate WITH EMPTY KEY.

    DATA lt_rates     TYPE tt_rate.
    DATA lv_xstring   TYPE xstring.
    DATA current_time TYPE d.

    " String -> xstring (UTF-8)
    lv_xstring = /ui2/cl_json=>string_to_raw( iv_string = mv_xml ).

    " Streaming reader
    DATA(reader) = cl_sxml_string_reader=>create( input = lv_xstring ).
    DATA event TYPE REF TO if_sxml_node.

    CONSTANTS c_ns_ecb TYPE string VALUE 'http://www.ecb.int/vocabulary/2002-08-01/eurofxref'.

    WHILE reader->read_next_node( ).
      event = reader->read_current_node( ).

      CASE event->type.
        WHEN if_sxml_node=>co_nt_element_open.
          DATA(el) = CAST if_sxml_open_element( event ).

          " Only care about ECB <Cube> nodes
          IF el->qname-name = 'Cube' AND el->qname-namespace = c_ns_ecb.

            DATA attr_tab TYPE if_sxml_attribute=>attributes.
            attr_tab = el->get_attributes( ).

            DATA(lv_time)     = ``.
            DATA(lv_currency) = ``.
            DATA(lv_rate)     = ``.

            LOOP AT attr_tab INTO DATA(a).
              CASE a->qname-name.
                WHEN 'time'. lv_time = a->get_value( ).
                WHEN 'currency'. lv_currency = a->get_value( ).
                WHEN 'rate'. lv_rate = a->get_value( ).
              ENDCASE.
            ENDLOOP.

            IF lv_time IS NOT INITIAL.
              " Date-level Cube
              DATA(tmp) = lv_time.
              REPLACE ALL OCCURRENCES OF '-' IN tmp WITH ''.
              REPLACE ALL OCCURRENCES OF '/' IN tmp WITH ''.
              REPLACE ALL OCCURRENCES OF '.' IN tmp WITH ''.
              current_time = CONV d( tmp ).

            ELSEIF lv_currency IS NOT INITIAL AND lv_rate IS NOT INITIAL.
              " Currency entry under current date
              APPEND VALUE ty_rate( time     = current_time
                                    currency = to_upper( lv_currency )
                                    rate     = CONV decfloat34( lv_rate ) )
                     TO lt_rates.
            ENDIF.

          ENDIF.

        WHEN OTHERS.
          " ignore text, close tags, etc.
      ENDCASE.
    ENDWHILE.

    out->write( lt_rates ).
  ENDMETHOD.
ENDCLASS.
