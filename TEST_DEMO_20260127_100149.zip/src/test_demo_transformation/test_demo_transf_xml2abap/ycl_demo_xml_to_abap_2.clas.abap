CLASS ycl_demo_xml_to_abap_2 DEFINITION
  PUBLIC
  INHERITING FROM cl_xco_cp_adt_simple_classrun FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    TYPES:
      BEGIN OF ty_root,
        v1 TYPE string,
        n1 TYPE p LENGTH 12 DECIMALS 2,
      END OF ty_root,
      tt_root TYPE STANDARD TABLE OF ty_root WITH EMPTY KEY.

  PROTECTED SECTION.
    METHODS main REDEFINITION.

  PRIVATE SECTION.
ENDCLASS.


CLASS ycl_demo_xml_to_abap_2 IMPLEMENTATION.
  METHOD main.
    "   TYPES: BEGIN OF s_person,
    "            name  TYPE string,
    "            title TYPE string,
    "            age   TYPE i,
    "          END OF s_person.
    "
    "   TYPES: t_person TYPE STANDARD TABLE OF s_person WITH DEFAULT KEY.
    "
    "   DATA(xml) = |<?xml version="1.0" encoding="UTF-8"?>| &&
    "               |<asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0">| &&
    "               |  <asx:values>| &&
    "               |    <VALUES>| &&
    "               |      <item>| &&
    "               |        <NAME>Horst</NAME>| &&
    "               |        <TITLE>Herr</TITLE>| &&
    "               |        <AGE>30</AGE>| &&
    "               |      </item>| &&
    "               |      <item>| &&
    "               |        <NAME>Jutta</NAME>| &&
    "               |        <TITLE>Frau</TITLE>| &&
    "               |        <AGE>35</AGE>| &&
    "               |      </item>| &&
    "               |      <item>| &&
    "               |        <NAME>Ingo</NAME>| &&
    "               |        <TITLE>Herr</TITLE>| &&
    "               |        <AGE>31</AGE>| &&
    "               |      </item>| &&
    "               |    </VALUES>| &&
    "               |  </asx:values>| &&
    "               |</asx:abap>|.
    "
    " XML -> ABAP (itab)
    "   DATA(it_persons) = VALUE t_person( ).
    "
    "   CALL TRANSFORMATION id SOURCE XML xml RESULT values = it_persons.
    "   out->write( it_persons ).


    "--- target types
    TYPES: BEGIN OF ty_rate,
             date     TYPE string,        " e.g. '2025-08-29'; convert to DATS if needed
             currency TYPE c LENGTH 3,
             rate     TYPE decfloat34,    " robust for rates like 19207.37
           END OF ty_rate.
    TYPES tt_rate TYPE STANDARD TABLE OF ty_rate WITH EMPTY KEY.

    DATA lt_rates TYPE tt_rate.

    "--- your XML (shortened here; paste the full string from your message)
    DATA(lv_xml) = '<?xml version="1.0" encoding="UTF-8"?>' &&
                    '<gesmes:Envelope xmlns:gesmes="http://www.gesmes.org/xml/2002-08-01" ' &&
                    'xmlns="http://www.ecb.int/vocabulary/2002-08-01/eurofxref">' &&
                    '  <gesmes:subject>Reference rates</gesmes:subject>' &&
                    '  <gesmes:Sender>' &&
                    '    <gesmes:name>European Central Bank</gesmes:name>' &&
                    '  </gesmes:Sender>' &&
                    '  <Cube>' &&
                    '    <Cube time="2025-08-29">' &&
                    '      <Cube currency="USD" rate="1.1658"/>' &&
                    '      <Cube currency="JPY" rate="171.72"/>' &&
                    '      <Cube currency="BGN" rate="1.9558"/>' &&
                    '      <Cube currency="CZK" rate="24.458"/>' &&
                    '      <Cube currency="DKK" rate="7.4642"/>' &&
                    '      <Cube currency="GBP" rate="0.8668"/>' &&
                    '      <Cube currency="HUF" rate="396.9"/>' &&
                    '      <Cube currency="PLN" rate="4.2665"/>' &&
                    '      <Cube currency="RON" rate="5.0728"/>' &&
                    '      <Cube currency="SEK" rate="11.055"/>' &&
                    '      <Cube currency="CHF" rate="0.9364"/>' &&
                    '      <Cube currency="ISK" rate="143"/>' &&
                    '      <Cube currency="NOK" rate="11.7465"/>' &&
                    '      <Cube currency="TRY" rate="47.9536"/>' &&
                    '      <Cube currency="AUD" rate="1.7865"/>' &&
                    '      <Cube currency="BRL" rate="6.3253"/>' &&
                    '      <Cube currency="CAD" rate="1.6031"/>' &&
                    '      <Cube currency="CNY" rate="8.3155"/>' &&
                    '      <Cube currency="HKD" rate="9.0877"/>' &&
                    '      <Cube currency="IDR" rate="19207.37"/>' &&
                    '      <Cube currency="ILS" rate="3.8953"/>' &&
                    '      <Cube currency="INR" rate="102.8035"/>' &&
                    '      <Cube currency="KRW" rate="1622.26"/>' &&
                    '      <Cube currency="MXN" rate="21.7935"/>' &&
                    '      <Cube currency="MYR" rate="4.9255"/>' &&
                    '      <Cube currency="NZD" rate="1.9811"/>' &&
                    '      <Cube currency="PHP" rate="66.687"/>' &&
                    '      <Cube currency="SGD" rate="1.4987"/>' &&
                    '      <Cube currency="THB" rate="37.76"/>' &&
                    '      <Cube currency="ZAR" rate="20.6758"/>' &&
                    '    </Cube>' &&
                    '    <Cube time="2025-08-28">' &&
                    '      <Cube currency="USD" rate="1.1658"/>' &&
                    '      <Cube currency="JPY" rate="171.72"/>' &&
                    '      <Cube currency="BGN" rate="1.9558"/>' &&
                    '      <Cube currency="CZK" rate="24.458"/>' &&
                    '      <Cube currency="DKK" rate="7.4642"/>' &&
                    '      <Cube currency="GBP" rate="0.8668"/>' &&
                    '      <Cube currency="HUF" rate="396.9"/>' &&
                    '      <Cube currency="PLN" rate="4.2665"/>' &&
                    '      <Cube currency="RON" rate="5.0728"/>' &&
                    '      <Cube currency="SEK" rate="11.055"/>' &&
                    '      <Cube currency="CHF" rate="0.9364"/>' &&
                    '      <Cube currency="ISK" rate="143"/>' &&
                    '      <Cube currency="NOK" rate="11.7465"/>' &&
                    '      <Cube currency="TRY" rate="47.9536"/>' &&
                    '      <Cube currency="AUD" rate="1.7865"/>' &&
                    '      <Cube currency="BRL" rate="6.3253"/>' &&
                    '      <Cube currency="CAD" rate="1.6031"/>' &&
                    '      <Cube currency="CNY" rate="8.3155"/>' &&
                    '      <Cube currency="HKD" rate="9.0877"/>' &&
                    '      <Cube currency="IDR" rate="19207.37"/>' &&
                    '      <Cube currency="ILS" rate="3.8953"/>' &&
                    '      <Cube currency="INR" rate="102.8035"/>' &&
                    '      <Cube currency="KRW" rate="1622.26"/>' &&
                    '      <Cube currency="MXN" rate="21.7935"/>' &&
                    '      <Cube currency="MYR" rate="4.9255"/>' &&
                    '      <Cube currency="NZD" rate="1.9811"/>' &&
                    '      <Cube currency="PHP" rate="66.687"/>' &&
                    '      <Cube currency="SGD" rate="1.4987"/>' &&
                    '      <Cube currency="THB" rate="37.76"/>' &&
                    '      <Cube currency="ZAR" rate="20.6758"/>' &&
                    '    </Cube>' &&
                    '  </Cube>' &&
                    '</gesmes:Envelope>'.


*    " Only do this if you actually see &lt; &gt; &amp; etc. in lv_xml
*    REPLACE ALL OCCURRENCES OF '&lt;'   IN lv_xml WITH '<'.
*    REPLACE ALL OCCURRENCES OF '&gt;'   IN lv_xml WITH '>'.
*    REPLACE ALL OCCURRENCES OF '&quot;' IN lv_xml WITH '"'.
*    REPLACE ALL OCCURRENCES OF '&apos;' IN lv_xml WITH ''''.
*    REPLACE ALL OCCURRENCES OF '&amp;'  IN lv_xml WITH '&'. " do this LAST


*    "--- run the transformation
*    CALL TRANSFORMATION ZTF_XML_CONVERT
*      SOURCE XML lv_xml
*      RESULT Cube = lt_rates.

    out->write( lt_rates ).

  ENDMETHOD.
ENDCLASS.
