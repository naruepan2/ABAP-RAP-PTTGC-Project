CLASS ycl_demo_tf_excel DEFINITION
  PUBLIC
  INHERITING FROM cl_xco_cp_adt_simple_classrun
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF ty_root,
        v1 TYPE string,
        n1 TYPE p LENGTH 12 DECIMALS 2,
      END OF ty_root,
      tt_root TYPE STANDARD TABLE OF ty_root WITH EMPTY KEY.

  PROTECTED SECTION.
    METHODS: main REDEFINITION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_demo_tf_excel IMPLEMENTATION.

  METHOD main.

    FINAL(lv_xml_string) = |<?xml version="1.0" encoding="utf-8"?><SMILE_ROOT><item><V1>Hiiiii</V1><N1>1231223.0</N1></item><item><V1>:)</V1><N1>10.0</N1></item></SMILE_ROOT>|.

    out->write( lv_xml_string ).

    DATA lt_root TYPE tt_root.

    CALL TRANSFORMATION ytf_demo_0001
      SOURCE XML lv_xml_string
      RESULT tf_root = lt_root.

    out->write( lt_root ).

  ENDMETHOD.

ENDCLASS.
