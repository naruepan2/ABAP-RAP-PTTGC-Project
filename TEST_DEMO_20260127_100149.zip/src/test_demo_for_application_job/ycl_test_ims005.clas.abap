CLASS ycl_test_ims005 DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
ENDCLASS.


CLASS ycl_test_ims005 IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.

*    MODIFY ENTITIES OF i_purchaserequisitiontp
*          ENTITY purchaserequisitionitem UPDATE
*          SET FIELDS WITH VALUE #( ( purchaserequisition = '1010000283'
*                                   purchaserequisitionitem = '10'
*                                   requestedquantity           = '20.00'
*                                   baseunit                    = 'EA'
*                                    ) ) .
*
*    COMMIT ENTITIES.


    DATA lt_parameters TYPE zcl_rtr_tr_ecb_exch_rate_main=>tt_job_parameters.

    lt_parameters = VALUE #( ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_purreq
                               sign    = 'I'
                               option  = 'EQ'
                               low     = '1010000516'
                               high    = '' )
                             ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_purtyp
                               sign    = 'I'
                               option  = 'EQ'
                               low     = '10ST'
                               high    = '' )
                             ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_reqdat
                               sign    = 'I'
                               option  = 'EQ'
                               low     = '20250911'
                               high    = '' )
                             ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_plant
                               sign    = 'I'
                               option  = 'EQ'
                               low     = '100E'
                               high    = '' )
*                             ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_prodct
*                               sign    = 'I'
*                               option  = 'EQ'
*                               low     = '000000006065000403'
*                               high    = '' )
*                             ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_mrpctl
*                               sign    = 'I'
*                               option  = 'EQ'
*                               low     = 'X'
*                               high    = '' )
*                             ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_incom1
*                               sign    = 'I'
*                               option  = 'EQ'
*                               low     = ''
*                               high    = '' )
*                             ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_incom2
*                               sign    = 'I'
*                               option  = 'EQ'
*                               low     = 'X'
*                               high    = '' )
                             ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_incom3
                               sign    = 'I'
                               option  = 'EQ'
                               low     = 'X'
                               high    = '' )
                             ( selname = zif_mts_ims_priorpurreqasgnmnt=>c_strloc
                               sign    = 'I'
                               option  = 'EQ'
                               low     = 'A-01'
                               high    = '' )
                           ).
*
    zcl_job_mts_priorpurreq_main=>get_instance( )->pr_priority_requis_assignment( it_parameters = lt_parameters ).
  ENDMETHOD.
ENDCLASS.
