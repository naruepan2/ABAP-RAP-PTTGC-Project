CLASS ycl_job_ext_demo03_call_cpi DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_apj_dt_exec_object .
    INTERFACES if_apj_rt_exec_object .
    CLASS-METHODS class_constructor.
  PROTECTED SECTION.
  PRIVATE SECTION.
    CLASS-DATA: go_log TYPE REF TO if_bali_log.
    CLASS-METHODS _add_log_from_symsg.
ENDCLASS.



CLASS ycl_job_ext_demo03_call_cpi IMPLEMENTATION.

  METHOD class_constructor.
    TRY.
        go_log =
          cl_bali_log=>create_with_header(
            cl_bali_header_setter=>create(
              object    = 'YEXT_DEMO_APJ'
              subobject = 'CPI' ) ).
      CATCH cx_bali_runtime.
        "handle exception
    ENDTRY.
  ENDMETHOD.


  METHOD if_apj_dt_exec_object~get_parameters.

    et_parameter_def = VALUE #(
      (
        selname         = 'P_JSON'
        kind            = if_apj_dt_exec_object=>parameter
        param_text      = 'JSON'
        lowercase_ind   = abap_true
        datatype        = 'C'
        mandatory_ind   = abap_true
        length          = 100
        changeable_ind  = abap_true
*        component_type  = 'BUKRS'
      )
      (
        selname         = 'P_PATH'
        kind            = if_apj_dt_exec_object=>parameter
        param_text      = 'Path'
        datatype        = 'C'
        lowercase_ind   = abap_true
        changeable_ind  = abap_true
*        mandatory_ind   = abap_true
        length          = 100
      )
    ).

  ENDMETHOD.


  METHOD if_apj_rt_exec_object~execute.

    DATA lv_dummy TYPE string.

    LOOP AT it_parameters INTO DATA(ls_parameter).
      CASE ls_parameter-selname.
        WHEN 'P_PATH'.
          DATA(lv_path) = ls_parameter-low.
        WHEN 'P_JSON'.
          DATA(lv_json) = ls_parameter-low.
      ENDCASE.
    ENDLOOP.

    MESSAGE i001 WITH lv_path INTO lv_dummy.
    _add_log_from_symsg( ).

    TRY.
        FINAL(lo_destination) =
          zcl_t2_outbound_provider_http=>create_by_destination( 'S4_TO_CPI' ).
        MESSAGE i002 WITH 'S4_TO_CPI' INTO lv_dummy.
        _add_log_from_symsg( ).

        FINAL(lo_client) = cl_web_http_client_manager=>create_by_http_destination( lo_destination ).

        FINAL(lo_request) = lo_client->get_http_request( ).

        lo_request->set_text( CONV #( lv_json ) ).
        IF lv_path IS NOT INITIAL.
          lo_request->set_uri_path( CONV #( lv_path ) ).
        ENDIF.

        FINAL(lo_response) = lo_client->execute( i_method = if_web_http_client=>get ).
        FINAL(ls_status) = lo_response->get_status( ).

        MESSAGE i003 WITH ls_status-code ls_status-reason INTO lv_dummy.
        _add_log_from_symsg( ).


      CATCH zcx_t2_outbound_provider_http.
        "handle exception
      CATCH cx_web_http_client_error.
        "handle exception
    ENDTRY.

  ENDMETHOD.

  METHOD _add_log_from_symsg.
    IF go_log IS BOUND.
      TRY.
          go_log->add_item( cl_bali_message_setter=>create_from_sy( ) ).
        CATCH cx_bali_runtime.
          "handle exception
      ENDTRY.
    ENDIF.
  ENDMETHOD.

ENDCLASS.
