CLASS ycl_job_ext_zflight_vh DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_apj_rt_value_help_exit .
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_job_ext_zflight_vh IMPLEMENTATION.


  METHOD if_apj_rt_value_help_exit~adjust.


    CASE iv_job_parameter_name.
*      WHEN 'P_AGCID'.
*        SELECT FROM yr_ext_demo_flight001
*    FIELDS agencyid
*    GROUP BY agencyid
*    INTO TABLE @DATA(lt_agency) .
**      ct_selopt = VALUE #( FOR ls_agency IN lt_agency ( shlpname = '/DMO/I_Agency_StdVH' shlpfield = 'P_AGCID' sign = 'I' option = 'EQ' low = ls_agency-agencyid ) ) .
*        ct_selopt = VALUE #( FOR ls_agency IN lt_agency ( shlpname = '/DMO/I_Agency_StdVH' shlpfield = 'AgencyID' sign = 'I' option = 'EQ' low = ls_agency-agencyid ) ) .
WHEN 'SO_BSART'.
*
*        DELETE ct_selopt WHERE shlpfield = 'BSTYP' AND low <> 'C'.
*        DELETE ct_selopt WHERE shlpfield = 'BSAKZ' AND low <> 'C' AND low <> ''.
*
*        APPEND VALUE #( shlpname = 'MMPUR_SH_CCTR_DOCTYPE' shlpfield = 'BSTYP'
*                        sign = 'I' option = 'EQ' low =  'C' )
*        TO ct_selopt.
*
*        APPEND VALUE #( shlpname = 'MMPUR_SH_CCTR_DOCTYPE' shlpfield = 'BSAKZ'
*                        sign = 'I' option = 'EQ' low =  'C' )
*        TO ct_selopt.
*
*        APPEND VALUE #( shlpname = 'MMPUR_SH_CCTR_DOCTYPE' shlpfield = 'BSAKZ'
*                        sign = 'I' option = 'EQ' low =  '' )
*        TO ct_selopt.
    ENDCASE.

  ENDMETHOD.


ENDCLASS.
