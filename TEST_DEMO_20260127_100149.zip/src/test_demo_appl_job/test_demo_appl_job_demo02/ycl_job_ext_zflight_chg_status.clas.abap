CLASS ycl_job_ext_zflight_chg_status DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_apj_dt_exec_object .
    INTERFACES if_apj_rt_exec_object .
  PROTECTED SECTION.
  PRIVATE SECTION.

    DATA : go_log TYPE REF TO if_bali_log .

    METHODS add_text_to_log
      IMPORTING
        iv_text TYPE cl_bali_free_text_setter=>ty_text.

ENDCLASS.



CLASS ycl_job_ext_zflight_chg_status IMPLEMENTATION.


  METHOD if_apj_dt_exec_object~get_parameters.

    " Set Selection Screen
    et_parameter_def = VALUE #(
           ( selname = 'P_AGCID' kind = if_apj_dt_exec_object=>parameter
             component_type = '/DMO/I_Agency_StdVH-AgencyID'  length = 6 datatype = 'C'
             param_text = 'Agency ID'

             section_text    = 'Section 1'
             changeable_ind = abap_true mandatory_ind = abap_true )
           ( selname = 'S_DATE' kind = if_apj_dt_exec_object=>select_option
             component_type = '/DMO/END_DATE'
             param_text = 'End Date'
             section_text    = 'Section 1'
             changeable_ind = abap_true mandatory_ind = abap_true )

*           ( selname = 'SO_BSART' kind = if_apj_dt_exec_object=>select_option
*             component_type = 'MMPUR_EXT_EKKO-BSART'
*             section_text    = 'Section 2'
*             param_text = 'BSART'
*             changeable_ind = abap_true mandatory_ind = abap_true )



                                ( selname         = 'RB_ACP'
                                  kind            = if_apj_dt_exec_object=>parameter
                                  datatype        = 'C'
                                  length          = 1
                                  group_text      = 'Action'
                                  param_text      = 'Accepted'
                                  radio_group_ind = abap_true
                                  radio_group_id  = 'ZST' )
                                ( selname         = 'RB_REJ'
                                  kind            = if_apj_dt_exec_object=>parameter
                                  datatype        = 'C'
                                  length          = 1
                                  param_text      = 'Rejected'
                                  radio_group_ind = abap_true
                                  radio_group_id  = 'ZST' )

*           ( selname = 'RB_ST1' kind = if_apj_dt_exec_object=>parameter
*             radio_group_id = 'ZST'
*             group_text = 'Action'
*             param_text = 'Accepted'
*             radio_group_ind = abap_true
*             component_type =  'C'  length = 1 )
*
*           ( selname = 'RB_ST2' kind = if_apj_dt_exec_object=>parameter
*             radio_group_id = 'ZST'
*             radio_group_ind = abap_true
*             param_text = 'Rejected'
*             component_type =  'C'  length = 1 )
           ).


    " Get Start Date Month / End Date Month
    DATA(lv_sydate) = cl_abap_context_info=>get_system_date(  ) .
    DATA(lv_langu) = cl_abap_context_info=>get_user_language_abap_format( ).
    SELECT SINGLE FROM yi_calendardatefuncbydate( p_date = @lv_sydate , p_language = @lv_langu )
    FIELDS firstdayofmonthdate ,
           lastdayofmonthdate
    INTO @DATA(ls_date) .

    " Set Default Selection Screen
    et_parameter_val = VALUE #(
      ( selname = 'P_AGCID' kind = if_apj_dt_exec_object=>parameter
        sign = 'I' option = 'EQ' low = '70007' ) " Hot Socks Travel (70007)

      ( selname = 'S_DATE' kind = if_apj_dt_exec_object=>select_option
        sign = 'I' option = 'BT' low = |{ ls_date-firstdayofmonthdate DATE = USER }| high = |{ ls_date-lastdayofmonthdate DATE = USER }| )

      ( selname = 'RB_REJ' kind = if_apj_dt_exec_object=>parameter
        sign = 'I' option = 'EQ' low = abap_on )
    ) .

  ENDMETHOD.


  METHOD if_apj_rt_exec_object~execute.


    TRY.
        " handle log
        IF sy-batch = abap_true.
          " if we are running in background, we create application log
          go_log = cl_bali_log=>create_with_header(
            header = cl_bali_header_setter=>create(
              object    = 'YALO_EXT_ZFLIGHT_CHG'
              subobject = 'SUB01' ) ).
          add_text_to_log( 'start job' ).
          FINAL(lv_log_handle) = go_log->get_handle( ).
          add_text_to_log( |log handle: { lv_log_handle }| ).
        ELSE.
          add_text_to_log( 'start job' ).
          add_text_to_log( |foreground run, no log created| ).
        ENDIF.

        " Going through job parameter values

        DATA lr_end_date TYPE RANGE OF ytext_0002_a-end_date .
        DATA lv_status TYPE ytext_0002_a-overall_status .

        LOOP AT it_parameters INTO DATA(ls_parameter).
          CASE ls_parameter-selname.
            WHEN 'P_AGCID'.
              DATA(lv_agency_id) = CONV ytext_0002_a-agency_id( ls_parameter-low ).
            WHEN 'S_DATE'.
              APPEND VALUE #( sign   = ls_parameter-sign
                              option = ls_parameter-option
                              low    = CONV #( ls_parameter-low  )
                              high   = CONV #( ls_parameter-high ) )
                TO lr_end_date.

            WHEN 'RB_ACP' .
              lv_status = COND #( WHEN lv_status IS INITIAL AND ls_parameter-low = abap_on THEN 'A'
                                  ELSE lv_status ) .

            WHEN 'RB_REJ' .
              lv_status = COND #( WHEN lv_status IS INITIAL AND ls_parameter-low = abap_on THEN 'X'
                                  ELSE lv_status ) .
          ENDCASE.
        ENDLOOP.

        " get bookstore for which reorder was requested
        SELECT FROM yr_ext_demo_flight001
          FIELDS *
          WHERE agencyid = @lv_agency_id
*            AND EndDate in @lr_end_date
          INTO TABLE @DATA(lt_flight) .
        IF sy-subrc <> 0 .
          add_text_to_log( |Agent ID not found with id: { lv_agency_id }| ).
        ENDIF.

        IF lt_flight IS NOT INITIAL AND lr_end_date IS NOT INITIAL .
          DELETE lt_flight WHERE enddate NOT IN lr_end_date .
          IF lt_flight IS INITIAL .
            add_text_to_log( |Agent ID { lv_agency_id } not found with scope end date | ).
          ENDIF.
        ENDIF.

        IF lt_flight IS NOT INITIAL .
          DELETE lt_flight WHERE overallstatus NE lv_status .
          IF lt_flight IS INITIAL .
            add_text_to_log( |All Agent ID { lv_agency_id } found with status is { lv_status } | ).
          ENDIF.
        ENDIF.

        DATA :
          lt_reported TYPE RESPONSE FOR REPORTED EARLY yr_ext_demo_flight001,
          lt_failed   TYPE RESPONSE FOR FAILED EARLY yr_ext_demo_flight001.
        IF lt_flight IS NOT INITIAL .

          MODIFY ENTITIES OF yr_ext_demo_flight001
          ENTITY travel
          UPDATE FIELDS ( overallstatus ) WITH VALUE #( FOR ls_flight IN lt_flight ( %key-travelid = ls_flight-travelid overallstatus = lv_status ) )
          FAILED DATA(lt_upd_failed)
          REPORTED DATA(lt_upd_reported) .
          IF lt_upd_failed IS INITIAL.
            " commit change
            COMMIT ENTITIES RESPONSE OF yr_ext_demo_flight001
              REPORTED DATA(lt_commit_reported)
              FAILED DATA(lt_commit_failed).
            " set errors if commit failed
            lt_reported = CORRESPONDING #( DEEP lt_commit_reported ).
            lt_failed = CORRESPONDING #( DEEP lt_commit_failed ).
          ELSE.
            " set error
            lt_reported = CORRESPONDING #( DEEP lt_upd_reported ).
            lt_failed = CORRESPONDING #( DEEP lt_upd_failed ).
          ENDIF.

          IF lt_failed IS INITIAL.
            " SUCCESS -------------------------------
            add_text_to_log( |Update success, nothing in failed| ).

          ELSE.
            " ERRORS --------------------------------
            LOOP AT lt_failed-travel INTO DATA(ls_failed).
              add_text_to_log( |failed to modify travel { ls_failed-travelid } | ).
              add_text_to_log( |reason: { ls_failed-%fail-cause }| ).
            ENDLOOP.
          ENDIF.

        ENDIF.

        add_text_to_log( |job finished| ).

      CATCH cx_bali_runtime INTO DATA(lx_bali_exception).

        DATA(lv_log_exception) = lx_bali_exception->get_text(  ).
        RAISE EXCEPTION TYPE cx_apj_rt_content
          EXPORTING
            previous = lx_bali_exception.

    ENDTRY.
  ENDMETHOD.

  METHOD add_text_to_log.
    " running in background for foreground...
    IF sy-batch = abap_true.
      " background - create text object for log
      DATA(o_go_log_free_text) =
        cl_bali_free_text_setter=>create(
          severity = if_bali_constants=>c_severity_status
          text = iv_text ).
      o_go_log_free_text->set_detail_level( detail_level = '1' ).
      " add text object to log
      go_log->add_item( item = o_go_log_free_text ).
      " save log
      cl_bali_log_db=>get_instance( )->save_log(
        log = go_log
        assign_to_current_appl_job = abap_true ).
    ELSE.
*      " foreground - simply add text to instace attribute, which can be fetched by caller program
*      gs_fglog-no += 1.
*      gs_fglog-text = iv_text.
*      APPEND gs_fglog TO gt_fglog.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
