CLASS ycl_job_ext_execute_demo_04 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_apj_dt_exec_object .
    INTERFACES if_apj_rt_exec_object .

  PROTECTED SECTION.
  PRIVATE SECTION.

    TYPES :
      ty_salname TYPE if_apj_dt_exec_object=>ty_templ_def-selname .

    DATA : go_log TYPE REF TO if_bali_log .

    METHODS add_text_to_log
      IMPORTING
        iv_text TYPE cl_bali_free_text_setter=>ty_text.


    CONSTANTS :
      BEGIN OF mc_exec_input ,
        BEGIN OF param ,
          p_numb TYPE ty_salname VALUE 'P_NUMB',
          p_text TYPE ty_salname VALUE 'P_TEXT',
          rb_01  TYPE ty_salname VALUE 'RB_01',
          rb_02  TYPE ty_salname VALUE 'RB_02',
          rb_03  TYPE ty_salname VALUE 'RB_03',
        END OF param ,

        BEGIN OF sel_opt,
          s_numb  TYPE ty_salname VALUE 'S_NUMB',
          s_bukrs TYPE ty_salname VALUE 'S_BUKRS',
          s_names TYPE ty_salname VALUE 'S_NAMES',
        END OF sel_opt ,
      END OF mc_exec_input .
ENDCLASS.



CLASS ycl_job_ext_execute_demo_04 IMPLEMENTATION.


  METHOD if_apj_dt_exec_object~get_parameters.

*    selname type c length 8
*    kind    type c length 1
*    datatype    type c length 4
*    length  type int4
*    decimals    type int4
*    component_type  type c length 30
*    section_text    type c length 255
*    group_text  type c length 255
*    param_text  type c length 255
*    lowercase_ind   type abap_bool
*    hidden_ind  type abap_bool
*    changeable_ind  type abap_bool
*    mandatory_ind   type abap_bool
*    checkbox_ind    type abap_bool
*    list_ind    type abap_bool
*    radio_group_ind type abap_bool
*    radio_group_id  type c length 4

    et_parameter_def = VALUE #( changeable_ind = abap_true

                                ( selname         = 'P_NUMB'
                                  kind            = if_apj_dt_exec_object=>parameter
                                  datatype        = 'C'
                                  length          = 1
                                  param_text      = 'Numbers available'
                                  checkbox_ind    = abap_true
                                  section_text    = 'Section 1'
                                  group_text      = 'Group 1' )
                                ( selname         = 'S_NUMB'
                                  kind            = if_apj_dt_exec_object=>select_option
                                  datatype        = 'I'
                                  param_text      = 'Numbers'
                                  section_text    = 'Section 1'
                                  group_text      = 'Group 1' )


                                ( selname         = 'S_BUKRS'
                                  kind            = if_apj_dt_exec_object=>select_option
                                  datatype        = 'C'
                                  length          = 4
                                  param_text      = 'Company Code'
                                  component_type  = 'T001-BUKRS' )


                                ( selname         = 'S_NAMES'
                                  kind            = if_apj_dt_exec_object=>select_option
                                  datatype        = 'C'
                                  length          = 50
                                  param_text      = 'Names'

                                  group_text      = 'Group 2' )
                                ( selname         = 'P_TEXT'
                                  kind            = if_apj_dt_exec_object=>parameter
                                  datatype        = 'C'
                                  length          = 255
                                  param_text      = 'Some text'
                                  section_text    = 'Section 2'
                                  group_text      = 'Group 2' )

                                ( selname         = 'RB_01'
                                  kind            = if_apj_dt_exec_object=>parameter
                                  datatype        = 'C'
                                  length          = 1
                                  param_text      = 'Option 1'
                                  radio_group_ind = abap_true
                                  radio_group_id  = 'ZGP1' )
                                ( selname         = 'RB_02'
                                  kind            = if_apj_dt_exec_object=>parameter
                                  datatype        = 'C'
                                  length          = 1
                                  param_text      = 'Option 2'
                                  radio_group_ind = abap_true
                                  radio_group_id  = 'ZGP1' )
                                ( selname         = 'RB_03'
                                  kind            = if_apj_dt_exec_object=>parameter
                                  datatype        = 'C'
                                  length          = 1
                                  param_text      = 'Option 3'
                                  radio_group_ind = abap_true
                                  radio_group_id  = 'ZGP1' ) ).

    " Return default parameter values, if any
    et_parameter_val = VALUE #(
                                ( selname = 'P_TEXT'
                                     kind = if_apj_dt_exec_object=>parameter
                                     sign = 'I' option = 'EQ'
                                     low  = '..My Text..' )
        ).

    et_parameter_val = VALUE #(
                                ( selname = 'RB_02'
                                     kind = if_apj_dt_exec_object=>parameter
                                     sign = 'I' option = 'EQ'
                                     low  = 'X' )
        ).

  ENDMETHOD.


  METHOD if_apj_rt_exec_object~execute.

    TRY.

        go_log = cl_bali_log=>create_with_header(
            header = cl_bali_header_setter=>create( object      = 'YALO_EXT_DEMO_01'
                                                    subobject   = 'YSUBOBJECT'
                                                    external_id = cl_system_uuid=>create_uuid_c32_static( )
                                                  )->set_expiry( expiry_date = CONV d( cl_abap_context_info=>get_system_date( ) + 5 )
                                                                 keep_until_expiry = abap_true ) ).
        add_text_to_log( 'start job' ).

        FINAL(lv_log_handle) = go_log->get_handle( ). add_text_to_log( |log handle: { lv_log_handle }| ).

        add_text_to_log( |log handle: { lv_log_handle }| ).



        " Going through job parameter values

        DATA lr_s_bukrs TYPE RANGE OF bukrs .
        DATA lr_s_names TYPE RANGE OF text50 .
        DATA lr_s_numb  TYPE RANGE OF i .

        LOOP AT it_parameters INTO DATA(ls_parameter).
          CASE ls_parameter-selname.
            WHEN mc_exec_input-param-p_numb .
              DATA(lv_p_numb) = CONV char1( ls_parameter-low ) .
            WHEN mc_exec_input-param-p_text .
              DATA(lv_p_text) = ls_parameter-low .
            WHEN mc_exec_input-param-rb_01 .
              DATA(lv_rb_01) = CONV char1( ls_parameter-low ) .
            WHEN mc_exec_input-param-rb_02 .
              DATA(lv_rb_02) = CONV char1( ls_parameter-low ) .
            WHEN mc_exec_input-param-rb_03 .
              DATA(lv_rb_03) = CONV char1( ls_parameter-low ) .

            WHEN mc_exec_input-sel_opt-s_bukrs .
              APPEND VALUE #( sign   = ls_parameter-sign
                              option = ls_parameter-option
                              low    = CONV #( ls_parameter-low  )
                              high   = CONV #( ls_parameter-high ) )
                TO lr_s_bukrs.
            WHEN mc_exec_input-sel_opt-s_names .
              APPEND VALUE #( sign   = ls_parameter-sign
                              option = ls_parameter-option
                              low    = CONV #( ls_parameter-low  )
                              high   = CONV #( ls_parameter-high ) )
                TO lr_s_names.
            WHEN mc_exec_input-sel_opt-s_numb .
              APPEND VALUE #( sign   = ls_parameter-sign
                              option = ls_parameter-option
                              low    = CONV #( ls_parameter-low  )
                              high   = CONV #( ls_parameter-high ) )
                TO lr_s_numb.
          ENDCASE.
        ENDLOOP.

*        """"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
*        " severity: use if_bali_constants
*        "   c_severity_default      type if_bali_constants=>ty_severity value c_severity_status
*        "   c_severity_error        type if_bali_constants=>ty_severity value 'E'
*        "   c_severity_exit         type if_bali_constants=>ty_severity value 'X'
*        "   c_severity_information  type if_bali_constants=>ty_severity value 'I'
*        "   c_severity_status       type if_bali_constants=>ty_severity value 'S'
*        "   c_severity_termination  type if_bali_constants=>ty_severity value 'A'
*        "   c_severity_warning      type if_bali_constants=>ty_severity value 'W'
*        """"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
*
*        """"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

        CASE abap_on.
          WHEN lv_rb_01.

            go_log->add_item( item = cl_bali_free_text_setter=>create( severity = if_bali_constants=>c_severity_default
                                                                       text     = 'test_severity_def' ) ).

          WHEN lv_rb_02.

            go_log->add_item( item = cl_bali_free_text_setter=>create( severity = if_bali_constants=>c_severity_status
                                                                       text     = 'test_severity_status' ) ).

          WHEN lv_rb_03.

            go_log->add_item( item = cl_bali_free_text_setter=>create( severity = if_bali_constants=>c_severity_error
                                                                       text     = 'test_severity_error' ) ).

        ENDCASE.

        cl_bali_log_db=>get_instance( )->save_log( log                        = go_log
                                                   assign_to_current_appl_job = abap_true ).

        " Incase Direct call
*        COMMIT WORK.
*      CATCH cx_bali_runtime INTO DATA(l_runtime_exception). " TODO: variable is assigned but only used in commented-out code (ABAP cleaner)
*        out->write( l_runtime_exception->get_longtext( ) ).
      CATCH cx_bali_runtime.

      CATCH cx_uuid_error.

    ENDTRY.


  ENDMETHOD.

  METHOD add_text_to_log.
    " running in background for foreground...
    IF sy-batch = abap_true.
      " background - create text object for log
      DATA(o_go_log_free_text) =
        cl_bali_free_text_setter=>create(
          severity = if_bali_constants=>c_severity_status
          text = iv_text ).
      o_go_log_free_text->set_detail_level( detail_level = '1' ).
      " add text object to log
      go_log->add_item( item = o_go_log_free_text ).
      " save log
      cl_bali_log_db=>get_instance( )->save_log(
        log = go_log
        assign_to_current_appl_job = abap_true ).
    ELSE.
*      " foreground - simply add text to instace attribute, which can be fetched by caller program
*      gs_fglog-no += 1.
*      gs_fglog-text = iv_text.
*      append gs_fglog to gt_fglog.
    ENDIF.
  ENDMETHOD.


ENDCLASS.
