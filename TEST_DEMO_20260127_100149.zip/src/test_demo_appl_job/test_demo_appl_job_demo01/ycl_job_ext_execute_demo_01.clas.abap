CLASS ycl_job_ext_execute_demo_01 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_apj_dt_exec_object .
    INTERFACES if_apj_rt_exec_object .
    INTERFACES if_apj_rt_value_help_exit .
    CLASS-METHODS class_constructor.
  PROTECTED SECTION.
  PRIVATE SECTION.

    TYPES:
      BEGIN OF ty_item,
        company_code TYPE string,
      END OF ty_item,
      tt_items TYPE STANDARD TABLE OF ty_item WITH EMPTY KEY,
      BEGIN OF ty_payload,
        timestamp TYPE timestamp,
        username  TYPE string,
        items     TYPE tt_items,
      END OF ty_payload.

    CLASS-DATA: go_log TYPE REF TO if_bali_log.
    CLASS-METHODS _add_log_from_symsg.
    CLASS-METHODS _save_log.
    DATA gv_dummy_text TYPE string.
    METHODS _get_parameters
      IMPORTING
        it_parameters TYPE if_apj_dt_exec_object=>tt_templ_val
      EXPORTING
        ev_path       TYPE string
        ev_json       TYPE string.
    METHODS _generate_payload
      RETURNING
        VALUE(rv_payload) TYPE string.
ENDCLASS.



CLASS ycl_job_ext_execute_demo_01 IMPLEMENTATION.

  METHOD class_constructor.
    TRY.
        go_log =
          cl_bali_log=>create_with_header(
            cl_bali_header_setter=>create(
              object    = 'YEXT_DEMO_APJ'
              subobject = 'CPI' ) ).
      CATCH cx_bali_runtime.
        "handle exception
    ENDTRY.
  ENDMETHOD.


  METHOD if_apj_dt_exec_object~get_parameters.

    et_parameter_def = VALUE #(
      (
        selname         = 'P_JSON'
        kind            = if_apj_dt_exec_object=>parameter
        param_text      = 'JSON'
        lowercase_ind   = abap_true
        datatype        = 'C'
        length          = 100
        changeable_ind  = abap_true
      )
      (
        selname         = 'P_PATH'
        kind            = if_apj_dt_exec_object=>parameter
        param_text      = 'Path'
        datatype        = 'C'
        lowercase_ind   = abap_true
        changeable_ind  = abap_true
        length          = 100
      )
      (
        selname         = 'S_BUKRS'
        kind            = if_apj_dt_exec_object=>parameter
        param_text      = 'Company Code'
        component_type  = 'BUKRS'
        datatype        = 'C'
        length          = 4
        changeable_ind  = abap_true
      )
    ).

  ENDMETHOD.


  METHOD if_apj_rt_exec_object~execute.

    _get_parameters(
      EXPORTING
        it_parameters = it_parameters
      IMPORTING
        ev_path = FINAL(lv_path)
        ev_json = DATA(lv_json)
    ).


    TRY.
        FINAL(lo_destination) =
          zcl_t2_outbound_provider_http=>create_by_destination( 'S4_TO_CPI' ).
        MESSAGE i002 WITH 'S4_TO_CPI' INTO gv_dummy_text.
        _add_log_from_symsg( ).

        FINAL(lo_client) = cl_web_http_client_manager=>create_by_http_destination( lo_destination ).

        FINAL(lo_request) = lo_client->get_http_request( ).

        IF lv_json IS INITIAL OR lv_json = 'FIXED'.
          lv_json = _generate_payload( ).
        ENDIF.

        lo_request->set_content_type( 'application/json' ).
        lo_request->set_text(
          i_text    = CONV #( lv_json )
          i_length  = strlen( lv_json ) ).

        IF lv_path IS NOT INITIAL.
          lo_request->set_uri_path( CONV #( lv_path ) ).
        ENDIF.

        FINAL(lo_response) = lo_client->execute( i_method = if_web_http_client=>post ).
        FINAL(ls_status) = lo_response->get_status( ).
        FINAL(lv_res_text) = lo_response->get_text( ).

        MESSAGE i003 WITH ls_status-code ls_status-reason INTO gv_dummy_text.
        _add_log_from_symsg( ).

        MESSAGE i004 WITH lv_res_text INTO gv_dummy_text.
        _add_log_from_symsg( ).

      CATCH zcx_t2_outbound_provider_http.
        "handle exception
      CATCH cx_web_http_client_error.
        "handle exception
    ENDTRY.

    _save_log( ).

  ENDMETHOD.

  METHOD _add_log_from_symsg.
    IF go_log IS BOUND.
      TRY.
          go_log->add_item( cl_bali_message_setter=>create_from_sy( ) ).
        CATCH cx_bali_runtime.
          "handle exception
      ENDTRY.
    ENDIF.
  ENDMETHOD.


  METHOD _save_log.
    IF go_log IS BOUND.
      TRY.
          cl_bali_log_db=>get_instance(
            )->save_log(
              log                        = go_log
              assign_to_current_appl_job = abap_true ).
        CATCH cx_bali_runtime.
          "handle exception
      ENDTRY.
    ENDIF.
  ENDMETHOD.


  METHOD _get_parameters.

    LOOP AT it_parameters INTO DATA(ls_parameter).
      CASE ls_parameter-selname.
        WHEN 'P_PATH'.  ev_path = ls_parameter-low.
        WHEN 'P_JSON'.  ev_json = ls_parameter-low.
      ENDCASE.
    ENDLOOP.

    MESSAGE i001 WITH ev_path INTO gv_dummy_text.
    _add_log_from_symsg( ).

    MESSAGE i005 WITH ev_json INTO gv_dummy_text.
    _add_log_from_symsg( ).

  ENDMETHOD.


  METHOD _generate_payload.
    DATA(ls_payload) =
      VALUE ty_payload(
        username = cl_abap_context_info=>get_user_technical_name( )
      ).
    GET TIME STAMP FIELD ls_payload-timestamp.

    SELECT FROM i_companycode
      FIELDS
        companycode AS company_code
      INTO CORRESPONDING FIELDS OF TABLE @ls_payload-items
      UP TO 5 ROWS.

    rv_payload =
      xco_cp_json=>data->from_abap( ls_payload
        )->apply( VALUE #( ( xco_cp_json=>transformation->underscore_to_pascal_case ) )
        )->to_string( ).
  ENDMETHOD.

  METHOD if_apj_rt_value_help_exit~adjust.
*    CASE iv_job_parameter_name.
*      WHEN 'S_BUKRS'.
    APPEND INITIAL LINE TO ct_selopt ASSIGNING FIELD-SYMBOL(<ls_selopt>).
    <ls_selopt>-sign       = 'I'.
    <ls_selopt>-option     = 'EQ'.
    <ls_selopt>-low        = '10'.
    <ls_selopt>-shlpname   = 'I_COMPANYCODESTDVH'.
    <ls_selopt>-shlpfield  = 'COMPANYCODE'.
*    ENDCASE.
  ENDMETHOD.

ENDCLASS.
