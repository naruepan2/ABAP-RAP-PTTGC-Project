@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Cube'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_RTR_CO018_Cube
  as select from    I_GLAccountLineItemRawData as ACDOCA

    inner join      ZI_FAGL_011ZC              as FSItem             on  ACDOCA.ChartOfAccounts =    FSItem.ktopl
                                                                     and FSItem.versn           =    'GC02'
                                                                     and FSItem.vonkt           <=   ACDOCA.GLAccount
                                                                     and FSItem.biskt           >=   ACDOCA.GLAccount
                                                                     and FSItem.ergsl           like '3%'

    left outer join ZI_SETLEAF                 as CostCenterGroupSet on  CostCenterGroupSet.SetRangeFromValue <=   ACDOCA.CostCenter
                                                                     and CostCenterGroupSet.SetRangeToValue   >=   ACDOCA.CostCenter
                                                                     and CostCenterGroupSet.SetSubClass       =    '1000'
                                                                     and CostCenterGroupSet.Setclass          =    '0101'
                                                                     and CostCenterGroupSet.SetID             like 'C%'
{
  key ACDOCA.SourceLedger,
  key ACDOCA.CompanyCode,
  key ACDOCA.FiscalYear,
  key ACDOCA.AccountingDocument,
  key ACDOCA.LedgerGLLineItem,
      ACDOCA.LedgerFiscalYear,
      ACDOCA.GLAccount,
      ACDOCA.ProfitCenter,
      ACDOCA.CostCenter,
      CostCenterGroupSet.SetID         as CostCenterGroupID,
      CostCenterGroupSet.SetLineNumber as CostCenterGroupLineNumber,

      case
        when $projection.CostCenterGroupID = 'C10RELEC01'
            then 'X002'
        else 'X999'
      end                              as zColumn,

      case
        when FSItem.ergsl = '31109' then 'Y005'
        when FSItem.ergsl = '31448' then 'Y087'
        when FSItem.ergsl = '3120105' then 'Y004' //'Y029!!!
        else 'Y999'
      end                              as zRow,

      //      @AnalyticsDetails.query.onCharacteristicStructure: true
      //      @EndUserText.label: 'Hydrogen'
      //      case
      //      when
      //       (
      //          GLAccount   =   '0051400200' or
      //          GLAccount   =   '0081514003' or
      //          GLAccount   =   '0082514003'
      //       )  then 1
      //      end                          as Hydrogen,
      //      @AnalyticsDetails.query.onCharacteristicStructure: true
      //      @EndUserText.label: 'BFW'
      //      case
      //      when
      //       (
      //          GLAccount   =   '0051411000' or
      //          GLAccount   =   '0081514110' or
      //          GLAccount   =   '0082514110'
      //       )  then 1
      //      end                          as BFW,
      //
      //      @AnalyticsDetails.query.formula: '(Hydrogen - BFW)' //!!!!!!
      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      cast( 0 as abap.curr(23,2) )     as Amount,

      @Semantics.amount.currencyCode: 'CompanyCodeCurrency'
      ACDOCA.AmountInCompanyCodeCurrency,
      ACDOCA.CompanyCodeCurrency,

      FSItem.versn,
      FSItem.ergsl,
      FSItem.ktopl,
      FSItem.vonkt,
      FSItem.biskt,
      FSItem.xsoll,
      FSItem.xhabn,
      FSItem.xverd

}
where
      ACDOCA.ChartOfAccounts = 'PTGC'
  and ACDOCA.SourceLedger    = '0L'
  and ACDOCA.GLRecordType    = '0'
  and ACDOCA.ProfitCenter    = 'P101033'
  and ACDOCA.ControllingArea = '1000'

  and ACDOCA.CompanyCode     = '10'
  and ACDOCA.FiscalYear      = '2026'
