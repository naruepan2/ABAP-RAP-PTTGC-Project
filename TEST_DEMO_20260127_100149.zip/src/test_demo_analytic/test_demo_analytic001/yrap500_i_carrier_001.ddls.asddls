@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Dimension for Carrier'
@Metadata.ignorePropagatedAnnotations: true

@Analytics.dataCategory: #DIMENSION
@Analytics.internalName: #LOCAL
@ObjectModel.representativeKey: 'CarrierId'

define view entity YRAP500_I_CARRIER_001
  as select from /dmo/carrier
{
      @ObjectModel.text.element: ['Name']
      @UI.lineItem: [{ position: 100 }]
  key carrier_id            as CarrierId,
      @UI.lineItem: [{ position: 200 }]
      name                  as Name,
      @UI.lineItem: [{ position: 300 }]
      currency_code         as CurrencyCode,
      local_created_by      as LocalCreatedBy,
      local_created_at      as LocalCreatedAt,
      local_last_changed_by as LocalLastChangedBy,
      local_last_changed_at as LocalLastChangedAt,
      last_changed_at       as LastChangedAt
}
