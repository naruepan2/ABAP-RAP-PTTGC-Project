@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Booking Cube'
@Metadata.ignorePropagatedAnnotations: true

@Analytics.dataCategory: #CUBE
@Analytics.internalName: #LOCAL

define view entity YRAP500_I_BOOKINGCUBE_001
  as select from YRAP500_I_BOOKING_001
  association [0..1] to YRAP500_I_CUSTOMER_001   as _Customer   on  $projection.CustomerID = _Customer.CustomerId
  association [0..1] to YRAP500_I_CARRIER_001    as _Carrier    on  $projection.AirlineID = _Carrier.CarrierId
  association [0..1] to YRAP500_I_CONNECTION_001 as _Connection on  $projection.AirlineID    = _Connection.CarrierId
                                                                and $projection.ConnectionId = _Connection.ConnectionId
  association [0..1] to YRAP500_I_AGENCY_001     as _Agency     on  $projection.AgencyID = _Agency.AgencyId
{
  key TravelID,
  key BookingID,
      BookingDate,
      @ObjectModel.foreignKey.association: '_Customer'
      CustomerID,
      @ObjectModel.foreignKey.association: '_Carrier'
      AirlineID,
      @ObjectModel.foreignKey.association: '_Connection'
      ConnectionID          as ConnectionId,
      FlightDate,
      //      @Semantics.amount.currencyCode: 'CurrencyCode'
      //      FlightPrice,
      CurrencyCode,
      @ObjectModel.foreignKey.association: '_Agency'
      AgencyID,

      @ObjectModel.foreignKey.association: '_CustomerCountry'
      _Customer.CountryCode as CustomerCountry,
      _Customer.City        as CustomerCity,
      _Connection.Trip      as Trip,

      /* Measures */

      @EndUserText.label: 'Total of Bookings'
      @Aggregation.default: #SUM
      1                     as TotalOfBookings,

      @Semantics.amount.currencyCode: 'CurrencyCode'
      @Aggregation.default: #SUM
      FlightPrice,


      /* Associations */
      _Carrier,
      _Connection,
      _Customer,
      _Travel,
      _Agency,
      _Customer._Country    as _CustomerCountry
}
