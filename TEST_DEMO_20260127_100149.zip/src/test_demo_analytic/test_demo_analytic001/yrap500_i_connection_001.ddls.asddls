@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Dimension for Connections'
@Metadata.ignorePropagatedAnnotations: true

@Analytics.dataCategory: #DIMENSION
@Analytics.internalName: #LOCAL
@ObjectModel.representativeKey: 'ConnectionId'

define view entity YRAP500_I_CONNECTION_001
  as select from /dmo/connection
  association [1] to YRAP500_I_CARRIER_001 as _Carrier on $projection.CarrierId = _Carrier.CarrierId
{
      @ObjectModel.text.element: ['Trip']
      @ObjectModel.foreignKey.association: '_Carrier'
  key carrier_id                                           as CarrierId,
  key connection_id                                        as ConnectionId,
      airport_from_id                                      as AirportFromId,
      airport_to_id                                        as AirportToId,
      concat(airport_from_id, concat('->', airport_to_id)) as Trip,
      departure_time                                       as DepartureTime,
      arrival_time                                         as ArrivalTime,
      distance                                             as Distance,
      distance_unit                                        as DistanceUnit,
      _Carrier
}
