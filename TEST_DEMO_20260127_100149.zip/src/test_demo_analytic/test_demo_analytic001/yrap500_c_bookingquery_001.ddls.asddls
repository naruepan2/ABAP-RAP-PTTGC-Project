@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_ALLOWED
@EndUserText.label: 'Query for Booking'
@ObjectModel.modelingPattern: #ANALYTICAL_QUERY
@ObjectModel.supportedCapabilities: [#ANALYTICAL_QUERY]

@Analytics.internalName: #LOCAL

define transient view entity YRAP500_C_BOOKINGQUERY_001
  provider contract analytical_query
  as projection on YRAP500_I_BOOKINGCUBE_001
{
  @AnalyticsDetails.query.axis: #ROWS
  TravelID,
  @AnalyticsDetails.query.axis: #ROWS
  BookingID,
  @AnalyticsDetails.query.axis: #ROWS
  BookingDate,
  @AnalyticsDetails.query.axis: #ROWS
  CustomerID,
  @AnalyticsDetails.query.axis: #ROWS
  AirlineID,
  @AnalyticsDetails.query.axis: #ROWS
  ConnectionId,
  @AnalyticsDetails.query.axis: #ROWS
  FlightDate,
  @AnalyticsDetails.query.axis: #ROWS
  CurrencyCode,
  @AnalyticsDetails.query.axis: #ROWS
  AgencyID,
  @AnalyticsDetails.query.axis: #COLUMNS
  CustomerCountry,
  @AnalyticsDetails.query.axis: #ROWS
  CustomerCity,
  @AnalyticsDetails.query.axis: #ROWS
  Trip,


  TotalOfBookings,

  @Semantics.amount.currencyCode: 'CurrencyCode'
  @Aggregation.default: #FORMULA
  currency_conversion (
      amount => FlightPrice,
      source_currency => CurrencyCode,
      target_currency => cast( 'EUR' as abap.cuky( 5 ) ) ,
      exchange_rate_date => cast ('20200101' as abap.dats),
      exchange_rate_type => 'M'
  ) as FlightPrice
}
