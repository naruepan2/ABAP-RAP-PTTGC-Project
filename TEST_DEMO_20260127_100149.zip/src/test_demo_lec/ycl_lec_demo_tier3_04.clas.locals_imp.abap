*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations

CLASS lcl_abap_behv_event_handler DEFINITION INHERITING FROM cl_abap_behavior_event_handler.

  PRIVATE SECTION.

    METHODS:
      consume_changed FOR ENTITY EVENT instances FOR customerpaymenttall~changed.

    METHODS:
      consume_created FOR ENTITY EVENT instances FOR customerpaymenttall~created.


ENDCLASS.

CLASS lcl_abap_behv_event_handler IMPLEMENTATION.

  METHOD consume_changed.
*    FINAL(lo_logic) = ycl_demo_lec_logic_in_tier1=>create( ).
    LOOP AT instances ASSIGNING FIELD-SYMBOL(<ls_instance>).
**      ASSERT <ls_instance>-SalesOrder <> '3190000024'.
*      TRY.
*          lo_logic->add_log(
*            iv_value1  = <ls_instance>-
*            iv_value2  = 'SO Changed'(002)
*          ).
*        CATCH cx_uuid_error.
*          CONTINUE.
*      ENDTRY.
    ENDLOOP.
*    lo_logic->save( ).
  ENDMETHOD.

  METHOD consume_created.

   LOOP AT instances ASSIGNING FIELD-SYMBOL(<ls_instance>).
   endloop.

  ENDMETHOD.

ENDCLASS.
