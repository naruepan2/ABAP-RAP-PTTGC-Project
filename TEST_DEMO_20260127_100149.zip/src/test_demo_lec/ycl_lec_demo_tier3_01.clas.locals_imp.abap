*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations

CLASS lcl_abap_behv_event_handler DEFINITION INHERITING FROM cl_abap_behavior_event_handler.

  PRIVATE SECTION.

    METHODS:
      consume_created FOR ENTITY EVENT instances FOR product~created,
      consume_changed FOR ENTITY EVENT instances FOR product~changed.

ENDCLASS.

CLASS lcl_abap_behv_event_handler IMPLEMENTATION.

  METHOD consume_created.
    FINAL(lo_logic) = ycl_demo_lec_logic_in_tier1=>create( ).
    LOOP AT instances ASSIGNING FIELD-SYMBOL(<ls_instance>).
      TRY.
          lo_logic->add_log(
            iv_value1  = <ls_instance>-Product
            iv_value2  = 'Product Created'(001)
          ).
        CATCH cx_uuid_error.
          CONTINUE.
      ENDTRY.
    ENDLOOP.
    lo_logic->save( ).
  ENDMETHOD.

  METHOD consume_changed.
    FINAL(lo_logic) = ycl_demo_lec_logic_in_tier1=>create( ).
    LOOP AT instances ASSIGNING FIELD-SYMBOL(<ls_instance>).
      TRY.
          lo_logic->add_log(
            iv_value1  = <ls_instance>-Product
            iv_value2  = 'Product Changed'(002)
          ).
        CATCH cx_uuid_error.
          CONTINUE.
      ENDTRY.
    ENDLOOP.
    lo_logic->save( ).
  ENDMETHOD.

ENDCLASS.
