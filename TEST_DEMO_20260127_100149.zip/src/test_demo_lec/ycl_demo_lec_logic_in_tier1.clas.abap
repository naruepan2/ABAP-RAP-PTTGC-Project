CLASS ycl_demo_lec_logic_in_tier1 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    CLASS-METHODS create
      RETURNING
        VALUE(ro_result) TYPE REF TO ycl_demo_lec_logic_in_tier1.

    METHODS add_log
      IMPORTING
        iv_value1 TYPE clike
        iv_value2 TYPE clike
      RAISING
        cx_uuid_error.

    METHODS save.

  PROTECTED SECTION.
  PRIVATE SECTION.
    TYPES:
      ty_log TYPE ytext_0001_l,
      tt_log TYPE STANDARD TABLE OF ty_log WITH EMPTY KEY.

    DATA:
      mt_log TYPE tt_log.
    METHODS is_allowed
      RETURNING
        VALUE(rv_result) TYPE abap_bool.

ENDCLASS.



CLASS ycl_demo_lec_logic_in_tier1 IMPLEMENTATION.

  METHOD create.
    ro_result = NEW #( ).
  ENDMETHOD.

  METHOD add_log.
    GET TIME STAMP FIELD DATA(lv_timestamp).
    INSERT
      VALUE ty_log(
        guid    = cl_system_uuid=>create_uuid_c32_static( )
        ts      = lv_timestamp
        value1  = iv_value1
        value2  = iv_value2
        username = cl_abap_context_info=>get_user_technical_name( )
    ) INTO TABLE mt_log.
  ENDMETHOD.

  METHOD save.
    IF is_allowed( ).
      cl_abap_tx=>save( ).
      INSERT ytext_0001_l FROM TABLE @mt_log.
*      cl_abap_tx=>modify( ).
    ENDIF.
  ENDMETHOD.


  METHOD is_allowed.
    CASE cl_abap_context_info=>get_user_technical_name( ).
      WHEN 'T_TEST'
        OR 'Z0012280'
        OR 'Z0012353'.
        rv_result = abap_true.
    ENDCASE.
  ENDMETHOD.

ENDCLASS.
