CLASS ycl_lec_demo_tier3_03 DEFINITION
  PUBLIC
  ABSTRACT
  FINAL
  "Implement in tier 3; S/4HANA PCE 2023 FPS3
  FOR EVENTS OF R_SalesOrderTP.
  "To be changed to tier 1; Future release
*  FOR EVENTS OF I_SalesOrderTP.

  PUBLIC SECTION.
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_lec_demo_tier3_03 IMPLEMENTATION.
ENDCLASS.
