CLASS ycl_ext_call_cpi_utility DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_oo_adt_classrun .
  PROTECTED SECTION.
  PRIVATE SECTION.
    METHODS call_outbound_bot IMPORTING out TYPE REF TO if_oo_adt_classrun_out .
ENDCLASS.



CLASS ycl_ext_call_cpi_utility IMPLEMENTATION.


  METHOD if_oo_adt_classrun~main.

    call_outbound_bot( out ) .

  ENDMETHOD.

  METHOD call_outbound_bot.



    " Declare type refer API Document: https://apiportal.bot.or.th/bot/public/node/18272
    TYPES :
      BEGIN OF lty_report_source_of_data,
        source_of_data_eng TYPE string,
        source_of_data_th  TYPE string,
      END OF lty_report_source_of_data ,
      ltt_report_source_of_data TYPE STANDARD TABLE OF lty_report_source_of_data WITH EMPTY KEY,

      BEGIN OF lty_report_remark,
        report_remark_eng TYPE string,
        report_remark_th  TYPE string,
      END OF lty_report_remark ,
      ltt_report_remark TYPE STANDARD TABLE OF lty_report_remark WITH EMPTY KEY,

      BEGIN OF lty_data_header ,
        report_name_eng       TYPE string,
        report_name_th        TYPE string,
        report_uoq_name_eng   TYPE string,
        report_uoq_name_th    TYPE string,
        report_source_of_data TYPE ltt_report_source_of_data,
        report_remark         TYPE ltt_report_remark,
        last_updated          TYPE string,
      END OF lty_data_header ,

      BEGIN OF lty_data_detail ,
        period            TYPE string,
        currency_id       TYPE string,
        currency_name_th  TYPE string,
        currency_name_eng TYPE string,
        buying_sight      TYPE string,
        buying_transfer   TYPE string,
        selling           TYPE string,
        mid_rate          TYPE string,
      END OF lty_data_detail ,
      ltt_data_detail TYPE STANDARD TABLE OF lty_data_detail WITH EMPTY KEY,
      BEGIN OF lty_data ,
        data_header TYPE lty_data_header,
        data_detail TYPE ltt_data_detail,
      END OF lty_data ,
      BEGIN OF lty_result ,
        api       TYPE string,
        timestamp TYPE string,
        data      TYPE lty_data,
      END OF lty_result ,

      BEGIN OF lty_response ,
        result TYPE lty_result,
      END OF lty_response .

    DATA : ls_response_cl TYPE lty_response,
           ls_response    TYPE lty_response.

    TRY.
        DATA(lo_cpi) = zcl_ext_cpi_utils_2=>get_instance(
          EXPORTING
            iv_program = 'YCL_CALL_BOT'
        ).

        lo_cpi->set_json_transformation( VALUE #(
      ( xco_cp_json=>transformation->boolean_to_abap_bool )
       ) ).

        lo_cpi->call_http_request_json(
          EXPORTING
            iv_interfaceid          = 'CALL_BOT'
*          iv_request_payload      =
            iv_iflow_path           = '/DAILY_AVG_EXG_RATE/'
            iv_iflow_query          = 'start_period=2025-08-01&end_period=2025-08-02'
            iv_iflow_http_method    =  if_web_http_client=>get
*          iv_iflow_requestheaders =
          IMPORTING
*          eo_response             =
*          eo_request              =
            eo_monitor              = DATA(lo_monitor)
          ev_response_payload     = DATA(lv_response_json)
            es_status               = DATA(ls_status)
          e_abap                  = ls_response_cl
        ).


        lo_monitor->save_eml( abap_on ).

        out->write( ls_response_cl ).


      CATCH zcx_ext_interface_error INTO DATA(lx_inf_error).
        out->write( lx_inf_error->get_text( ) ).
    ENDTRY.

  ENDMETHOD.

ENDCLASS.
