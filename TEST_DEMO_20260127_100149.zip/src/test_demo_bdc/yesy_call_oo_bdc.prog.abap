*&---------------------------------------------------------------------*
*& Report  ZESY_CALL_OO_BDC
*&
*&---------------------------------------------------------------------*
REPORT  yesy_call_oo_bdc.

*----------------------------------------------------------------------*
*  Selection Screen
*----------------------------------------------------------------------*
PARAMETER:
  p_kunnr  TYPE kna1-kunnr DEFAULT '2400',
  p_vkorg  TYPE knvv-vkorg DEFAULT '1000',
  p_vtweg  TYPE knvv-vtweg DEFAULT '10',
  p_spart  TYPE knvv-spart DEFAULT '00'.
SELECTION-SCREEN SKIP 1.
PARAMETER:
  p_delblk TYPE kna1-lifsd DEFAULT '01',
  p_bilblk TYPE kna1-faksd DEFAULT '01'.
SELECTION-SCREEN SKIP 1.

PARAMETER:
  p_tran RADIOBUTTON GROUP r1 DEFAULT 'X',
  p_sess RADIOBUTTON GROUP r1.

*----------------------------------------------------------------------*
*  Data Declarations
*----------------------------------------------------------------------*
DATA:
  g_bdc       TYPE REF TO zcl_classic_bdc_utilities,
  g_messages  TYPE tab_bdcmsgcoll,
  g_message   LIKE LINE OF g_messages,
  g_subrc     TYPE sy-subrc,
  g_exception TYPE REF TO zcx_classic_batch_input_error,
  g_error     TYPE string.

*----------------------------------------------------------------------*
*  Initialization
*----------------------------------------------------------------------*
*INITIALIZATION.

*----------------------------------------------------------------------*
*  Start of Selection
*----------------------------------------------------------------------*
START-OF-SELECTION.

* Create an object for BDC
  IF p_tran = 'X'.
    g_bdc = zcl_classic_bdc_utilities=>s_instantiate( iv_bdc_type = 'CT'
                                       iv_tcode    = 'VD05' ).
  ELSEIF p_sess = 'X'.
    g_bdc = zcl_classic_bdc_utilities=>s_instantiate( iv_bdc_type = 'BI'
                                       iv_tcode    = 'VD05'
                                       iv_group    = 'MY_SESSION'
                                       iv_keep     = 'X'
                                       iv_holddate = '20140528' ).
  ENDIF.

* Populate first screen
  g_bdc->add_screen( iv_repid = 'SAPMF02D' iv_dynnr = '0507').
  g_bdc->add_field( iv_fld = 'BDC_OKCODE'  iv_val = '/00').
  g_bdc->add_field( iv_fld = 'RF02D-KUNNR' iv_val = p_kunnr ).
  g_bdc->add_field( iv_fld = 'RF02D-VKORG' iv_val = p_vkorg ).
  g_bdc->add_field( iv_fld = 'RF02D-VTWEG' iv_val = p_vtweg ).
  g_bdc->add_field( iv_fld = 'RF02D-SPART' iv_val = p_spart ).
* Populate second screen
  g_bdc->add_screen( iv_repid = 'SAPMF02D' iv_dynnr = '0510').
  g_bdc->add_field( iv_fld = 'BDC_OKCODE' iv_val = '=UPDA').
  g_bdc->add_field( iv_fld = 'KNA1-LIFSD' iv_val = p_delblk ).
  g_bdc->add_field( iv_fld = 'KNA1-FAKSD' iv_val = p_bilblk ).

*----------------------------------------------------------------------*
*  End of Selection
*----------------------------------------------------------------------*
END-OF-SELECTION.

  IF p_tran = 'X'.
    g_bdc->process( IMPORTING ev_subrc    = g_subrc
                              et_messages = g_messages ).
*   Display processing status
    IF g_subrc = 0.
      WRITE:/ 'Success:'.
    ELSE.
      WRITE:/ 'Error:'.
*     Display messages in list
      LOOP AT g_messages INTO g_message.
        MESSAGE ID g_message-msgid
                TYPE g_message-msgtyp
                NUMBER g_message-msgnr
                WITH g_message-msgv1
                     g_message-msgv2
                     g_message-msgv3
                     g_message-msgv4
                INTO g_error.
        WRITE:/ g_error.
      ENDLOOP.
    ENDIF.
  ELSEIF p_sess = 'X'.
    TRY.
        g_bdc->process( ).
        WRITE: 'Success: Check session in SM35'.
      CATCH zcx_classic_batch_input_error INTO g_exception.
        WRITE:/ 'Error creating batch input session:'.
        MESSAGE ID g_exception->msgid
                TYPE 'E'
                NUMBER g_exception->msgno
                WITH g_exception->msgv1
                     g_exception->msgv2
                     g_exception->msgv3
                     g_exception->msgv4
                INTO g_error.
        WRITE:/ g_error.
    ENDTRY.
  ENDIF.
