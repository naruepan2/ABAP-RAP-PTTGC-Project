CLASS ycl_ext_call_itself DEFINITION
  PUBLIC
  INHERITING FROM cl_xco_cp_adt_simple_classrun
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
  PROTECTED SECTION.
    METHODS: main REDEFINITION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_ext_call_itself IMPLEMENTATION.
  METHOD main.

    TRY.
        FINAL(lo_http) =
          zcl_t2_outbound_provider_http=>create_by_destination(
*          iv_name = CONV #( |FIORI_FLP_HTTPS| )
          iv_name = CONV #( |HTTPS_GSDCLNT120| )
*          iv_name = CONV #( |GSDCLNT{ sy-mandt  }| )
*            iv_name         = SWITCH #( sy-mandt
*                                        WHEN '100' then 'GSDCLNT100'
*                                        WHEN '110' then 'GSDCLNT100'
*                                        WHEN '120' then 'GSDCLNT100'
*                                        WHEN '130' then 'GSDCLNT100' )
          ).

        FINAL(lo_client) = cl_web_http_client_manager=>create_by_http_destination( lo_http ).

        lo_client->get_http_request( )->set_uri_path( '/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV/?$format=json' ).
        FINAL(lo_response) = lo_client->execute( i_method = if_web_http_client=>get ).

        out->write( lo_response->get_status( ) ).
        out->write( lo_response->get_text( ) ).

      CATCH
        zcx_t2_outbound_provider_http
        cx_web_http_client_error
        INTO FINAL(lx_error).
        out->write( lx_error->get_text( ) ).
    ENDTRY.

  ENDMETHOD.

ENDCLASS.
