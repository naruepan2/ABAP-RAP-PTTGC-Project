@AbapCatalog.viewEnhancementCategory: [ #NONE ]

@AccessControl.authorizationCheck: #NOT_REQUIRED

@EndUserText.label: 'YI_DEMO_Country001'

@Metadata.ignorePropagatedAnnotations: true

define root view entity YI_DEMO_Country001
  as select from I_Country

{
  key Country,

      CountryThreeLetterISOCode,
      CountryThreeDigitISOCode,
      CountryISOCode,
      IsEuropeanUnionMember,
      BankAndBankInternalIDCheckRule,
      BankInternalIDLength,
      BankInternalIDCheckRule,
      BankNumberLength,
      BankCheckRule,
      BankAccountLength,
      BankPostalCheckRule,
      BankDataCheckIsCountrySpecific,
      CountryCurrency,
      IndexBasedCurrency,
      HardCurrency,
      TaxCalculationProcedure,
      CountryAlternativeCode,

      /* Associations */
      _Text
}
