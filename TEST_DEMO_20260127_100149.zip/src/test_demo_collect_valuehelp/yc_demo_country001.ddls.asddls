@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'YC_DEMO_COUNTRY001'
@Metadata.ignorePropagatedAnnotations: true

define root view entity YC_DEMO_COUNTRY001
  provider contract transactional_query
  as projection on YI_DEMO_Country001
{

      @Consumption.valueHelpDefinition: [{ entity: { name: 'YSM_ABSTRACT_CDS_ENTITY', element: 'Country' } }]
      @UI.lineItem: [{ position: 10 }]
      @UI.selectionField: [{ position: 10 }]
  key Country,
      @UI.lineItem: [{ position: 20 }]
      CountryThreeLetterISOCode,
      @UI.lineItem: [{ position: 30 }]
      CountryThreeDigitISOCode,
      @UI.lineItem: [{ position: 40 }]
      CountryISOCode,
      @UI.lineItem: [{ position: 50 }]
      IsEuropeanUnionMember,
      @UI.lineItem: [{ position: 60 }]
      BankAndBankInternalIDCheckRule,
      @UI.lineItem: [{ position: 70 }]
      BankInternalIDLength,
      @UI.lineItem: [{ position: 80 }]
      BankInternalIDCheckRule,
      @UI.lineItem: [{ position: 90 }]
      BankNumberLength,
      @UI.lineItem: [{ position: 100 }]
      BankCheckRule,
      BankAccountLength,
      BankPostalCheckRule,
      BankDataCheckIsCountrySpecific,
      CountryCurrency,
      IndexBasedCurrency,
      HardCurrency,
      TaxCalculationProcedure,
      CountryAlternativeCode,
      /* Associations */
      _Text
}
