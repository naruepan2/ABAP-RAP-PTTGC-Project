@EndUserText.label: 'Abstract entity'

@ObjectModel.collectiveValueHelp.for.element: 'Country'
//@ObjectModel.supportedCapabilities: [ #COLLECTIVE_VALUE_HELP ]
define abstract entity YSM_ABSTRACT_CDS_ENTITY

{
  @Consumption.valueHelpDefinition: [ { entity: { name: 'I_CountryVH', element: 'Country' },
                                        label: 'Search by Country' },
                                      { entity: { name: 'I_RegionVH', element: 'Country' },
                                        additionalBinding: [ { localElement: 'Region', element: 'Region' } ],
                                        label: 'Search by Region',
                                        qualifier: 'Regionsearch' } ]
  Country : land1;

  Region  : regio;
}
