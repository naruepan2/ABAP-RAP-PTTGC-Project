*&---------------------------------------------------------------------*
*& Report yemail_with_table
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT yemail_with_table.

PARAMETERS:
 p_to TYPE string OBLIGATORY DEFAULT 'zNakkarin.K@pttgcgroup.com'.

CLASS lcl_main DEFINITION.
  PUBLIC SECTION.
    METHODS process.

  PRIVATE SECTION.
    TYPES:
      BEGIN OF gty_email_hd1,
        vendor     TYPE string,
        vend_rate  TYPE string,
        period     TYPE string,
        planning   TYPE string,
        rate_limit TYPE string,
        pounit     TYPE string,
        poamt      TYPE netwr,
      END OF gty_email_hd1,

      BEGIN OF gty_email_it1,
        pono  TYPE ebeln,
        poqty TYPE string,
      END OF gty_email_it1,

      BEGIN OF gty_email_it2,
        userid   TYPE string,
        username TYPE string,
      END OF gty_email_it2,


      BEGIN OF gty_email_data1,
        head   TYPE gty_email_hd1,
        t_item TYPE TABLE OF gty_email_it1 WITH DEFAULT KEY,
        t_name TYPE TABLE OF gty_email_it2 WITH DEFAULT KEY,
      END OF gty_email_data1.

    DATA: gs_email TYPE  gty_email_data1.
ENDCLASS.

CLASS lcl_main IMPLEMENTATION.

  METHOD process.

    DATA lt_recipient TYPE zcl_ext_email_utilities=>tt_mail_recipient.
    gs_email = VALUE #( head = VALUE #( vendor     = '123'
                                        rate_limit = '100'
                                        pounit     = 'TON'
                                        poamt      = '123.00'
                                      )
                        t_item = VALUE #( ( pono = '1234'
                                            poqty = |{ 100 NUMBER = ENVIRONMENT }| )
                                           ( pono = '2222'
                                            poqty = |{ 3000 NUMBER = ENVIRONMENT }| )
                                           )
                        t_name = VALUE #( ( userid = 'Z00123'
                                            username = 'Name1' )
                                           ( userid = 'Z002222'
                                            username = 'Name2' )
                                         )
                      ).

    TRY.
        DATA(ls_emailconf) = zcl_ext_email_config=>get_instance(
                          iv_program = 'xxx' )->get_email_config( ).
      CATCH zcx_ext_general_error.
        "handle exception
    ENDTRY.
    ls_emailconf-emailtmplid  = 'YDEMO_TEMPTAB1'.

    DATA(lo_email) = zcl_ext_email_utilities=>create_instance( ).
    lo_email->get_email_template_subj_body( EXPORTING iv_template_id  = ls_emailconf-emailtmplid
                                               IMPORTING ev_subject   = DATA(lv_subject)
                                                         ev_body_html = DATA(lv_body) ).
    lo_email->replace_var_with_data(
      EXPORTING iw_data = gs_email-head
      CHANGING cv_text = lv_subject ).

    lo_email->replace_var_with_data(
      EXPORTING iw_data = gs_email-head
      CHANGING cv_text = lv_body ).

    lo_email->replace_hmlt_tr_tag_with_data(
      EXPORTING it_data = gs_email-t_item
        iv_elemid_tr = 'ITEMS'
      CHANGING  cv_text = lv_body ).

    lo_email->replace_hmlt_tr_tag_with_data(
      EXPORTING it_data = gs_email-t_name
      iv_elemid_tr = 'NAMES'
      CHANGING  cv_text = lv_body ).

    lt_recipient = VALUE #( BASE lt_recipient
                            ( address = p_to )
                          ).

    ls_emailconf-sender = 'no-reply@dev-pttgcgroup.com'.
    lo_email->send_email( EXPORTING iv_address         = CONV #( ls_emailconf-sender )
                                    iv_subject         = CONV #( lv_subject )
                                    it_recipient       = lt_recipient
                                    it_body            = VALUE #( ( content = lv_body content_type = lo_email->c_attachment_content_type-text_html ) )
                                    iv_commit_work     = abap_on
*                                    iv_set_background  = iv_set_background
*                                    iv_encoding        = iv_encoding
                          IMPORTING et_status          = DATA(lt_status)
                                        ev_mail_status     = DATA(lv_mail_status)
                                        ev_msg             = DATA(lv_msg)
                                        ev_msg_longtext    = DATA(lv_msg_longtext)
                                         ).
  ENDMETHOD.

ENDCLASS.

START-OF-SELECTION.
  NEW lcl_main( )->process( ).
