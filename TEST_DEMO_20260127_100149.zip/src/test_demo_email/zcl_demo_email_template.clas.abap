CLASS zcl_demo_email_template DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_oo_adt_classrun .
  PROTECTED SECTION.
  PRIVATE SECTION.

    DATA lo_main_out  TYPE REF TO if_oo_adt_classrun_out .
    METHODS get_content_mail_template.
    METHODS get_content_mail_template_cds.
    METHODS get_send_email.

ENDCLASS.



CLASS zcl_demo_email_template IMPLEMENTATION.


  METHOD if_oo_adt_classrun~main.
    lo_main_out = out .

*    get_content_mail_template(  ) .
*    get_content_mail_template_cds(  ) .
    get_send_email(  ) .

  ENDMETHOD.


  METHOD get_content_mail_template.


    DATA(lo_email) = zcl_ext_email_utilities=>create_instance( ).

    lo_email->set_placeholder(
      iv_placeholder_name  = '&USER_FIRST_NAME&'
      iv_placeholder_value = 'Wawowwwwwwwwwwwww'
    ).

    SELECT FROM I_CompanyCode
      FIELDS CompanyCode, CompanyCodeName
      INTO TABLE @DATA(lt_data)
      UP TO 10 ROWS  .

    lo_email->set_placeholder_itab(
      iv_placeholder_name  = '&DATA_TAB&'
      it_placeholder_value = lt_data
      it_column_text       = VALUE #( ( fieldname = 'COMPANYCODE'     col_text = 'Company Code' )
                                      ( fieldname = 'COMPANYCODENAME' col_text = 'Company Name' )
                                    )
    ).

    lo_email->get_email_template_subj_body(
        EXPORTING
         iv_template_id   = 'YET_DEMO01'
          IMPORTING
            ev_subject   = DATA(lv_subject)
            ev_body_html = DATA(lv_body_html)
            ev_body_text = DATA(lv_body_text)
           ).

    DATA(lv_string) =
      |**********************************************************************{ cl_abap_char_utilities=>cr_lf }| &&
      |           Get Email Template "YET_DEMO01"           { cl_abap_char_utilities=>cr_lf }| &&
      |**********************************************************************{ cl_abap_char_utilities=>cr_lf }| &&
      |SUBJECT: { lv_subject } { cl_abap_char_utilities=>cr_lf }| &&
      |BODY HTML: { cl_abap_char_utilities=>cr_lf }{ lv_body_html }| &&
      |BODY TEXT: { cl_abap_char_utilities=>cr_lf }{ lv_body_text }| .
    lo_main_out->write( lv_string ).

  ENDMETHOD.


  METHOD get_content_mail_template_cds.

    DATA(lo_email) = zcl_ext_email_utilities=>create_instance( ).

    lo_email->get_email_template_subj_body(
        EXPORTING
         iv_template_id   = 'YET_DEMO_CDS'
         it_data_key      = VALUE #( ( name =  'COMPANYCODE' value = 'AE01' )  )
          IMPORTING
            ev_subject   = DATA(lv_subject)
            ev_body_html = DATA(lv_body_html)
            ev_body_text = DATA(lv_body_text)
           ).

    DATA(lv_string) =
      |**********************************************************************{ cl_abap_char_utilities=>cr_lf }| &&
      |           Get Email Template "YET_DEMO_CDS" (I_COMPANYCODE)           { cl_abap_char_utilities=>cr_lf }| &&
      |**********************************************************************{ cl_abap_char_utilities=>cr_lf }| &&
      |SUBJECT: { lv_subject } { cl_abap_char_utilities=>cr_lf }| &&
      |BODY HTML: { cl_abap_char_utilities=>cr_lf }{ lv_body_html }| &&
      |BODY TEXT: { cl_abap_char_utilities=>cr_lf }{ lv_body_text }| .
    lo_main_out->write( lv_string ).

  ENDMETHOD.


  METHOD get_send_email.


    DATA(lo_email) = zcl_ext_email_utilities=>create_instance( ).

    lo_email->set_placeholder(
      iv_placeholder_name  = '&USER_FIRST_NAME&'
      iv_placeholder_value = 'Wawowwwwwwwwwwwww'
    ).

    SELECT FROM I_CompanyCode
      FIELDS CompanyCode, CompanyCodeName
      INTO TABLE @DATA(lt_data)
      UP TO 10 ROWS  .

    lo_email->set_itab_to_html_styles(
*      iv_table_id    =
*      iv_table_class =
      iv_table_style = 'border: 1px solid; cellpadding: 4px ; cellspacing: 0px ; border-collapse:collapse;'
*      iv_tr_class    =
      iv_tr_style    = ''
*      iv_th_class    =
      iv_th_style    = 'background-color:#f2f2f2; border: 1px solid;'
*      iv_td_class    =
      iv_td_style    = 'border: 1px solid;'
    ).

    lo_email->set_placeholder_itab(
      iv_placeholder_name  = '&DATA_TAB&'
      it_placeholder_value = lt_data
      it_column_text       = VALUE #( ( fieldname = 'COMPANYCODE'     col_text = 'Company Code' )
                                      ( fieldname = 'COMPANYCODENAME' col_text = 'Company Name' )
                                    )
    ).

    lo_email->get_email_template_subj_body(
        EXPORTING
         iv_template_id   = 'YET_DEMO01'
          IMPORTING
            ev_subject   = DATA(lv_subject)
            ev_body_html = DATA(lv_body_html)
            ev_body_text = DATA(lv_body_text)
           ).

    lo_email->send_email(
      EXPORTING
        iv_address          = 'test@pttgcgroup.com'
        iv_subject          = conv #( lv_subject )
        it_recipient        = VALUE #( ( address = 'SAP_EXT@dev-pttgcgroup.com' ) )
*        it_mail_attachment  =
        it_body             = VALUE #( ( content = lv_body_html content_type = lo_email->c_attachment_content_type-text_html ) )
        iv_send_async       = space
*        iv_commit_work      = space
*        iv_set_background   = space
*        iv_encoding         =
*        iv_with_email_templ = space
*        io_email_template   =
*        iv_template_id      =
*        is_email_template   =
*        iv_language         =
*        it_data_key         =
      IMPORTING
        et_status           = DATA(lt_status)
        ev_mail_status      = DATA(lv_status)
        ev_msg              = DATA(lv_msg)
        ev_msg_longtext     = DATA(lv_msg_longtext)
    ).

  ENDMETHOD.

ENDCLASS.
