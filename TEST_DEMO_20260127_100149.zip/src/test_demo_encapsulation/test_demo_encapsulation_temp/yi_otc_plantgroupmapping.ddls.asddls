@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Plant Group Mapping'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
  serviceQuality: #X,
  sizeCategory: #S,
  dataClass: #MIXED
}
// Temp only; for tesing
define view entity YI_OTC_PlantGroupMapping
  as select from ZR_OTC_PlantGroupMappingTP
{
  key Werks    as Plant,
      PlantGrp as PlantGroup
}
