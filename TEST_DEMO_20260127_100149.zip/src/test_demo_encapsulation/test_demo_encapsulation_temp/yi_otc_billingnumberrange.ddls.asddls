@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Billing Number Range'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
  serviceQuality: #X,
  sizeCategory: #S,
  dataClass: #MIXED
}
define view entity YI_OTC_BillingNumberRange
  as select from ZR_OTC_BillingNumberRangeTP
{
  key Object,
  key Bukrs    as Companycode,
  key Spart    as Division,
  key BillGrp  as BillingGroup,
  key Mwskz    as TaxCode,
  key PlantGrp as PlantGroup,
      Cndn     as CnDn,
      Nrrange  as NumberRange
}
