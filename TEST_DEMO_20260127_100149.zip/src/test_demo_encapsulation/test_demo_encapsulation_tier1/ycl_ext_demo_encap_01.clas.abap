CLASS ycl_ext_demo_encap_01 DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    TYPES:
      BEGIN OF ty_billing,
        billingdocument TYPE i_billingdocument-billingdocument,
        companycode     TYPE i_billingdocument-companycode,
        division        TYPE i_billingdocument-division,
        totalnetamount  TYPE i_billingdocument-totalnetamount,
      END OF ty_billing,
      BEGIN OF ty_billingitem,
        billingdocument     TYPE i_billingdocumentitem-billingdocument,
        billingdocumentitem TYPE i_billingdocumentitem-billingdocumentitem,
        plant               TYPE i_billingdocumentitem-plant,
      END OF ty_billingitem,
      tt_billingitems TYPE SORTED TABLE OF ty_billingitem WITH NON-UNIQUE KEY billingdocument,
      BEGIN OF ty_pricing,
        salesdocumentcondition TYPE i_salesdocument-salesdocumentcondition,
        conditionclass         TYPE i_salesdocumentpricingelement-conditionclass,
        taxcode                TYPE i_salesdocumentpricingelement-taxcode,
      END OF ty_pricing,
      tt_pricing TYPE STANDARD TABLE OF ty_pricing WITH EMPTY KEY.

    CLASS-METHODS determine_tax_number_range
      IMPORTING
        iv_nrintnumber  TYPE numki OPTIONAL
        is_billing      TYPE ty_billing OPTIONAL
        it_billingitems TYPE tt_billingitems OPTIONAL
        it_pricing      TYPE tt_pricing OPTIONAL
      EXPORTING
        ev_numberrange  TYPE cl_numberrange_runtime=>nr_interval.

  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ycl_ext_demo_encap_01 IMPLEMENTATION.


  METHOD determine_tax_number_range.

    DATA: lv_plantgroup TYPE yi_otc_billingnumberrange-plantgroup.
    CONSTANTS: lc_d      TYPE c LENGTH 1 VALUE 'D',
               lc_iq     TYPE numki VALUE '1Q',
               lc_object TYPE cl_numberrange_runtime=>nr_object VALUE 'RV_BELEG',
               lc_cn     TYPE yi_otc_billingnumberrange-cndn VALUE 'CN',
               lc_dn     TYPE yi_otc_billingnumberrange-cndn VALUE 'DN'.

    "Get tax code of the billing document
    READ TABLE it_pricing INTO FINAL(ls_komv)
      WITH KEY  conditionclass          = lc_d
                salesdocumentcondition  = is_billing-billingdocument.

    "Get first item
    READ TABLE it_billingitems ASSIGNING FIELD-SYMBOL(<lfs_vbrp>)
      WITH TABLE KEY billingdocument = is_billing-billingdocument.
    IF sy-subrc EQ 0.

      "Get plant group
      SELECT SINGLE FROM yi_otc_plantgroupmapping
        FIELDS
          plantgroup
        WHERE plant = @<lfs_vbrp>-plant
        INTO @lv_plantgroup.
      IF sy-subrc EQ 0.

        IF iv_nrintnumber = lc_iq.

          IF is_billing-totalnetamount < 0.

            SELECT SINGLE FROM yi_otc_billingnumberrange
              FIELDS
                numberrange
              WHERE object        = @lc_object
                AND companycode   = @is_billing-companycode
                AND division      = @is_billing-division
                AND billinggroup  = @iv_nrintnumber
                AND taxcode       = @ls_komv-taxcode
                AND plantgroup    = @lv_plantgroup
                AND cndn          = @lc_cn
              INTO @ev_numberrange.
            IF sy-subrc NE 0.

              SELECT SINGLE FROM yi_otc_billingnumberrange
                FIELDS
                  numberrange
                WHERE object        = @lc_object
                  AND companycode   = @is_billing-companycode
                  AND division      = @is_billing-division
                  AND billinggroup  = @iv_nrintnumber
                  AND taxcode       = @space
                  AND plantgroup    = @lv_plantgroup
                  AND cndn          = @lc_cn
                INTO @ev_numberrange.
            ENDIF.

          ELSEIF is_billing-totalnetamount > 0.

            SELECT SINGLE FROM yi_otc_billingnumberrange
              FIELDS
                numberrange
              WHERE object        = @lc_object
                AND companycode   = @is_billing-companycode
                AND division      = @is_billing-division
                AND billinggroup  = @iv_nrintnumber
                AND taxcode       = @ls_komv-taxcode
                AND plantgroup    = @lv_plantgroup
                AND cndn          = @lc_dn
              INTO @ev_numberrange.
            IF sy-subrc NE 0.

              SELECT SINGLE FROM yi_otc_billingnumberrange
                FIELDS
                  numberrange
                WHERE object        = @lc_object
                  AND companycode   = @is_billing-companycode
                  AND division      = @is_billing-division
                  AND billinggroup  = @iv_nrintnumber
                  AND taxcode       = @space
                  AND plantgroup    = @lv_plantgroup
                  AND cndn          = @lc_dn
                INTO @ev_numberrange.

            ENDIF.
          ENDIF.

        ELSE.

          SELECT SINGLE FROM yi_otc_billingnumberrange
            FIELDS
              numberrange
            WHERE object        = @lc_object
              AND companycode   = @is_billing-companycode
              AND division      = @is_billing-division
              AND billinggroup  = @iv_nrintnumber
              AND taxcode       = @ls_komv-taxcode
              AND plantgroup    = @lv_plantgroup
            INTO @ev_numberrange.
          IF sy-subrc NE 0.

            SELECT SINGLE FROM yi_otc_billingnumberrange
              FIELDS
                numberrange
              WHERE object        = @lc_object
                AND companycode   = @is_billing-companycode
                AND division      = @is_billing-division
                AND billinggroup  = @iv_nrintnumber
                AND taxcode       = @space
                AND plantgroup    = @lv_plantgroup
              INTO @ev_numberrange.

          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
