*&---------------------------------------------------------------------*
*& Report yr_ext_demo_encap_01
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT yr_ext_demo_encap_01.

TABLES:
  vbak,
  vbap,
  tvfk.

TYPES:
  ty_vbak TYPE vbak,
  ty_vbap TYPE vbap,
  tt_vbak TYPE STANDARD TABLE OF ty_vbak WITH EMPTY KEY,
  tt_vbap TYPE STANDARD TABLE OF ty_vbap WITH EMPTY KEY.

DATA:
  xkomv TYPE STANDARD TABLE OF komv WITH DEFAULT KEY,
  xvbrk TYPE vbrkvb,
  xvbrp TYPE STANDARD TABLE OF vbrpvb WITH DEFAULT KEY,
  xvbak TYPE tds_xvbak,
  xvbap TYPE STANDARD TABLE OF vbapvb WITH DEFAULT KEY.


*SELECT-OPTIONS:
*  s_vbeln FOR vbak-vbeln OBLIGATORY.

START-OF-SELECTION.
*
*  SELECT FROM


  CALL METHOD ycl_ext_demo_encap_01=>determine_tax_number_range
    EXPORTING
      iv_nrintnumber  = tvfk-numki
      is_billing      = CORRESPONDING #( xvbrk
                          MAPPING
                            billingdocument  = vbeln
                            companycode      = bukrs
                            division         = spart
                            totalnetamount   = netwr )
      it_billingitems = CORRESPONDING #( xvbrp
                          MAPPING
                            billingdocument     = vbeln
                            billingdocumentitem = posnr
                            plant               = werks )
      it_pricing      = CORRESPONDING #( xkomv
                          MAPPING
                            conditionclass          = koaid
                            salesdocumentcondition  = knumv
                            taxcode                 = mwsk1 )
    IMPORTING
*      ev_numberrange = us_range_intern.
      ev_numberrange = FINAL(lv_nrnr).
