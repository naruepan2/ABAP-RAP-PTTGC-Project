CLASS ycl_demo_cvi_ei_adapter DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.

    CLASS-METHODS cvi_start_inbound_main_single
      IMPORTING is_creditmanagementaccount TYPE ukm_s_formula_account
      EXPORTING et_messages                TYPE bapiretct.

    CLASS-METHODS cvi_update_businesspartner
      IMPORTING is_data   TYPE zcl_t2_cvi_ei_adapter=>ts_cvis_ei_extern OPTIONAL
                iv_commit TYPE abap_boolean                             OPTIONAL
      EXPORTING es_return TYPE zcl_t2_cvi_ei_adapter=>ts_bapiretc.
ENDCLASS.


CLASS ycl_demo_cvi_ei_adapter IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.
    ycl_demo_cvi_ei_adapter=>cvi_start_inbound_main_single(
      EXPORTING is_creditmanagementaccount = VALUE ukm_s_formula_account( partner = '0068100001' )
      IMPORTING et_messages                = DATA(lt_messages) ).

    IF NOT ( line_exists( lt_messages[ type = 'E' ] ) OR line_exists( lt_messages[ type = 'A' ] ) ).
      COMMIT WORK.
    ENDIF.

    out->write( lt_messages ).
  ENDMETHOD.

  METHOD cvi_start_inbound_main_single.
    DATA ls_data TYPE zcl_t2_cvi_ei_adapter=>ts_cvis_ei_extern.

    SELECT SINGLE FROM I_BusinessPartnerTP_3
      FIELDS BusinessPartnerUUID
      WHERE BusinessPartner = @is_creditmanagementaccount-partner
      INTO @FINAL(lv_businesspartneruuid).

    ls_data-partner-header = VALUE #( object_task                  = 'U'
                                      object_instance-bpartner     = is_creditmanagementaccount-partner
                                      object_instance-bpartnerguid = lv_businesspartneruuid ).

*    ls_data-partner-finserv_data-ratings-current_state = abap_true.
    ls_data-partner-finserv_data-ratings-ratings = VALUE #(
        ( task     = 'M'
          data_key = VALUE #( date_to      = cl_abap_context_info=>get_system_date( ) + 365
                              grade_method = 'SAP_BAFIN' )
          data     = VALUE #( date_from  = cl_abap_context_info=>get_system_date( )
                              flg_permit = abap_true
                              grade      = 'SAP_IG' "'SAP_DR'
                              date_when  = cl_abap_context_info=>get_system_date( ) )
          datax    = VALUE #( date_from  = abap_true
                              flg_permit = abap_true
                              grade      = abap_true
                              date_when  = abap_true
                             ) ) ).

    zcl_t2_cvi_ei_adapter=>start_inbound_main_single( EXPORTING is_data     = ls_data
                                                      IMPORTING et_messages = et_messages ).
  ENDMETHOD.

  METHOD cvi_update_businesspartner.
    TYPES: BEGIN OF lty_input_data,
             businesspartner TYPE kunnr,
             creditrule      TYPE ukm_limit_rule,
             creditscore     TYPE ukm_own_rating,
             ratingprocedure TYPE bp_grade_method,
             rating          TYPE bp_grade_method,
           END OF lty_input_data.

    DATA ls_data       TYPE zcl_t2_cvi_ei_adapter=>ts_cvis_ei_extern.

    DATA ls_input_data TYPE lty_input_data.

    ls_input_data = CORRESPONDING #( DEEP is_data ).

    IF ls_input_data IS INITIAL.
      RETURN.
    ENDIF.

    SELECT SINGLE FROM I_BusinessPartnerTP_3
      FIELDS BusinessPartnerUUID
      WHERE BusinessPartner = @ls_input_data-BusinessPartner
      INTO @FINAL(lv_businesspartneruuid).

    ls_data-partner-header = VALUE #( object_task                  = 'U'
                                      object_instance-bpartner     = ls_input_data-businesspartner
                                      object_instance-bpartnerguid = lv_businesspartneruuid ).

    ls_data-partner-ukmbp_data-profile = VALUE #( data  = VALUE #( limit_rule = ls_input_data-creditrule
                                                                   own_rating = ls_input_data-creditscore
*                                                                   own_rating_calc = ls_input_data-creditscore
                                                                 )
                                                  datax = VALUE #( limit_rule = abap_true
                                                                   own_rating = abap_true
*                                                                   own_rating_calc = abap_true
                                                                 ) ).

*    ls_data-partner-finserv_data-ratings-current_state = abap_true.
    ls_data-partner-finserv_data-ratings-ratings = VALUE #(
        ( task     = 'I'
          data_key = VALUE #( date_to      = cl_abap_context_info=>get_system_date( ) + 365
                              grade_method = ls_input_data-ratingprocedure )
          data     = VALUE #( date_from  = cl_abap_context_info=>get_system_date( )
                              flg_permit = abap_true
                              grade      = ls_input_data-rating
                              date_when  = cl_abap_context_info=>get_system_date( ) )
          datax    = VALUE #( date_from  = abap_true
                              flg_permit = abap_true
                              grade      = abap_true
                              date_when  = abap_true ) ) ).

    zcl_t2_cvi_ei_adapter=>start_inbound_main_single( EXPORTING is_data     = ls_data
                                                      IMPORTING et_messages = DATA(lt_messages) ).

    LOOP AT lt_messages INTO DATA(ls_messages) WHERE type CA 'EAX'.
      EXIT.
    ENDLOOP.
    IF sy-subrc = 0.
      es_return = VALUE #( type    = ls_messages-type
                           message = ls_messages-message ).
    ELSE.
      IF iv_commit IS NOT INITIAL.
        COMMIT WORK AND WAIT.
      ENDIF.

      READ TABLE lt_messages INTO ls_messages WITH KEY type = 'S'.
      IF sy-subrc = 0.
        es_return = VALUE #( type    = ls_messages-type
                             message = ls_messages-message ).
      ENDIF.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
