@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Test'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YR_TEST3
  as select from I_SalesOrder
    inner join   I_SalesOrderItem on I_SalesOrder.SalesOrder = I_SalesOrderItem.SalesOrder
    inner join   YR_TEST2         on  YR_TEST2.SalesOrder     = I_SalesOrderItem.SalesOrder
                                  and YR_TEST2.SalesOrderItem = I_SalesOrderItem.SalesOrderItem
{
  key I_SalesOrder.SalesOrder         as SalesOrder,
      sum( YR_TEST2.NonC )            as NonC
}
group by
  I_SalesOrder.SalesOrder
having
  sum( YR_TEST2.NonC ) = 0
