@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Test'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YR_TEST2
  as select from I_SalesOrder
    inner join   I_SalesOrderItem               on I_SalesOrder.SalesOrder = I_SalesOrderItem.SalesOrder
    inner join   I_SDDocumentMultiLevelProcFlow on  I_SDDocumentMultiLevelProcFlow.PrecedingDocument          = I_SalesOrderItem.SalesOrder
                                                and I_SDDocumentMultiLevelProcFlow.PrecedingDocumentItem      = I_SalesOrderItem.SalesOrderItem
                                                and I_SDDocumentMultiLevelProcFlow.PrecedingDocumentCategory  = 'C'
                                                and I_SDDocumentMultiLevelProcFlow.SubsequentDocumentCategory = 'J'
    inner join   I_DeliveryDocument             on I_DeliveryDocument.DeliveryDocument = I_SDDocumentMultiLevelProcFlow.SubsequentDocument
    inner join   I_DeliveryDocumentItem         on  I_DeliveryDocumentItem.DeliveryDocument     = I_SDDocumentMultiLevelProcFlow.SubsequentDocument
                                                and I_DeliveryDocumentItem.DeliveryDocumentItem = I_SDDocumentMultiLevelProcFlow.SubsequentDocumentItem
{
  key I_SalesOrder.SalesOrder                                                                                                                          as SalesOrder,
  key I_SalesOrderItem.SalesOrderItem                                                                                                                  as SalesOrderItem,
      sum( case when I_DeliveryDocument.OverallGoodsMovementStatus <> 'C' or I_DeliveryDocument.OverallGoodsMovementStatus is null then 1 else 0 end ) as NonC
}
where
      I_SalesOrder.OverallTotalDeliveryStatus         = 'C'
  and I_DeliveryDocumentItem.OriginalDeliveryQuantity is not initial
group by
  I_SalesOrder.SalesOrder,
  I_SalesOrderItem.SalesOrderItem    
//having sum( case when I_DeliveryDocument.OverallGoodsMovementStatus <> 'C' or I_DeliveryDocument.OverallGoodsMovementStatus is null then 1 else 0 end ) = 0
