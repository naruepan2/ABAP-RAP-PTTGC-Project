@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Test'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YR_Test
  as select from I_DeliveryDocumentItem
{
  key I_DeliveryDocumentItem.DeliveryDocument         as DeliveryDocument,
  key I_DeliveryDocumentItem.DeliveryDocumentItem     as DeliveryDocumentItem,
  key I_DeliveryDocumentItem.Product                  as Product,
  key I_DeliveryDocumentItem.Batch                    as Batch,
      @Semantics.quantity.unitOfMeasure: 'Unit'
      I_DeliveryDocumentItem.OriginalDeliveryQuantity as Quantity,
      I_DeliveryDocumentItem.DeliveryQuantityUnit     as Unit
}
