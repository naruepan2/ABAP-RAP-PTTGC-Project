@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Test'
@Metadata.ignorePropagatedAnnotations: true
@Metadata.allowExtensions: true
define root view entity YC_Test
  provider contract transactional_query
  as projection on YR_Test
{
  @Search.defaultSearchElement: true
  key     DeliveryDocument,
  key     DeliveryDocumentItem,
  key     Product,
  key     Batch,
  @Aggregation.default: #SUM
  @Semantics.quantity.unitOfMeasure: 'Unit'
          Quantity,
          Unit
}
