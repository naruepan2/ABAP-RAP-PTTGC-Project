@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'API: 001'
@ObjectModel.semanticKey: [ 'FiscalYearPeriod', 'Plant', 'Material', 'IssuingOrReceivingPlant', 'IssgOrRcvgMaterial' ]

//@Metadata.ignorePropagatedAnnotations: true
define root view entity YA_EXT_DemoAPI_001
  provider contract transactional_query
  as projection on YI_EXT_DemoMDX01_Cube
{
  key FiscalYearPeriod,
  key Plant,
      @AnalyticsDetails.query.axis: #COLUMNS
  key Material,
  key IssuingOrReceivingPlant,
  key IssgOrRcvgMaterial,
      FiscalYearVariant,
      CompanyCodeCurrency,
      MaterialBaseUnit,
      FiscalYear,
      @DefaultAggregation: #SUM
      GoodsMovementStkAmtInCCCrcy,
      MatlStkChangeQtyInBaseUnit,
      /* Associations */
      _Currency,
      _IssgOrRcvgMaterial,
      _IssuingOrReceivingPlant,
      _Material,
      _MaterialBaseUnit,
      _Plant,
      _Product,
      _ProductPlant
}
