class ZRAP100_BP_TRAVELTP_001 definition
  public
  abstract
  final
  for behavior of ZRAP100_R_TRAVELTP_001 .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZRAP100_BP_TRAVELTP_001 IMPLEMENTATION.
ENDCLASS.
