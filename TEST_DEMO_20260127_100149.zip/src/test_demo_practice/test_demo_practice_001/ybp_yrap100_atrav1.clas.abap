class YBP_YRAP100_ATRAV1 definition
  public
  abstract
  final
  for behavior of YR_YRAP100_ATRAV1 .

public section.
protected section.
private section.
ENDCLASS.



CLASS YBP_YRAP100_ATRAV1 IMPLEMENTATION.
ENDCLASS.
