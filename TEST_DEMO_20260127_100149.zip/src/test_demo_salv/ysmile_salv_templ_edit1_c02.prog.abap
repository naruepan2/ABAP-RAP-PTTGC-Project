*&---------------------------------------------------------------------*
*& Include          YNDBS_SALV_TEMPLATE_C02
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& ALV Events Class
*&---------------------------------------------------------------------*
CLASS lcl_salv_events DEFINITION.
  PUBLIC SECTION.

    INTERFACES if_salv_gui_om_edit_strct_lstr.
    INTERFACES if_salv_gui_toolbar_listener.
    INTERFACES if_salv_gui_om_ctxt_menu_lstr.

    METHODS constructor
      IMPORTING io_view TYPE REF TO lcl_salv OPTIONAL
                io_main TYPE REF TO lcl_main OPTIONAL.
* Event Handler for HOTSPOT event
    METHODS: on_link_click_handler
      FOR EVENT link_click OF cl_salv_events_table
      IMPORTING row column.
* Event Handler for DOUBLE-CLICK event
    METHODS on_double_click_handler
      FOR EVENT double_click OF cl_salv_events_table
      IMPORTING row column.
* Event Handler for Custom User Command event
    METHODS on_user_command_handler
      FOR EVENT added_function OF cl_salv_events_table
      IMPORTING e_salv_function.
* Event Handler for Control Before Execution of a Generic ALV Function
    METHODS on_before_function_handler
      FOR EVENT before_salv_function OF cl_salv_events_table
      IMPORTING e_salv_function.
* Event Handler for Control After Execution of a Generic ALV Function
    METHODS on_after_function_handler
      FOR EVENT after_salv_function OF cl_salv_events_table
      IMPORTING e_salv_function.

  PRIVATE SECTION.

    DATA mo_view TYPE REF TO lcl_salv.
    DATA mo_main TYPE REF TO lcl_main.
    DATA mo_grid TYPE REF TO cl_gui_alv_grid.

    METHODS _set_register_modified
      RETURNING VALUE(ro_lcl_events) TYPE REF TO lcl_salv_events.

ENDCLASS.

*&---------------------------------------------------------------------*
*& ALV Class for Display
*&---------------------------------------------------------------------*
CLASS lcl_salv DEFINITION FINAL.

  PUBLIC SECTION.
    METHODS display_alv.
    METHODS refresh_alv
      IMPORTING is_stable         TYPE lvc_s_stbl OPTIONAL
                iv_set_all_stable TYPE flag OPTIONAL
                iv_refresh_mode   TYPE salv_de_constant DEFAULT if_salv_c_refresh=>soft.
    METHODS get_salv_table
      RETURNING VALUE(ro_salv) TYPE REF TO cl_salv_table.
    METHODS get_events
      RETURNING VALUE(ro_events) TYPE REF TO lcl_salv_events.

  PRIVATE SECTION.

    DATA mo_salv TYPE REF TO cl_salv_table.
    DATA mo_extended_grid_api TYPE REF TO if_salv_gui_om_extend_grid_api.
    DATA mo_events TYPE REF TO lcl_salv_events.

    DATA mv_is_set_edit_listener TYPE abap_boolean.

    METHODS _set_pf_status
      IMPORTING iv_report        TYPE syrepid DEFAULT sy-repid
                iv_pfstatus      TYPE sypfkey OPTIONAL
                iv_set_functions TYPE salv_de_constant DEFAULT cl_salv_model_base=>c_functions_all.
    METHODS _set_pf_title.
    METHODS _set_layout.
    METHODS _set_top_end_of_page.
    METHODS _set_display_setting.
    METHODS _set_columns.
    METHODS _set_technical_columns.
    METHODS _set_technical_client.
    METHODS _modify_columns
      IMPORTING io_columns TYPE REF TO cl_salv_columns_table.
    METHODS _set_events.
    METHODS _set_aggregations.
    METHODS _set_filters.
    METHODS _set_sorts.
    METHODS _set_screen_popup.
    METHODS _set_extended_grid_api.
    METHODS _set_editable_column
      IMPORTING iv_columnname              TYPE lvc_fname
                iv_drop_down_columnname    TYPE lvc_fname OPTIONAL
                is_register_f4_help        TYPE if_salv_gui_om_edit_restricted=>ys_f4_help_attributes OPTIONAL
                iv_urge_foreign_key_check  TYPE abap_bool DEFAULT abap_false
                iv_all_cells_input_enabled TYPE abap_bool DEFAULT abap_true.
    METHODS _set_editable_dummy_cellstyle
      RETURNING VALUE(ro_editable) TYPE REF TO if_salv_gui_om_edit_restricted .

ENDCLASS.

*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& ALV Events Class for Display Implementation
*&---------------------------------------------------------------------*
CLASS lcl_salv_events IMPLEMENTATION.
  METHOD constructor.
    mo_view = COND #( WHEN io_view IS BOUND THEN io_view ELSE mo_view ).
    mo_main = COND #( WHEN io_main IS BOUND THEN io_main ELSE mo_main ).
  ENDMETHOD.

  METHOD on_link_click_handler.
  ENDMETHOD.

  METHOD on_double_click_handler.
  ENDMETHOD.

  METHOD on_user_command_handler.
  ENDMETHOD.

  METHOD on_before_function_handler.
  ENDMETHOD.

  METHOD on_after_function_handler.
  ENDMETHOD.

  METHOD if_salv_gui_om_edit_strct_lstr~on_check_changed_data.
**  Example:
**    o_ui_data_modify->get_ui_changes( IMPORTING t_modified_cells      = DATA(lt_modified_cells)
**                                                t_good_cells          = DATA(lt_good_cells)
**                                                t_deleted_rows        = DATA(lt_deleted_rows)
**                                                t_inserted_rows       = DATA(lt_inserted_rows)
**                                                rt_modified_data_rows = DATA(lt_modified_data_rows) ).
  ENDMETHOD.

  METHOD if_salv_gui_om_edit_strct_lstr~on_f4_request.
  ENDMETHOD.

  METHOD if_salv_gui_toolbar_listener~build_toolbar.
    _set_register_modified( ).      " To register when ALV data was/were changed

    "------------------------------------------------------------------------------------"
    " See Example from program: SALV_OM_DEMO_TABLE_TOOLBAR
    "------------------------------------------------------------------------------------"
    " Add custom logic to insert custom toolbar
  ENDMETHOD.

  METHOD if_salv_gui_toolbar_listener~build_menu.
    "------------------------------------------------------------------------------------"
    " See Example from program: SALV_OM_DEMO_TABLE_TOOLBAR
    "------------------------------------------------------------------------------------"
    " Add custom logic to build dynamic menu of toolbar
  ENDMETHOD.

  METHOD if_salv_gui_om_ctxt_menu_lstr~before_display_context_menu.
    " Add custom logic to insert custom context menu (Trigger when click right)
  ENDMETHOD.

  METHOD _set_register_modified.
    CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
      IMPORTING
        e_grid = mo_grid.

    IF mo_grid IS NOT BOUND.
      RETURN.
    ENDIF.

    CALL METHOD mo_grid->register_edit_event
      EXPORTING
        i_event_id = cl_gui_alv_grid=>mc_evt_modified.
  ENDMETHOD.
ENDCLASS.

*&---------------------------------------------------------------------*
*& ALV Class for Display Implementation
*&---------------------------------------------------------------------*
CLASS lcl_salv IMPLEMENTATION.
  METHOD display_alv.
    DATA(lr_data) = go_main->get_result_data( ).
    IF lr_data IS NOT BOUND.
      RETURN.
    ENDIF.
    ASSIGN lr_data->* TO FIELD-SYMBOL(<lt_data>).

    TRY.
        cl_salv_table=>factory(
          IMPORTING
            r_salv_table = mo_salv
          CHANGING
            t_table      = <lt_data> ).
      CATCH cx_salv_msg.
        RETURN.
    ENDTRY.

    IF mo_salv IS NOT BOUND.
      RETURN.
    ENDIF.

* Set each columns of the ALV
    me->_set_columns( ).

* Set PF-Status
    me->_set_pf_status( iv_pfstatus = space ).

* Set PF-Title
*    me->_set_pf_title( ).

* Set Layout
    me->_set_layout( ).

*** Set Top and End of Page
**    me->_set_top_end_of_page( ).

* Set appearance of the ALV
    me->_set_display_setting( ).

* Set Events
    me->_set_events( ).

*** Apply Aggregations & Filters & Sorts
**    me->_set_aggregations( ).
**    me->_set_filters( ).
**    me->_set_sorts( ).
**    me->_set_screen_popup( ).

* Displaying the ALV
    mo_salv->display( ).
  ENDMETHOD.

  METHOD refresh_alv.
    DATA: ls_stable TYPE lvc_s_stbl.

    IF mo_salv IS NOT BOUND.
      RETURN.
    ENDIF.

    ls_stable = is_stable.

    IF iv_set_all_stable IS NOT INITIAL.
      ls_stable = VALUE #( col = abap_true
                           row = abap_true ).
    ENDIF.

    mo_salv->refresh( EXPORTING s_stable     = ls_stable
                                refresh_mode = iv_refresh_mode ).
  ENDMETHOD.

  METHOD get_salv_table.
    ro_salv = mo_salv.
  ENDMETHOD.

  METHOD get_events.
    ro_events = mo_events.
  ENDMETHOD.

  METHOD _set_columns.
    DATA: lo_columns TYPE REF TO cl_salv_columns_table.
*...Get all the Columns
    lo_columns = mo_salv->get_columns( ).
    lo_columns->set_optimize( ).
    lo_columns->set_key_fixation( ).

* Get Restricted Use of extended Grid API
    me->_set_extended_grid_api( ).

    me->_set_technical_columns( ).

* Modify Column of ALV
    me->_modify_columns( lo_columns ).

* Set Editable Fields
*   Example
*     me->_set_editable_column( EXPORTING iv_columnname             = 'BUTXT'
*                                         iv_urge_foreign_key_check = abap_false ).
*     me->_set_editable_column( EXPORTING iv_columnname             = 'PERIV'
*                                         iv_urge_foreign_key_check = abap_true ).

    me->_set_editable_column( EXPORTING iv_columnname             = 'BUTXT'
                                        iv_urge_foreign_key_check = abap_false ).
    me->_set_editable_column( EXPORTING iv_columnname             = 'PERIV'
                                        iv_urge_foreign_key_check = abap_true ).

  ENDMETHOD.

  METHOD _modify_columns.
    DATA: lo_column TYPE REF TO cl_salv_column_table.
    DATA: lv_stext TYPE scrtext_s,
          lv_mtext TYPE scrtext_m,
          lv_ltext TYPE scrtext_l,
          lv_field TYPE lvc_fname.

    DEFINE mc_set_field.
* See Example Program: SALV_DEMO_TABLE_COLUMNS
      lv_field = &1.
      lv_stext = &2.
      lv_mtext = &2.
      lv_ltext = &2.

      TRY.
          lo_column ?= io_columns->get_column( lv_field ).
          lo_column->set_short_text( lv_stext ).
          lo_column->set_medium_text( lv_mtext ).
          lo_column->set_long_text( lv_ltext ).
          lo_column->set_sign( abap_true ).
        CATCH cx_salv_not_found.
          RETURN.
      ENDTRY.
    END-OF-DEFINITION.

** Change the properties of the Columns
*    mc_set_field:
*      'BUTXT'         'As Of Date'.

    "------------------------------------------------------------------------------------"
*** Set additional properties of the Columns
**    TRY.
**        lo_column ?= io_columns->get_column( '' ).
**        lo_column->set_icon( ).
**        lo_column->set_key( ).
**
**        lo_column ?= io_columns->get_column( '' ).
**        lo_column->set_cell_type( if_salv_c_cell_type=>checkbox ).
**        lo_column->set_key( ).
**      CATCH cx_salv_not_found.
**    ENDTRY.

  ENDMETHOD.

  METHOD _set_pf_status.
    IF iv_pfstatus IS NOT INITIAL.
      " Calling method to set the PF-Status
      mo_salv->set_screen_status(
        pfstatus      = iv_pfstatus
        report        = iv_report
        set_functions = iv_set_functions ).
    ELSE.
      mo_salv->get_functions( )->set_all( abap_true ).
    ENDIF.
  ENDMETHOD.

  METHOD _set_pf_title.
*    SET TITLEBAR 'XXXX' WITH 'XXXX'.
  ENDMETHOD.

  METHOD _set_layout.
    DATA: lf_variant TYPE slis_vari,
          ls_key     TYPE salv_s_layout_key.

*   get layout object
    DATA(lo_layout) = mo_salv->get_layout( ).

*   set Layout save restriction
*   1. Set Layout Key .. Unique key identifies the Differenet ALVs
    ls_key-report = sy-repid.

    lo_layout->set_key( ls_key ).
*   2. Remove Save layout the restriction.
    lo_layout->set_save_restriction( if_salv_c_layout=>restrict_none ).
    lo_layout->set_default( abap_true ).

*   set initial Layout
*    lf_variant = ''.
    lo_layout->set_initial_layout( lf_variant ).
  ENDMETHOD.

  METHOD _set_top_end_of_page.
    DATA: lo_f_label TYPE REF TO cl_salv_form_label,
          lo_f_flow  TYPE REF TO cl_salv_form_layout_flow.

    DATA(lo_header) = NEW cl_salv_form_layout_grid( ).
    DATA(lo_footer) = NEW cl_salv_form_layout_grid( ).

    "---------------------------------------------------------------------------------------------------"
    " See Example:
    "     https://zevolving.com/2008/09/salv-table-5-add-header-top-of-page-footer-end-of-page
    "---------------------------------------------------------------------------------------------------"
  ENDMETHOD.

  METHOD _set_display_setting.


    DATA(lo_disp_setting) = mo_salv->get_display_settings( ).

*   Set ZEBRA pattern
    lo_disp_setting->set_striped_pattern( abap_true ).

**   Title to ALV
*    lo_disp_setting->set_list_header( 'ALV Test for Display Settings' ).

  ENDMETHOD.

  METHOD _set_technical_columns.
    DATA lo_column TYPE REF TO cl_salv_column_table.

    DATA(lo_columns) = mo_salv->get_columns( ).

    _set_technical_client( ).

** Set ALV Color
    TRY.
**        lo_columns->set_color_column( 'T_COLOR' ).
      CATCH cx_salv_data_error.
    ENDTRY.

** Set ALV Cell type: hotspot, hyperlink, text, checkbox, checkbox(hotspot) ....
    TRY.
**        lo_columns->set_cell_type_column( 'T_CELLTYPE' ).     "if_salv_c_cell_type
      CATCH cx_salv_data_error.
    ENDTRY.

** Set ALV Exception (Traffic Light)
    TRY.
        lo_column ?= lo_columns->get_column( 'EXCEPTION' ).
        lo_column->set_technical( ).
        lo_columns->set_exception_column( 'EXCEPTION' ).      "Set exception column
      CATCH cx_salv_data_error cx_salv_not_found.
    ENDTRY.

** Set Editable with T_CELLSTYLE
    TRY.
        me->_set_editable_dummy_cellstyle( )->set_t_celltab_columnname( 'T_CELLSTYLE' ).
      CATCH cx_salv_api_contract_violation cx_salv_gui_om_not_editable.
    ENDTRY.
  ENDMETHOD.

  METHOD _set_technical_client.
    TRY.
        CAST cl_salv_column_table( mo_salv->get_columns( )->get_column( 'MANDT' ) )->set_technical( ).
      CATCH cx_salv_not_found.
    ENDTRY.
  ENDMETHOD.

  METHOD _set_events.
    DATA: lo_events TYPE REF TO cl_salv_events_table.

*  Get all events
    mo_events = COND #( WHEN mo_events IS BOUND THEN mo_events ELSE NEW lcl_salv_events( io_view = me
                                                                                         io_main = go_main ) ).
    lo_events = mo_salv->get_event( ).

*    SET HANDLER mo_events->on_user_command_handler FOR lo_events.
*    SET HANDLER mo_events->on_link_click_handler FOR lo_events.
*    SET HANDLER mo_events->on_double_click_handler FOR lo_events.
*    SET HANDLER mo_events->on_before_function_handler FOR lo_events.
*    SET HANDLER mo_events->on_after_function_handler FOR lo_events.
  ENDMETHOD.

  METHOD _set_aggregations.
    DATA: lo_aggrs TYPE REF TO cl_salv_aggregations.

    lo_aggrs = mo_salv->get_aggregations( ).
  ENDMETHOD.

  METHOD _set_filters.
    DATA: lo_filters TYPE REF TO cl_salv_filters.

    lo_filters = mo_salv->get_filters( ).
  ENDMETHOD.

  METHOD _set_sorts.
    DATA: lo_sort TYPE REF TO cl_salv_sorts.

    lo_sort = mo_salv->get_sorts( ).
  ENDMETHOD.

  METHOD _set_screen_popup.
**    mo_salv->_set_screen_popup(
**      start_column =
***      end_column   =
**      start_line   =
***      end_line     =
**    ).
  ENDMETHOD.

  METHOD _set_extended_grid_api.
    IF mo_extended_grid_api IS NOT BOUND.
      mo_extended_grid_api = mo_salv->extended_grid_api( ).
    ENDIF.
  ENDMETHOD.

  METHOD _set_editable_column.
    IF iv_columnname IS INITIAL.
      RETURN.
    ENDIF.

    _set_extended_grid_api( ).

    " Set the toolbar listener and Context menu
    TRY.
        mo_extended_grid_api->set_toolbar_listener( COND #( WHEN mo_events IS BOUND THEN mo_events
                                                            ELSE NEW lcl_salv_events( io_view = me
                                                                                      io_main = go_main ) ) ).
        mo_extended_grid_api->set_context_menu_listener( COND #( WHEN mo_events IS BOUND THEN mo_events
                                                                 ELSE NEW lcl_salv_events( io_view = me
                                                                                           io_main = go_main ) ) ).
      CATCH cx_salv_gui_tb_api_violation  ##NO_HANDLER.
    ENDTRY.

    TRY.
        DATA(lo_editable) = mo_extended_grid_api->editable_restricted( ).

        IF lo_editable IS NOT BOUND.
          RETURN.
        ENDIF.

        TRY.
            lo_editable->request_data_set_of_size( size = if_salv_gui_om_edit_restricted=>large ).
          CATCH cx_salv_gui_data_set_no_edit. " Editable Mode not possible
        ENDTRY.

        lo_editable->set_attributes_for_columnname( columnname                  = iv_columnname
                                                    drop_down_handle_columnname = iv_drop_down_columnname
                                                    s_register_f4_help          = is_register_f4_help
                                                    urge_foreign_key_check      = iv_urge_foreign_key_check
                                                    all_cells_input_enabled     = iv_all_cells_input_enabled ).

        IF mv_is_set_edit_listener IS INITIAL.
          " Set Change data listener
          lo_editable->set_listener( COND #( WHEN mo_events IS BOUND THEN mo_events
                                             ELSE NEW lcl_salv_events( io_view = me
                                                                       io_main = go_main ) ) ).
          mv_is_set_edit_listener = abap_true.
        ENDIF.
      CATCH cx_salv_api_contract_violation cx_salv_gui_om_not_editable.
      CATCH cx_salv_not_found.
    ENDTRY.
  ENDMETHOD.

  METHOD _set_editable_dummy_cellstyle.
    _set_extended_grid_api( ).

    " Set the toolbar listener and Context menu
    TRY.
        mo_extended_grid_api->set_toolbar_listener( COND #( WHEN mo_events IS BOUND THEN mo_events
                                                            ELSE NEW lcl_salv_events( io_view = me
                                                                                      io_main = go_main ) ) ).
        mo_extended_grid_api->set_context_menu_listener( COND #( WHEN mo_events IS BOUND THEN mo_events
                                                                 ELSE NEW lcl_salv_events( io_view = me
                                                                                           io_main = go_main ) ) ).
      CATCH cx_salv_gui_tb_api_violation  ##NO_HANDLER.
    ENDTRY.

    ro_editable = mo_extended_grid_api->editable_restricted( ).

    DATA(lv_dummy) = CONV lvc_fname( 'YYDUMMYEDIT' ).

    TRY.
        CAST cl_salv_column_table( mo_salv->get_columns( )->get_column( lv_dummy ) )->set_technical( ).
      CATCH cx_salv_data_error cx_salv_not_found.
    ENDTRY.

    TRY.
        DATA(lo_editable) = mo_extended_grid_api->editable_restricted( ).

        IF lo_editable IS NOT BOUND.
          RETURN.
        ENDIF.

        TRY.
            lo_editable->request_data_set_of_size( size = if_salv_gui_om_edit_restricted=>large ).
          CATCH cx_salv_gui_data_set_no_edit. " Editable Mode not possible
        ENDTRY.

        lo_editable->set_attributes_for_columnname( columnname              = lv_dummy
                                                    all_cells_input_enabled = space ).
        IF mv_is_set_edit_listener IS INITIAL.
          " Set Change data listener
          lo_editable->set_listener( COND #( WHEN mo_events IS BOUND THEN mo_events
                                             ELSE NEW lcl_salv_events( io_view = me
                                                                       io_main = go_main ) ) ).
          mv_is_set_edit_listener = abap_true.
        ENDIF.
      CATCH cx_salv_api_contract_violation cx_salv_gui_om_not_editable.
      CATCH cx_salv_not_found.
    ENDTRY.
  ENDMETHOD.
ENDCLASS.
